"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => GibSyncPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian4 = require("obsidian");

// src/api.ts
var import_obsidian = require("obsidian");

// ../packages/protocol/dist/json-merge.js
var missing = Symbol("missing");
var object = (value) => Boolean(value) && value !== missing && !Array.isArray(value) && typeof value === "object";
var get = (value, key) => Object.prototype.hasOwnProperty.call(value, key) ? value[key] : missing;
var equal = (left, right) => {
  if (left === missing || right === missing)
    return left === right;
  if (Object.is(left, right))
    return true;
  if (Array.isArray(left) && Array.isArray(right))
    return left.length === right.length && left.every((item, index) => equal(item, right[index]));
  if (object(left) && object(right))
    return [.../* @__PURE__ */ new Set([...Object.keys(left), ...Object.keys(right)])].every((key) => equal(get(left, key), get(right, key)));
  return false;
};
function records(value, bookmarks) {
  if (value === missing)
    return /* @__PURE__ */ new Map();
  if (!Array.isArray(value))
    return null;
  const result = /* @__PURE__ */ new Map();
  for (const item of value) {
    if (!object(item))
      return null;
    let key;
    if (typeof item.id === "string" || typeof item.id === "number")
      key = `id:${typeof item.id}:${item.id}`;
    else if (bookmarks && typeof item.ctime === "number" && Number.isSafeInteger(item.ctime) && item.ctime > 0 && typeof item.type === "string")
      key = `bookmark:${item.type}:${item.ctime}`;
    else
      return null;
    if (result.has(key))
      return null;
    result.set(key, item);
  }
  return result;
}
function mergeJsonValues(base, local, remote, preferLocal, schema) {
  let overlaps = 0;
  const merge = (b, l, r, depth) => {
    var _a, _b, _c;
    if (depth > 100)
      throw new Error("Settings nesting exceeds safe merge depth");
    if (equal(l, r))
      return l;
    if (equal(l, b))
      return r;
    if (equal(r, b))
      return l;
    if (object(l) && object(r)) {
      const baseline = object(b) ? b : {}, output = /* @__PURE__ */ Object.create(null);
      for (const key of /* @__PURE__ */ new Set([...Object.keys(baseline), ...Object.keys(l), ...Object.keys(r)])) {
        const value2 = merge(get(baseline, key), get(l, key), get(r, key), depth + 1);
        if (value2 !== missing)
          output[key] = value2;
      }
      return output;
    }
    if (Array.isArray(l) && Array.isArray(r)) {
      const bm = records(b, schema === "bookmarks"), lm = records(l, schema === "bookmarks"), rm = records(r, schema === "bookmarks");
      if (bm && lm && rm) {
        const order = preferLocal ? [...lm.keys(), ...rm.keys(), ...bm.keys()] : [...rm.keys(), ...lm.keys(), ...bm.keys()], output = [];
        for (const id of new Set(order)) {
          const value2 = merge((_a = bm.get(id)) != null ? _a : missing, (_b = lm.get(id)) != null ? _b : missing, (_c = rm.get(id)) != null ? _c : missing, depth + 1);
          if (value2 !== missing)
            output.push(value2);
        }
        return output;
      }
    }
    overlaps++;
    return preferLocal ? l : r;
  };
  const value = merge(base, local, remote, 0);
  return { value: value === missing ? void 0 : value, overlaps };
}

// ../node_modules/diff/libesm/diff/base.js
var Diff = class {
  diff(oldStr, newStr, options = {}) {
    let callback;
    if (typeof options === "function") {
      callback = options;
      options = {};
    } else if ("callback" in options) {
      callback = options.callback;
    }
    const oldString = this.castInput(oldStr, options);
    const newString = this.castInput(newStr, options);
    const oldTokens = this.removeEmpty(this.tokenize(oldString, options));
    const newTokens = this.removeEmpty(this.tokenize(newString, options));
    return this.diffWithOptionsObj(oldTokens, newTokens, options, callback);
  }
  diffWithOptionsObj(oldTokens, newTokens, options, callback) {
    var _a;
    const done = (value) => {
      value = this.postProcess(value, options);
      if (callback) {
        setTimeout(function() {
          callback(value);
        }, 0);
        return void 0;
      } else {
        return value;
      }
    };
    const newLen = newTokens.length, oldLen = oldTokens.length;
    let editLength = 1;
    let maxEditLength = newLen + oldLen;
    if (options.maxEditLength != null) {
      maxEditLength = Math.min(maxEditLength, options.maxEditLength);
    }
    const maxExecutionTime = (_a = options.timeout) !== null && _a !== void 0 ? _a : Infinity;
    const abortAfterTimestamp = Date.now() + maxExecutionTime;
    const bestPath = [{ oldPos: -1, lastComponent: void 0 }];
    let newPos = this.extractCommon(bestPath[0], newTokens, oldTokens, 0, options);
    if (bestPath[0].oldPos + 1 >= oldLen && newPos + 1 >= newLen) {
      return done(this.buildValues(bestPath[0].lastComponent, newTokens, oldTokens));
    }
    let minDiagonalToConsider = -Infinity, maxDiagonalToConsider = Infinity;
    const execEditLength = () => {
      for (let diagonalPath = Math.max(minDiagonalToConsider, -editLength); diagonalPath <= Math.min(maxDiagonalToConsider, editLength); diagonalPath += 2) {
        let basePath;
        const removePath = bestPath[diagonalPath - 1], addPath = bestPath[diagonalPath + 1];
        if (removePath) {
          bestPath[diagonalPath - 1] = void 0;
        }
        let canAdd = false;
        if (addPath) {
          const addPathNewPos = addPath.oldPos - diagonalPath;
          canAdd = addPath && 0 <= addPathNewPos && addPathNewPos < newLen;
        }
        const canRemove = removePath && removePath.oldPos + 1 < oldLen;
        if (!canAdd && !canRemove) {
          bestPath[diagonalPath] = void 0;
          continue;
        }
        if (!canRemove || canAdd && removePath.oldPos < addPath.oldPos) {
          basePath = this.addToPath(addPath, true, false, 0, options);
        } else {
          basePath = this.addToPath(removePath, false, true, 1, options);
        }
        newPos = this.extractCommon(basePath, newTokens, oldTokens, diagonalPath, options);
        if (basePath.oldPos + 1 >= oldLen && newPos + 1 >= newLen) {
          return done(this.buildValues(basePath.lastComponent, newTokens, oldTokens)) || true;
        } else {
          bestPath[diagonalPath] = basePath;
          if (basePath.oldPos + 1 >= oldLen) {
            maxDiagonalToConsider = Math.min(maxDiagonalToConsider, diagonalPath - 1);
          }
          if (newPos + 1 >= newLen) {
            minDiagonalToConsider = Math.max(minDiagonalToConsider, diagonalPath + 1);
          }
        }
      }
      editLength++;
    };
    if (callback) {
      (function exec() {
        setTimeout(function() {
          if (editLength > maxEditLength || Date.now() > abortAfterTimestamp) {
            return callback(void 0);
          }
          if (!execEditLength()) {
            exec();
          }
        }, 0);
      })();
    } else {
      while (editLength <= maxEditLength && Date.now() <= abortAfterTimestamp) {
        const ret = execEditLength();
        if (ret) {
          return ret;
        }
      }
    }
  }
  addToPath(path, added, removed, oldPosInc, options) {
    const last = path.lastComponent;
    if (last && !options.oneChangePerToken && last.added === added && last.removed === removed) {
      return {
        oldPos: path.oldPos + oldPosInc,
        lastComponent: { count: last.count + 1, added, removed, previousComponent: last.previousComponent }
      };
    } else {
      return {
        oldPos: path.oldPos + oldPosInc,
        lastComponent: { count: 1, added, removed, previousComponent: last }
      };
    }
  }
  extractCommon(basePath, newTokens, oldTokens, diagonalPath, options) {
    const newLen = newTokens.length, oldLen = oldTokens.length;
    let oldPos = basePath.oldPos, newPos = oldPos - diagonalPath, commonCount = 0;
    while (newPos + 1 < newLen && oldPos + 1 < oldLen && this.equals(oldTokens[oldPos + 1], newTokens[newPos + 1], options)) {
      newPos++;
      oldPos++;
      commonCount++;
      if (options.oneChangePerToken) {
        basePath.lastComponent = { count: 1, previousComponent: basePath.lastComponent, added: false, removed: false };
      }
    }
    if (commonCount && !options.oneChangePerToken) {
      basePath.lastComponent = { count: commonCount, previousComponent: basePath.lastComponent, added: false, removed: false };
    }
    basePath.oldPos = oldPos;
    return newPos;
  }
  equals(left, right, options) {
    if (options.comparator) {
      return options.comparator(left, right);
    } else {
      return left === right || !!options.ignoreCase && left.toLowerCase() === right.toLowerCase();
    }
  }
  removeEmpty(array) {
    const ret = [];
    for (let i = 0; i < array.length; i++) {
      if (array[i]) {
        ret.push(array[i]);
      }
    }
    return ret;
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  castInput(value, options) {
    return value;
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  tokenize(value, options) {
    return Array.from(value);
  }
  join(chars) {
    return chars.join("");
  }
  postProcess(changeObjects, options) {
    return changeObjects;
  }
  get useLongestToken() {
    return false;
  }
  buildValues(lastComponent, newTokens, oldTokens) {
    const components2 = [];
    let nextComponent;
    while (lastComponent) {
      components2.push(lastComponent);
      nextComponent = lastComponent.previousComponent;
      delete lastComponent.previousComponent;
      lastComponent = nextComponent;
    }
    components2.reverse();
    const componentLen = components2.length;
    let componentPos = 0, newPos = 0, oldPos = 0;
    for (; componentPos < componentLen; componentPos++) {
      const component = components2[componentPos];
      if (!component.removed) {
        if (!component.added && this.useLongestToken) {
          let value = newTokens.slice(newPos, newPos + component.count);
          value = value.map(function(value2, i) {
            const oldValue = oldTokens[oldPos + i];
            return oldValue.length > value2.length ? oldValue : value2;
          });
          component.value = this.join(value);
        } else {
          component.value = this.join(newTokens.slice(newPos, newPos + component.count));
        }
        newPos += component.count;
        if (!component.added) {
          oldPos += component.count;
        }
      } else {
        component.value = this.join(oldTokens.slice(oldPos, oldPos + component.count));
        oldPos += component.count;
      }
    }
    return components2;
  }
};

// ../node_modules/diff/libesm/diff/line.js
var LineDiff = class extends Diff {
  constructor() {
    super(...arguments);
    this.tokenize = tokenize;
  }
  equals(left, right, options) {
    if (options.ignoreWhitespace) {
      if (!options.newlineIsToken || !left.includes("\n")) {
        left = left.trim();
      }
      if (!options.newlineIsToken || !right.includes("\n")) {
        right = right.trim();
      }
    } else if (options.ignoreNewlineAtEof && !options.newlineIsToken) {
      if (left.endsWith("\n")) {
        left = left.slice(0, -1);
      }
      if (right.endsWith("\n")) {
        right = right.slice(0, -1);
      }
    }
    return super.equals(left, right, options);
  }
};
var lineDiff = new LineDiff();
function diffLines(oldStr, newStr, options) {
  return lineDiff.diff(oldStr, newStr, options);
}
function tokenize(value, options) {
  if (options.stripTrailingCr) {
    value = value.replace(/\r\n/g, "\n");
  }
  const retLines = [], linesAndNewlines = value.split(/(\n|\r\n)/);
  if (!linesAndNewlines[linesAndNewlines.length - 1]) {
    linesAndNewlines.pop();
  }
  for (let i = 0; i < linesAndNewlines.length; i++) {
    const line = linesAndNewlines[i];
    if (i % 2 && !options.newlineIsToken) {
      retLines[retLines.length - 1] += line;
    } else {
      retLines.push(line);
    }
  }
  return retLines;
}

// ../node_modules/diff/libesm/diff/array.js
var ArrayDiff = class extends Diff {
  tokenize(value) {
    return value.slice();
  }
  join(value) {
    return value;
  }
  removeEmpty(value) {
    return value;
  }
};
var arrayDiff = new ArrayDiff();
function diffArrays(oldArr, newArr, options) {
  return arrayDiff.diff(oldArr, newArr, options);
}

// ../packages/protocol/dist/text-merge.js
var MAX_AUTO_MERGE_CHARACTERS = 75e4;
var MAX_AUTO_MERGE_TOKENS = 75e3;
var DIFF_BUDGET_MS = 20;
var word = /[\p{L}\p{N}_]/u;
var tokenize2 = (value) => {
  var _a;
  return (_a = value.match(/\s+|[\p{L}\p{N}_]+|[^\s\p{L}\p{N}_]/gu)) != null ? _a : [];
};
function hunks(base, changed, side) {
  const parts = diffArrays(base, changed, { timeout: DIFF_BUDGET_MS, maxEditLength: 2048 });
  if (!parts)
    throw new Error("comparison exceeded the interactive work budget");
  const output = [];
  let baseIndex = 0;
  for (let index = 0; index < parts.length; index++) {
    const part = parts[index];
    if (!part.added && !part.removed) {
      baseIndex += part.value.length;
      continue;
    }
    const hunk = { start: baseIndex, remove: 0, add: [], side };
    while (index < parts.length && (parts[index].added || parts[index].removed)) {
      const current = parts[index];
      if (current.removed) {
        hunk.remove += current.value.length;
        baseIndex += current.value.length;
      }
      if (current.added)
        for (const value of current.value)
          hunk.add.push(value);
      index++;
    }
    index--;
    output.push(hunk);
  }
  return output;
}
function components(hunks2) {
  const output = [];
  let current = [];
  let end = -1;
  let insertionAtEnd = false;
  for (const hunk of [...hunks2].sort((a, b) => a.start - b.start || a.remove - b.remove)) {
    const connects = current.length && (hunk.start < end || hunk.start === end && (hunk.remove === 0 || insertionAtEnd));
    if (!connects) {
      current = [];
      output.push(current);
      end = hunk.start;
      insertionAtEnd = false;
    }
    current.push(hunk);
    const nextEnd = hunk.start + hunk.remove;
    if (nextEnd > end) {
      end = nextEnd;
      insertionAtEnd = false;
    }
    if (hunk.remove === 0 && hunk.start === end)
      insertionAtEnd = true;
  }
  return output;
}
function scale(base, component) {
  const start = Math.min(...component.map((hunk) => hunk.start));
  const end = Math.max(...component.map((hunk) => hunk.start + hunk.remove));
  const samples = [base.slice(start, end), ...component.map((hunk) => hunk.add)];
  return {
    words: Math.max(...samples.map((tokens) => tokens.filter((token) => word.test(token)).length)),
    lines: Math.max(...samples.map((tokens) => tokens.join("").split("\n").length))
  };
}
function affectedLines(base, component) {
  var _a, _b;
  const start = Math.min(...component.map((hunk) => hunk.start));
  const startLine = ((_b = (_a = base.slice(0, start).join("").match(/\n/g)) == null ? void 0 : _a.length) != null ? _b : 0) + 1;
  const size = scale(base, component), lines = /* @__PURE__ */ new Set();
  for (let offset = 0; offset < size.lines; offset++)
    lines.add(startLine + offset);
  return lines;
}
function mergeText(baseText, localText, remoteText, preferred) {
  const done = (text) => ({ text, conflicted: false, kind: "merged", overlapWords: 0, overlapLines: 0 });
  const fallback = (reason) => ({ text: preferred === "local" ? localText : remoteText, conflicted: true, kind: "merge-fallback", overlapWords: 0, overlapLines: 0, reason });
  if (localText === remoteText)
    return done(localText);
  if (localText === baseText)
    return done(remoteText);
  if (remoteText === baseText)
    return done(localText);
  if (baseText.length + localText.length + remoteText.length > MAX_AUTO_MERGE_CHARACTERS)
    return fallback("combined text is too large for a reliable automatic merge");
  let base, local, remote, all;
  try {
    base = tokenize2(baseText);
    local = tokenize2(localText);
    remote = tokenize2(remoteText);
    if (base.length + local.length + remote.length > MAX_AUTO_MERGE_TOKENS)
      return fallback("combined token count is too large for a reliable automatic merge");
    all = [...hunks(base, local, "local"), ...hunks(base, remote, "remote")];
  } catch (error) {
    const reason = error instanceof Error ? `${error.name}: ${error.message}` : String(error);
    return fallback(`merge engine could not compare the versions (${reason})`);
  }
  try {
    const groups = components(all), mixedGroups = groups.filter((component) => component.some((hunk) => hunk.side === "local") && component.some((hunk) => hunk.side === "remote"));
    const overlapWords = mixedGroups.reduce((total, component) => total + scale(base, component).words, 0), lines = /* @__PURE__ */ new Set();
    for (const component of mixedGroups)
      for (const line of affectedLines(base, component))
        lines.add(line);
    const overlapLines = lines.size;
    if (overlapWords > 20 || overlapLines > 2)
      return { text: preferred === "local" ? localText : remoteText, conflicted: true, kind: "large-conflict", overlapWords, overlapLines };
    const selected = [];
    let smallOverlap = false;
    for (const component of groups) {
      const mixed = component.some((hunk) => hunk.side === "local") && component.some((hunk) => hunk.side === "remote");
      if (!mixed) {
        selected.push(...component);
        continue;
      }
      smallOverlap = true;
      selected.push(...component.filter((hunk) => hunk.side === preferred));
    }
    const result = [];
    let cursor = 0;
    for (const hunk of selected.sort((left, right) => left.start - right.start)) {
      if (hunk.start < cursor)
        throw new Error("selected changes unexpectedly overlap");
      result.push(base.slice(cursor, hunk.start).join(""), hunk.add.join(""));
      cursor = hunk.start + hunk.remove;
    }
    result.push(base.slice(cursor).join(""));
    return { text: result.join(""), conflicted: false, kind: smallOverlap ? "small-overlap" : "merged", overlapWords, overlapLines };
  } catch (error) {
    const reason = error instanceof Error ? `${error.name}: ${error.message}` : String(error);
    return fallback(`merge engine could not safely assemble the result (${reason})`);
  }
}

// ../packages/protocol/dist/operations.js
var MAX_SETTINGS_JSON_BYTES = 2 * 1024 * 1024;
function reconciliationStrategy(path) {
  const normalized = path.replace(/\\/g, "/").toLowerCase();
  return normalized.startsWith(".obsidian/") ? normalized.endsWith(".json") ? "json-settings" : "whole-file" : "text";
}
function reconcileFolders(input) {
  var _a, _b;
  const byId = (folders) => {
    const map = /* @__PURE__ */ new Map();
    for (const folder of folders) {
      if (map.has(folder.folderId))
        throw new Error("Duplicate folder identity");
      map.set(folder.folderId, folder);
    }
    return map;
  }, base = byId(input.base), local = byId(input.local), remote = byId(input.remote), chosen = [], conflicts = [];
  for (const id of /* @__PURE__ */ new Set([...base.keys(), ...local.keys(), ...remote.keys()])) {
    const b = base.get(id), l = local.get(id), r = remote.get(id);
    let selected;
    if ((l == null ? void 0 : l.path) === (r == null ? void 0 : r.path))
      selected = r != null ? r : l;
    else if (!b)
      selected = r != null ? r : l;
    else if ((l == null ? void 0 : l.path) === b.path)
      selected = r;
    else if ((r == null ? void 0 : r.path) === b.path)
      selected = l;
    else {
      selected = l && r ? l.revision.modifiedAt > r.revision.modifiedAt ? l : r.revision.modifiedAt > l.revision.modifiedAt ? r : l.path < r.path ? l : r : l != null ? l : r;
      if (selected)
        conflicts.push({ folderId: id, localPath: (_a = l == null ? void 0 : l.path) != null ? _a : null, remotePath: (_b = r == null ? void 0 : r.path) != null ? _b : null, chosenPath: selected.path });
    }
    if (selected)
      chosen.push(selected);
  }
  const accepted = input.acceptedSide === "local" ? local : remote, byPath = /* @__PURE__ */ new Map();
  for (const folder of chosen) {
    const key = folder.path.normalize("NFC").toLowerCase(), prior = byPath.get(key), acceptedHere = (entry) => {
      var _a2;
      return ((_a2 = accepted.get(entry.folderId)) == null ? void 0 : _a2.path.normalize("NFC").toLowerCase()) === key;
    };
    if (!prior || acceptedHere(folder) && !acceptedHere(prior) || acceptedHere(folder) === Boolean(prior && acceptedHere(prior)) && folder.folderId < prior.folderId)
      byPath.set(key, folder);
  }
  return { folders: [...byPath.values()].sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0), conflicts: conflicts.sort((a, b) => a.folderId < b.folderId ? -1 : a.folderId > b.folderId ? 1 : 0) };
}
var same = (a, b) => {
  if (!a || !b)
    return a === b;
  return a.hash === b.hash && a.size === b.size && (!a.fileId || !b.fileId || a.fileId === b.fileId);
};
function decideReconciliation(path, base, local, remote) {
  let kind;
  const localRecreated = Boolean((base == null ? void 0 : base.fileId) && (local == null ? void 0 : local.fileId) && local.fileId !== base.fileId), remoteRecreated = Boolean((base == null ? void 0 : base.fileId) && (remote == null ? void 0 : remote.fileId) && remote.fileId !== base.fileId);
  if (localRecreated || remoteRecreated) {
    if (same(local, remote))
      kind = "equal";
    else if (localRecreated && !remoteRecreated && (!remote || same(base, remote)))
      kind = "local-only";
    else if (remoteRecreated && !localRecreated && (!local || same(base, local)))
      kind = "remote-only";
    else
      kind = "independent-create";
  } else if (same(local, remote))
    kind = same(base, local) ? "unchanged" : "equal";
  else if (same(base, local))
    kind = "remote-only";
  else if (same(base, remote))
    kind = "local-only";
  else if (!base)
    kind = local && remote ? "independent-create" : local ? "local-only" : "remote-only";
  else if (!local || !remote)
    kind = "edit-delete";
  else if (base.fileId && local.fileId && base.fileId !== local.fileId || base.fileId && remote.fileId && base.fileId !== remote.fileId)
    kind = "independent-create";
  else
    kind = "concurrent-edit";
  return { path, kind, strategy: reconciliationStrategy(path), ...base ? { base } : {}, ...local ? { local } : {}, ...remote ? { remote } : {} };
}
async function planReconciliationCooperative(input, cooperate) {
  let work = 0;
  const step = async () => {
    if (++work >= 512) {
      work = 0;
      await cooperate();
    }
  }, paths = /* @__PURE__ */ new Set();
  const byPath = async (entries) => {
    const result = /* @__PURE__ */ new Map();
    for (const entry of entries) {
      if (result.has(entry.path))
        throw new Error("Duplicate reconciliation path");
      result.set(entry.path, entry);
      paths.add(entry.path);
      await step();
    }
    return result;
  };
  const base = await byPath(input.base), local = await byPath(input.local), remote = await byPath(input.remote);
  let ordered = [];
  for (const path of paths) {
    ordered.push(path);
    await step();
  }
  let scratch = new Array(ordered.length);
  for (let width = 1; width < ordered.length; width *= 2) {
    for (let start = 0; start < ordered.length; start += 2 * width) {
      let a = start, b = Math.min(start + width, ordered.length), endA = b, endB = Math.min(start + 2 * width, ordered.length);
      for (let i = start; i < endB; i++) {
        scratch[i] = a < endA && (b >= endB || ordered[a] <= ordered[b]) ? ordered[a++] : ordered[b++];
        await step();
      }
    }
    [ordered, scratch] = [scratch, ordered];
  }
  const decisions = [];
  for (const path of ordered) {
    decisions.push(decideReconciliation(path, base.get(path), local.get(path), remote.get(path)));
    await step();
  }
  return { decisions };
}
var pathOrder = (a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0;
var packageEqual = (left, right) => {
  if (left.entries.length !== right.entries.length)
    return false;
  const values = new Map(right.entries.map((entry) => [entry.path, entry.hash]));
  return left.entries.every((entry) => values.get(entry.path) === entry.hash);
};
function versionOrder(left, right) {
  if (left === right)
    return 0;
  const parse = (value) => typeof value === "string" ? value.match(/^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?(?:\+[0-9A-Za-z.-]+)?$/) : null;
  const a = parse(left), b = parse(right);
  if (!a || !b)
    return a ? 1 : b ? -1 : 0;
  for (let i = 1; i <= 3; i++) {
    const x2 = Number(a[i]), y2 = Number(b[i]);
    if (x2 !== y2)
      return x2 > y2 ? 1 : -1;
  }
  if (!a[4] || !b[4])
    return a[4] ? -1 : b[4] ? 1 : 0;
  const x = a[4].split("."), y = b[4].split(".");
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    if (x[i] === void 0)
      return -1;
    if (y[i] === void 0)
      return 1;
    if (x[i] === y[i])
      continue;
    const xn = /^\d+$/.test(x[i]), yn = /^\d+$/.test(y[i]);
    if (xn && yn)
      return Number(x[i]) > Number(y[i]) ? 1 : -1;
    if (xn !== yn)
      return xn ? -1 : 1;
    return x[i] > y[i] ? 1 : -1;
  }
  return 0;
}
function selectPluginPackage(base, local, remote) {
  const localChanged = !packageEqual(local, base), remoteChanged = !packageEqual(remote, base), choose = (side, reason, resolved = false) => ({ side, entries: [...side === "local" ? local.entries : remote.entries].sort(pathOrder), reason, resolved });
  if (!local.complete && !remote.complete && (local.entries.length || remote.entries.length)) {
    return { side: base.complete ? "base" : "held", entries: [...base.entries].sort(pathOrder), reason: base.complete ? "both incoming packages are incomplete; retained the verified baseline" : "no complete package is available; package changes are held while notes continue", resolved: true };
  }
  if (packageEqual(local, remote))
    return { side: "equal", entries: [...remote.entries].sort(pathOrder), reason: "identical package", resolved: false };
  if (localChanged && !remoteChanged && !local.entries.length)
    return choose("local", "this device removed the package");
  if (!localChanged && remoteChanged && !remote.entries.length)
    return choose("remote", "remote package was removed");
  if (local.entries.length && remote.entries.length && local.complete !== remote.complete)
    return choose(local.complete ? "local" : "remote", "complete package repairs an incomplete copy", true);
  const order = versionOrder(local.version, remote.version);
  if (local.complete && remote.complete && order)
    return choose(order > 0 ? "local" : "remote", "higher manifest version", true);
  if (local.complete && remote.complete && !order) {
    const byPath = new Map(remote.entries.map((entry) => [entry.path, entry]));
    const overlaps = local.entries.some((entry) => byPath.has(entry.path) && byPath.get(entry.path).hash !== entry.hash);
    if (!overlaps) {
      for (const entry of local.entries)
        byPath.set(entry.path, entry);
      return { side: "equal", entries: [...byPath.values()].sort(pathOrder), reason: "same-version non-overlapping ancillary assets", resolved: true };
    }
  }
  if (localChanged && !remoteChanged)
    return choose("local", local.entries.length ? "only this device changed the package" : "this device removed the package");
  if (!localChanged && remoteChanged)
    return choose("remote", remote.entries.length ? "only the remote package changed" : "remote package was removed");
  if (local.complete !== remote.complete)
    return choose(local.complete ? "local" : "remote", "complete package repairs an incomplete copy", true);
  if (order)
    return choose(order > 0 ? "local" : "remote", "higher manifest version", true);
  const modified = (evidence) => evidence.entries.reduce((latest, entry) => {
    var _a, _b;
    return Math.max(latest, (_b = (_a = entry.revision) == null ? void 0 : _a.modifiedAt) != null ? _b : entry.mtime);
  }, 0);
  return choose(modified(local) > modified(remote) ? "local" : "remote", "same version; later observed package content", true);
}

// ../packages/protocol/dist/index.js
var PROTOCOL_VERSION = 7;
var MINIMUM_SAFE_SERVER_VERSION = "0.8.55";
var REQUIRED_SERVER_CAPABILITIES = ["readable-generation-v1", "external-delete-proof-v1", "folder-manifest-v1", "folder-manifest-migration-v2", "folder-provenance-repair-v1", "folder-retirement-directive-v1", "snapshot-integrity-v1", "atomic-head-commit-v1", "server-containment-v1"];
var movedPrefix = (previousPath, path) => {
  const previous = previousPath.split("/"), next = path.split("/");
  let suffix = 0;
  while (suffix < previous.length && suffix < next.length && previous[previous.length - 1 - suffix] === next[next.length - 1 - suffix])
    suffix++;
  if (!suffix)
    return null;
  const previousPrefix = previous.slice(0, previous.length - suffix).join("/"), nextPrefix = next.slice(0, next.length - suffix).join("/");
  return previousPrefix !== nextPrefix ? { previous: previousPrefix, next: nextPrefix } : null;
};
function detectMoves(previous, next, mode = "assessment") {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
  const before = new Map(previous.map((entry) => [entry.path, entry])), after = new Map(next.map((entry) => [entry.path, entry]));
  const removed = [...before.values()].filter((entry) => !after.has(entry.path)), created = [...after.values()].filter((entry) => !before.has(entry.path));
  const removedByHash = /* @__PURE__ */ new Map(), createdByHash = /* @__PURE__ */ new Map();
  for (const entry of removed) {
    const group = (_a = removedByHash.get(entry.hash)) != null ? _a : [];
    group.push(entry);
    removedByHash.set(entry.hash, group);
  }
  for (const entry of created) {
    const group = (_b = createdByHash.get(entry.hash)) != null ? _b : [];
    group.push(entry);
    createdByHash.set(entry.hash, group);
  }
  const result = /* @__PURE__ */ new Map(), usedCreated = /* @__PURE__ */ new Set();
  const identityBefore = /* @__PURE__ */ new Map(), identityAfter = /* @__PURE__ */ new Map();
  for (const entry of previous)
    if (entry.fileId) {
      const group = (_c = identityBefore.get(entry.fileId)) != null ? _c : [];
      group.push(entry);
      identityBefore.set(entry.fileId, group);
    }
  for (const entry of next)
    if (entry.fileId) {
      const group = (_d = identityAfter.get(entry.fileId)) != null ? _d : [];
      group.push(entry);
      identityAfter.set(entry.fileId, group);
    }
  for (const source of removed) {
    if (!source.fileId || ((_e = identityBefore.get(source.fileId)) == null ? void 0 : _e.length) !== 1)
      continue;
    const destinations = (_f = identityAfter.get(source.fileId)) != null ? _f : [], destination = destinations[0];
    if (destinations.length !== 1 || !destination || before.has(destination.path) || !created.some((item) => item.path === destination.path))
      continue;
    result.set(source.path, destination.path);
    usedCreated.add(destination.path);
  }
  for (const [hash, sources] of removedByHash) {
    const destinations = (_g = createdByHash.get(hash)) != null ? _g : [];
    if (sources.length !== 1 || destinations.length !== 1 || result.has(sources[0].path) || usedCreated.has(destinations[0].path))
      continue;
    if (sources[0].fileId && destinations[0].fileId && sources[0].fileId !== destinations[0].fileId)
      continue;
    result.set(sources[0].path, destinations[0].path);
    usedCreated.add(destinations[0].path);
  }
  if (mode === "identity")
    return [...result].map(([previousPath, path]) => ({ previousPath, path })).sort((a, b) => a.previousPath.localeCompare(b.previousPath));
  const prefixCounts = /* @__PURE__ */ new Map();
  const support = (source, destination, exact) => {
    const prefixes = movedPrefix(source, destination);
    if (!prefixes)
      return;
    const key = `${prefixes.previous}\0${prefixes.next}`, current = prefixCounts.get(key);
    if (current) {
      current.count++;
      if (exact)
        current.exact++;
    } else
      prefixCounts.set(key, { ...prefixes, count: 1, exact: exact ? 1 : 0 });
  };
  for (const [source, destination] of result)
    support(source, destination, true);
  const name = (path) => path.slice(path.lastIndexOf("/") + 1), extension = (path) => {
    const value = name(path), index = value.lastIndexOf(".");
    return index < 0 ? "" : value.slice(index + 1).toLowerCase();
  };
  const remainingRemoved = removed.filter((entry) => !result.has(entry.path)), remainingCreated = created.filter((entry) => !usedCreated.has(entry.path));
  const removedByName = /* @__PURE__ */ new Map(), createdByName = /* @__PURE__ */ new Map();
  for (const entry of remainingRemoved) {
    const group = (_h = removedByName.get(name(entry.path))) != null ? _h : [];
    group.push(entry);
    removedByName.set(name(entry.path), group);
  }
  for (const entry of remainingCreated) {
    const group = (_i = createdByName.get(name(entry.path))) != null ? _i : [];
    group.push(entry);
    createdByName.set(name(entry.path), group);
  }
  for (const [filename, sources] of removedByName) {
    const destinations = (_j = createdByName.get(filename)) != null ? _j : [];
    if (sources.length !== 1 || destinations.length !== 1)
      continue;
    const source = sources[0], destination = destinations[0], largest = Math.max(source.size, destination.size), sizeDifference = Math.abs(source.size - destination.size);
    if (extension(source.path) !== extension(destination.path) || sizeDifference > Math.max(64 * 1024, largest * 0.5))
      continue;
    support(source.path, destination.path, false);
  }
  const mappings = [...prefixCounts.values()].filter((item) => item.exact >= 2 || item.count >= 3).sort((left, right) => right.previous.length - left.previous.length || right.count - left.count);
  for (const source of removed) {
    if (result.has(source.path))
      continue;
    for (const mapping of mappings) {
      const prefix = mapping.previous ? `${mapping.previous}/` : "";
      if (prefix && !source.path.startsWith(prefix))
        continue;
      const suffix = prefix ? source.path.slice(prefix.length) : source.path, candidate = mapping.next ? `${mapping.next}/${suffix}` : suffix;
      if (usedCreated.has(candidate) || before.has(candidate) || !after.has(candidate))
        continue;
      result.set(source.path, candidate);
      usedCreated.add(candidate);
      break;
    }
  }
  return [...result].map(([previousPath, path]) => ({ previousPath, path })).sort((left, right) => left.previousPath.localeCompare(right.previousPath));
}

// ../node_modules/@noble/hashes/_u64.js
var fromNumH = (n) => n / 2 ** 32 | 0;
var fromNumL = (n) => n >>> 0;
function setU64FromNum(view, byteOffset, n, isLE) {
  const h = fromNumH(n);
  const l = fromNumL(n);
  view.setUint32(byteOffset, isLE ? l : h, isLE);
  view.setUint32(byteOffset + 4, isLE ? h : l, isLE);
}

// ../node_modules/@noble/hashes/utils.js
function isBytes(a) {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in a && a.BYTES_PER_ELEMENT === 1;
}
var atitle = (title) => title ? `"${title}" ` : "";
function anumber(n, title = "") {
  if (typeof n !== "number")
    throw new TypeError(atitle(title) + "expected number, got " + typeof n);
  if (!Number.isSafeInteger(n) || n < 0)
    throw new RangeError(atitle(title) + "expected integer >= 0, got " + n);
  return n;
}
function abytes(value, length, title = "") {
  if (isBytes(value) && (length === void 0 || value.length === length))
    return value;
  if (length !== void 0)
    anumber(length, "length");
  const bytes2 = isBytes(value);
  const ofLen = length !== void 0 ? ` of length ${length}` : "";
  const got = bytes2 ? `length=${value.length}` : `type=${typeof value}`;
  const message = atitle(title) + "expected Uint8Array" + ofLen + ", got " + got;
  if (!bytes2)
    throw new TypeError(message);
  throw new RangeError(message);
}
var aobject = (value, label) => {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    throw new TypeError((label === "object" ? "" : `"${label}" `) + "expected object, got type=" + typeof value);
};
var aopts = (value, label) => {
  aobject(value, label);
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null)
    throw new TypeError(`"${label}" expected plain object`);
  if (Object.hasOwn(value, "__proto__"))
    throw new TypeError(`"${label}.__proto__" is not allowed`);
};
function aexists(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("hash was destroyed");
  if (checkFinished && instance.finished)
    throw new Error("digest() was already called");
}
function aoutput(out, instance) {
  abytes(out, void 0, "output");
  const min = instance.outputLen;
  if (!(out.length >= min)) {
    throw new RangeError('"output" expected length >= ' + min);
  }
}
function clean(...arrays) {
  for (let i = 0; i < arrays.length; i++) {
    arrays[i].fill(0);
  }
}
function createView(arr) {
  return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
}
function rotr(word2, shift) {
  return word2 << 32 - shift | word2 >>> shift;
}
var hasHexBuiltin = /* @__PURE__ */ (() => (
  // @ts-ignore
  typeof Uint8Array.from([]).toHex === "function" && typeof Uint8Array.fromHex === "function"
))();
var hexes = /* @__PURE__ */ Array.from({ length: 256 }, (_, i) => i.toString(16).padStart(2, "0"));
function bytesToHex(bytes2) {
  abytes(bytes2);
  if (hasHexBuiltin)
    return bytes2.toHex();
  let hex = "";
  for (let i = 0; i < bytes2.length; i++) {
    hex += hexes[bytes2[i]];
  }
  return hex;
}
function checkOpts(defaults, opts, title = "opts") {
  aopts(defaults, "defaults");
  if (opts !== void 0)
    aopts(opts, title);
  const merged = Object.assign(/* @__PURE__ */ Object.create(null), defaults, opts);
  return merged;
}
function createHasher(hashCons, info = {}) {
  if (typeof hashCons !== "function")
    throw new TypeError('"hashCons" expected function, got type=' + typeof hashCons);
  info = checkOpts({}, info, "info");
  const hashC = (msg, opts) => hashCons(opts).update(msg).digest();
  const tmp = hashCons(void 0);
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.canXOF = tmp.canXOF;
  hashC.create = (opts) => hashCons(opts);
  Object.assign(hashC, info);
  return Object.freeze(hashC);
}
var oidNist = (suffix) => ({
  // Current NIST hashAlgs suffixes used here fit in one DER subidentifier octet.
  // Larger suffix values would need base-128 OID encoding and a different length byte.
  oid: Uint8Array.from([6, 9, 96, 134, 72, 1, 101, 3, 4, 2, suffix])
});

// ../node_modules/@noble/hashes/_md.js
function Chi(a, b, c) {
  return a & b ^ ~a & c;
}
function Maj(a, b, c) {
  return a & b ^ a & c ^ b & c;
}
var HashMD = class {
  constructor(blockLen, outputLen, padOffset, isLE) {
    __publicField(this, "blockLen");
    __publicField(this, "outputLen");
    __publicField(this, "canXOF", false);
    __publicField(this, "padOffset");
    __publicField(this, "isLE");
    // For partial updates less than block size
    __publicField(this, "buffer");
    __publicField(this, "view");
    __publicField(this, "finished", false);
    __publicField(this, "length", 0);
    __publicField(this, "pos", 0);
    __publicField(this, "destroyed", false);
    this.blockLen = blockLen;
    this.outputLen = outputLen;
    this.padOffset = padOffset;
    this.isLE = isLE;
    this.buffer = new Uint8Array(blockLen);
    this.view = createView(this.buffer);
  }
  update(data) {
    aexists(this);
    abytes(data);
    const { view, buffer, blockLen } = this;
    const len = data.length;
    let processed = false;
    for (let pos = 0; pos < len; ) {
      const take = Math.min(blockLen - this.pos, len - pos);
      if (take === blockLen) {
        const dataView = createView(data);
        for (; blockLen <= len - pos; pos += blockLen)
          this.process(dataView, pos);
        processed = true;
        continue;
      }
      buffer.set(pos === 0 && take === len ? data : data.subarray(pos, pos + take), this.pos);
      this.pos += take;
      pos += take;
      if (this.pos === blockLen) {
        this.process(view, 0);
        this.pos = 0;
        processed = true;
      }
    }
    this.length += data.length;
    if (processed)
      this.roundClean();
    return this;
  }
  digestInto(out) {
    aexists(this);
    aoutput(out, this);
    this.finished = true;
    const { buffer, view, blockLen, isLE } = this;
    let { pos } = this;
    buffer[pos++] = 128;
    buffer.fill(0, pos);
    if (this.padOffset > blockLen - pos) {
      this.process(view, 0);
      buffer.fill(0);
    }
    setU64FromNum(view, blockLen - 8, this.length * 8, isLE);
    this.process(view, 0);
    this.roundClean();
    const oview = out === buffer ? view : createView(out);
    const len = this.outputLen;
    const outLen = len / 4;
    const state = this.get();
    if (len % 4 || outLen > state.length)
      throw new Error("invalid outputLen");
    for (let i = 0; i < outLen; i++)
      oview.setUint32(4 * i, state[i], isLE);
  }
  digest() {
    const { buffer, outputLen } = this;
    this.digestInto(buffer);
    const res = buffer.slice(0, outputLen);
    this.destroy();
    return res;
  }
  _cloneIntoMeta(to) {
    const { buffer, length, finished, destroyed, pos } = this;
    to.destroyed = destroyed;
    to.finished = finished;
    to.length = length;
    to.pos = pos;
    if (pos)
      to.buffer.set(buffer);
    return to;
  }
  clone() {
    return this._cloneInto();
  }
};
var SHA256_IV = /* @__PURE__ */ Uint32Array.from([
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
]);

// ../node_modules/@noble/hashes/sha2.js
var SHA256_K = /* @__PURE__ */ Uint32Array.from([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var SHA256_W = /* @__PURE__ */ new Uint32Array(64);
var SHA2_32B = class extends HashMD {
  constructor(outputLen, IV) {
    super(64, outputLen, 8, false);
    // We cannot use array here since array allows indexing by variable
    // which means optimizer/compiler cannot use registers.
    // Numeric initializers matter: starting the fields as `undefined` changes
    // V8's field representation and makes sha256 3x slower (measured).
    __publicField(this, "A", 0);
    __publicField(this, "B", 0);
    __publicField(this, "C", 0);
    __publicField(this, "D", 0);
    __publicField(this, "E", 0);
    __publicField(this, "F", 0);
    __publicField(this, "G", 0);
    __publicField(this, "H", 0);
    this.A = IV[0] | 0;
    this.B = IV[1] | 0;
    this.C = IV[2] | 0;
    this.D = IV[3] | 0;
    this.E = IV[4] | 0;
    this.F = IV[5] | 0;
    this.G = IV[6] | 0;
    this.H = IV[7] | 0;
  }
  get() {
    const { A, B, C, D, E, F, G, H } = this;
    return [A, B, C, D, E, F, G, H];
  }
  // prettier-ignore
  set(A, B, C, D, E, F, G, H) {
    this.A = A | 0;
    this.B = B | 0;
    this.C = C | 0;
    this.D = D | 0;
    this.E = E | 0;
    this.F = F | 0;
    this.G = G | 0;
    this.H = H | 0;
  }
  _cloneInto(to) {
    (to || (to = new this.constructor())).set(...this.get());
    return this._cloneIntoMeta(to);
  }
  process(view, offset) {
    for (let i = 0; i < 16; i++, offset += 4)
      SHA256_W[i] = view.getUint32(offset, false);
    for (let i = 16; i < 64; i++) {
      const W15 = SHA256_W[i - 15];
      const W2 = SHA256_W[i - 2];
      const s0 = rotr(W15, 7) ^ rotr(W15, 18) ^ W15 >>> 3;
      const s1 = rotr(W2, 17) ^ rotr(W2, 19) ^ W2 >>> 10;
      SHA256_W[i] = s1 + SHA256_W[i - 7] + s0 + SHA256_W[i - 16] | 0;
    }
    let { A, B, C, D, E, F, G, H } = this;
    for (let i = 0; i < 64; i++) {
      const sigma1 = rotr(E, 6) ^ rotr(E, 11) ^ rotr(E, 25);
      const T1 = H + sigma1 + Chi(E, F, G) + SHA256_K[i] + SHA256_W[i] | 0;
      const sigma0 = rotr(A, 2) ^ rotr(A, 13) ^ rotr(A, 22);
      const T2 = sigma0 + Maj(A, B, C) | 0;
      H = G;
      G = F;
      F = E;
      E = D + T1 | 0;
      D = C;
      C = B;
      B = A;
      A = T1 + T2 | 0;
    }
    A = A + this.A | 0;
    B = B + this.B | 0;
    C = C + this.C | 0;
    D = D + this.D | 0;
    E = E + this.E | 0;
    F = F + this.F | 0;
    G = G + this.G | 0;
    H = H + this.H | 0;
    this.set(A, B, C, D, E, F, G, H);
  }
  roundClean() {
    clean(SHA256_W);
  }
  destroy() {
    this.destroyed = true;
    this.set(0, 0, 0, 0, 0, 0, 0, 0);
    clean(this.buffer);
  }
};
var _SHA256 = class extends SHA2_32B {
  constructor() {
    super(32, SHA256_IV);
  }
};
var sha256 = /* @__PURE__ */ createHasher(
  () => new _SHA256(),
  /* @__PURE__ */ oidNist(1)
);

// src/crypto.ts
var encoder = new TextEncoder();
function fromBase64Url(value) {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(value.length / 4) * 4, "=");
  const binary = atob(normalized);
  const bytes2 = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes2[i] = binary.charCodeAt(i);
  return bytes2;
}
function normalizeQuickCode(value) {
  const compact = value.replace(/\s/g, "");
  if (!/^\d{5}$/.test(compact)) throw new Error("Enter the five-digit quick code");
  return compact;
}
async function hashBytes(bytes2) {
  if (bytes2.byteLength > 1024 * 1024) {
    const hash = sha256.create();
    let yieldedAt = performance.now();
    for (let offset = 0; offset < bytes2.byteLength; offset += 64 * 1024) {
      hash.update(bytes2.subarray(offset, offset + 64 * 1024));
      if (performance.now() - yieldedAt >= 8) {
        await new Promise((resolve) => setTimeout(resolve, 0));
        yieldedAt = performance.now();
      }
    }
    return bytesToHex(hash.digest());
  }
  const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", bytes2));
  return Array.from(digest, (b) => b.toString(16).padStart(2, "0")).join("");
}
async function importKey(raw) {
  return crypto.subtle.importKey("raw", fromBase64Url(raw), { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}
async function encryptBlob(bytes2, key, hash) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv, additionalData: encoder.encode(hash) }, await importKey(key), bytes2));
  const output = new Uint8Array(1 + iv.length + encrypted.length);
  output[0] = 1;
  output.set(iv, 1);
  output.set(encrypted, 13);
  return output;
}
async function decryptBlob(payload, key, hash) {
  if (payload[0] !== 1 || payload.length < 29) throw new Error("Unsupported or invalid encrypted blob");
  const result = await crypto.subtle.decrypt({ name: "AES-GCM", iv: payload.slice(1, 13), additionalData: encoder.encode(hash) }, await importKey(key), payload.slice(13));
  const bytes2 = new Uint8Array(result);
  if (await hashBytes(bytes2) !== hash) throw new Error(`Integrity check failed for ${hash}`);
  return bytes2;
}
async function openPairingEnvelope(payload, secret, pairingId) {
  const packed = fromBase64Url(payload);
  const salt = encoder.encode("gib-sync-v1");
  const context = encoder.encode(`pairing:${pairingId}`);
  const base = await crypto.subtle.importKey("raw", encoder.encode(secret), "HKDF", false, ["deriveKey"]);
  const key = await crypto.subtle.deriveKey({ name: "HKDF", hash: "SHA-256", salt, info: context }, base, { name: "AES-GCM", length: 256 }, false, ["decrypt"]);
  const combined = new Uint8Array(packed.length - 12);
  combined.set(packed.slice(28), 0);
  combined.set(packed.slice(12, 28), packed.length - 28);
  const decoded = await crypto.subtle.decrypt({ name: "AES-GCM", iv: packed.slice(0, 12) }, key, combined);
  return JSON.parse(new TextDecoder().decode(decoded));
}

// src/io-control.ts
async function controlledIo(checkpoint, operation) {
  const controller = new AbortController();
  let deadline = Date.now() + 12e4, cancelled;
  checkpoint();
  const timer = setInterval(() => {
    try {
      checkpoint();
      if (Date.now() > deadline) throw new ApiTransportError(new Error("File transfer stalled; retrying safely"));
    } catch (error) {
      cancelled = error;
      controller.abort();
    }
  }, 250);
  try {
    return await operation(controller.signal, () => {
      deadline = Date.now() + 12e4;
    });
  } catch (error) {
    throw cancelled != null ? cancelled : error;
  } finally {
    clearInterval(timer);
    controller.abort();
  }
}

// src/api.ts
var ApiError = class extends Error {
  constructor(message, status, responseBody) {
    super(message);
    this.status = status;
    this.responseBody = responseBody;
  }
};
var ApiTransportError = class extends Error {
  constructor(cause) {
    super(cause instanceof Error ? cause.message : "Connection interrupted", { cause });
  }
};
async function transport(request) {
  try {
    return await request();
  } catch (error) {
    throw new ApiTransportError(error);
  }
}
function errorBody(response) {
  try {
    return response.json;
  } catch (e) {
    return null;
  }
}
var CLIENT_VERSION = "0.8.64";
function exactArrayBuffer(bytes2) {
  if (bytes2.buffer instanceof ArrayBuffer && bytes2.byteOffset === 0 && bytes2.byteLength === bytes2.buffer.byteLength) return bytes2.buffer;
  return bytes2.slice().buffer;
}
var GibSyncApi = class {
  constructor(settings, cache) {
    this.settings = settings;
    this.cache = cache;
    __publicField(this, "capabilities", /* @__PURE__ */ new Map());
  }
  url(path, override) {
    return `${(override != null ? override : this.settings().serverUrl).replace(/\/$/, "")}${path}`;
  }
  clientHeaders() {
    return { "X-Gib-Sync-Client-Version": CLIENT_VERSION, "X-Gib-Sync-Protocol": String(PROTOCOL_VERSION) };
  }
  async json(method, path, body, token, server) {
    var _a, _b;
    const response = await transport(() => (0, import_obsidian.requestUrl)({
      url: this.url(path, server),
      method,
      headers: { ...this.clientHeaders(), ...token ? { Authorization: `Bearer ${token}` } : {}, ...body === void 0 ? {} : { "Content-Type": "application/json" } },
      body: body === void 0 ? void 0 : JSON.stringify(body),
      throw: false
    }));
    if (response.status < 200 || response.status >= 300) {
      const body2 = errorBody(response);
      throw new ApiError((_b = (_a = body2 == null ? void 0 : body2.message) != null ? _a : body2 == null ? void 0 : body2.error) != null ? _b : `Gib Sync request failed (${response.status})`, response.status, body2);
    }
    const result = response.json, caps = result == null ? void 0 : result.serverCapabilities;
    if (Array.isArray(caps)) this.capabilities.set((server != null ? server : this.settings().serverUrl).replace(/\/$/, ""), new Set(caps.filter((item) => typeof item === "string")));
    else if (typeof (result == null ? void 0 : result.serverVersion) === "string") this.capabilities.set((server != null ? server : this.settings().serverUrl).replace(/\/$/, ""), /* @__PURE__ */ new Set());
    return result;
  }
  supportsStreamUpload() {
    var _a;
    try {
      if (new URL(this.settings().serverUrl).protocol !== "https:") return false;
    } catch (e) {
      return false;
    }
    return ((_a = this.capabilities.get(this.settings().serverUrl.replace(/\/$/, ""))) == null ? void 0 : _a.has("resumable-content-upload-v1")) === true;
  }
  disableStreamUpload() {
    var _a;
    (_a = this.capabilities.get(this.settings().serverUrl.replace(/\/$/, ""))) == null ? void 0 : _a.delete("resumable-content-upload-v1");
  }
  supportsOperationsV2() {
    var _a;
    return ((_a = this.capabilities.get(this.settings().serverUrl.replace(/\/$/, ""))) == null ? void 0 : _a.has("snapshot-operations-v2")) === true;
  }
  syncTree() {
    return this.json("GET", "/v2/tree", void 0, this.settings().deviceToken);
  }
  operationBatch(batch) {
    return this.json("POST", "/v2/batches", batch, this.settings().deviceToken);
  }
  batchReceipt(id) {
    return this.json("GET", `/v2/batches/${encodeURIComponent(id)}`, void 0, this.settings().deviceToken);
  }
  rolloutStatus() {
    return this.json("GET", "/v2/rollout", void 0, this.settings().deviceToken);
  }
  observeReconciliation(input, baseSnapshotId) {
    return this.json("POST", "/v2/shadow", { baseSnapshotId, ...input }, this.settings().deviceToken);
  }
  declareConfigRoot(configDir) {
    return this.json("POST", "/v2/config-root", { configDir }, this.settings().deviceToken);
  }
  discover(server, seafileUrl, seafileUsername, seafilePassword) {
    return this.json("POST", "/v1/storage/discover", { seafileUrl, seafileUsername, seafilePassword }, void 0, server);
  }
  serverInfo(server) {
    return this.json("GET", "/healthz", void 0, void 0, server);
  }
  setup(server, body) {
    return this.json("POST", "/v1/setup", body, void 0, server);
  }
  async state() {
    var _a, _b, _c;
    const settings = this.settings(), base = settings.lastSnapshotId && await ((_a = this.cache) == null ? void 0 : _a.get(settings.lastSnapshotId, settings.vaultId));
    if (base) {
      try {
        const delta = await this.json("GET", `/v1/delta?since=${encodeURIComponent(base.id)}`, void 0, settings.deviceToken);
        if (delta.baseId !== base.id || delta.snapshot.vaultId !== settings.vaultId) throw new Error("Snapshot delta identity is invalid");
        const entries = new Map(base.entries.map((entry) => [entry.path, entry]));
        for (const path of delta.removed) entries.delete(path);
        for (const entry of delta.changed) entries.set(entry.path, entry);
        const head = { ...delta.snapshot, entries: [...entries.values()].sort((a, b) => a.path.localeCompare(b.path)) };
        await ((_b = this.cache) == null ? void 0 : _b.put(head));
        return { head };
      } catch (error) {
        if (!(error instanceof ApiError && [404, 409].includes(error.status))) throw error;
      }
    }
    const state = await this.json("GET", "/v1/state", void 0, settings.deviceToken);
    if (state.head) await ((_c = this.cache) == null ? void 0 : _c.put(state.head));
    return state;
  }
  headState() {
    return this.json("GET", "/v1/head", void 0, this.settings().deviceToken);
  }
  watch(headId) {
    return this.json("GET", `/v1/watch?head=${encodeURIComponent(headId != null ? headId : "")}`, void 0, this.settings().deviceToken);
  }
  status() {
    return this.json("GET", "/v1/status", void 0, this.settings().deviceToken);
  }
  compatibility() {
    return this.json("GET", "/v1/compatibility", void 0, this.settings().deviceToken);
  }
  async snapshot(id) {
    var _a, _b;
    const settings = this.settings(), cached = await ((_a = this.cache) == null ? void 0 : _a.get(id, settings.vaultId));
    if (cached) return cached;
    const snapshot = await this.json("GET", `/v1/snapshots/${id}`, void 0, settings.deviceToken);
    await ((_b = this.cache) == null ? void 0 : _b.put(snapshot));
    return snapshot;
  }
  history() {
    return this.json("GET", "/v1/history?limit=100", void 0, this.settings().deviceToken);
  }
  async commit(body) {
    var _a;
    const snapshot = await this.json("POST", "/v1/commit", body, this.settings().deviceToken);
    await ((_a = this.cache) == null ? void 0 : _a.put(snapshot));
    return snapshot;
  }
  restorePreview(id) {
    return this.json("GET", `/v1/restore/${id}/preview`, void 0, this.settings().deviceToken);
  }
  restore(id, confirmToken) {
    return this.json("POST", `/v1/restore/${id}`, { confirmToken }, this.settings().deviceToken);
  }
  selectiveRestorePlan(id) {
    return this.json("GET", `/v1/restore/${id}/changes`, void 0, this.settings().deviceToken);
  }
  selectiveRestorePreview(id, changeIds) {
    return this.json("POST", `/v1/restore/${id}/paths/preview`, { changeIds }, this.settings().deviceToken);
  }
  selectiveRestore(id, changeIds, confirmToken) {
    return this.json("POST", `/v1/restore/${id}/paths`, { changeIds, confirmToken }, this.settings().deviceToken);
  }
  safeguards() {
    return this.json("GET", "/v1/safeguards", void 0, this.settings().deviceToken);
  }
  updateSafeguardPolicy(policy) {
    return this.json("PUT", "/v1/safeguards/policy", policy, this.settings().deviceToken);
  }
  setWriteLock(locked) {
    return this.json("POST", "/v1/safeguards/lock", { locked }, this.settings().deviceToken);
  }
  setMaintenance(minutes) {
    return this.json("POST", "/v1/safeguards/maintenance", { minutes }, this.settings().deviceToken);
  }
  quarantines() {
    return this.json("GET", "/v1/quarantines", void 0, this.settings().deviceToken);
  }
  approveQuarantine(id, trustMinutes = 0) {
    return this.json("POST", `/v1/quarantines/${id}/approve`, { trustMinutes }, this.settings().deviceToken);
  }
  rejectQuarantine(id) {
    return this.json("POST", `/v1/quarantines/${id}/reject`, {}, this.settings().deviceToken);
  }
  repairHealth() {
    return this.json("POST", "/v1/health/repair", { restoreAcceptedHead: true }, this.settings().deviceToken);
  }
  markDeviceReady(headId) {
    return this.json("POST", "/v1/devices/current/ready", { headId }, this.settings().deviceToken);
  }
  revokeDevice(id) {
    return this.json("POST", `/v1/devices/${id}/revoke`, {}, this.settings().deviceToken);
  }
  bookmark(id, label = "Known good") {
    return this.json("PUT", `/v1/bookmarks/${id}`, { label }, this.settings().deviceToken);
  }
  unbookmark(id) {
    return this.json("DELETE", `/v1/bookmarks/${id}`, void 0, this.settings().deviceToken);
  }
  mirrorPlan(snapshotId, entries) {
    return this.json("POST", "/v1/mirror/plan", { snapshotId, entries }, this.settings().deviceToken);
  }
  mirrorComplete(snapshotId) {
    return this.json("POST", "/v1/mirror/complete", { snapshotId }, this.settings().deviceToken);
  }
  async createPairing() {
    const pairing = await this.json("POST", "/v1/pairings", { requireConfirmation: true }, this.settings().deviceToken);
    if (pairing.requiresConfirmation !== true) throw new Error("The server must be updated before secure quick-code setup is available. Existing synchronization is unaffected.");
    return pairing;
  }
  claimQuickCode(server, code, deviceName) {
    return this.json("POST", "/v1/pairings/claim-code", { code, deviceName }, void 0, server);
  }
  pendingDeviceClaims() {
    return this.json("GET", "/v1/pairings/pending", void 0, this.settings().deviceToken);
  }
  decideDeviceClaim(id, approved) {
    return this.json("POST", `/v1/pairings/requests/${encodeURIComponent(id)}/decision`, { approved }, this.settings().deviceToken);
  }
  pollDeviceClaim(server, ticket) {
    return this.json("POST", "/v1/pairings/poll", { ticket }, void 0, server);
  }
  cancelDeviceClaim(server, ticket) {
    return this.json("POST", "/v1/pairings/cancel-claim", { ticket }, void 0, server);
  }
  async conflictInbox() {
    const records2 = [];
    for (let offset = 0; offset < 1e6; offset += 500) {
      const page = await this.json("GET", `/v1/conflicts?offset=${offset}`, void 0, this.settings().deviceToken);
      records2.push(...page);
      if (page.length < 500) return records2;
    }
    throw new Error("Conflict history exceeded its retrieval budget; preserved records were not changed.");
  }
  async publishConflicts(records2) {
    for (let offset = 0; offset < records2.length; offset += 50) await this.json("POST", "/v1/conflicts", { records: records2.slice(offset, offset + 50) }, this.settings().deviceToken);
    return { ok: true };
  }
  recordConflictResolution(id, batchId, choice, after, before) {
    return this.json("POST", `/v1/conflicts/${encodeURIComponent(id)}/resolution`, { batchId, choice, after, before }, this.settings().deviceToken);
  }
  recordConflictUndo(id, batchId, resolutionId) {
    return this.json("POST", `/v1/conflicts/${encodeURIComponent(id)}/undo`, { batchId, resolutionId }, this.settings().deviceToken);
  }
  async getBlob(hash) {
    const response = await transport(() => (0, import_obsidian.requestUrl)({ url: this.url(`/v1/blobs/${hash}`), method: "GET", headers: { ...this.clientHeaders(), Authorization: `Bearer ${this.settings().deviceToken}` }, throw: false }));
    if (response.status !== 200) throw new ApiError(`Blob download failed (${response.status})`, response.status, null);
    return new Uint8Array(response.arrayBuffer);
  }
  async getContent(hash, expectedSize) {
    const response = await transport(() => fetch(this.url(`/v1/content/${hash}`), { method: "GET", headers: { ...this.clientHeaders(), Authorization: `Bearer ${this.settings().deviceToken}` }, cache: "no-store" }));
    if (!response.ok) throw new ApiError(`Large-file download failed (${response.status})`, response.status, null);
    if (response.headers.get("x-content-sha256") !== hash) throw new Error("Large-file integrity header is missing or invalid");
    if (expectedSize !== void 0 && (!Number.isSafeInteger(expectedSize) || expectedSize < 0)) throw new Error("Large-file manifest size is invalid");
    if (!response.body || expectedSize === void 0) {
      const bytes3 = new Uint8Array(await transport(() => response.arrayBuffer()));
      if (expectedSize !== void 0 && bytes3.byteLength !== expectedSize) throw new Error("Large-file response size does not match the manifest");
      if (await hashBytes(bytes3) !== hash) throw new Error("Large-file content integrity check failed");
      return bytes3;
    }
    const bytes2 = new Uint8Array(expectedSize), reader = response.body.getReader();
    let offset = 0;
    try {
      for (; ; ) {
        const { done, value } = await transport(() => reader.read());
        if (done) break;
        if (offset + value.byteLength > bytes2.byteLength) throw new Error("Large-file response exceeded its declared size");
        bytes2.set(value, offset);
        offset += value.byteLength;
      }
    } catch (error) {
      await reader.cancel().catch(() => {
      });
      throw error;
    } finally {
      reader.releaseLock();
    }
    if (offset !== bytes2.byteLength) throw new Error(`Large-file response ended early (${offset} of ${bytes2.byteLength} bytes)`);
    if (await hashBytes(bytes2) !== hash) throw new Error("Large-file content integrity check failed");
    return bytes2;
  }
  /** Only a verified private stage may be promoted after this returns. */
  async streamContent(hash, expectedSize, onChunk, checkpoint) {
    if (!/^[a-f0-9]{64}$/.test(hash) || !Number.isSafeInteger(expectedSize) || expectedSize < 0) throw new Error("Large-file manifest is invalid");
    return controlledIo(checkpoint, async (signal, touch) => {
      var _a, _b;
      checkpoint();
      const response = await transport(() => fetch(this.url(`/v1/content/${hash}`), { method: "GET", headers: { ...this.clientHeaders(), Authorization: `Bearer ${this.settings().deviceToken}` }, cache: "no-store", signal }));
      try {
        checkpoint();
        if (!response.ok) throw new ApiError(`Large-file download failed (${response.status})`, response.status, null);
        if (response.headers.get("x-content-sha256") !== hash) throw new Error("Large-file integrity header is missing or invalid");
        if (!response.body) throw new Error("This device cannot stream the file response");
        const reader = response.body.getReader(), digest = sha256.create();
        let size = 0;
        try {
          for (; ; ) {
            checkpoint();
            const { done, value } = await transport(() => reader.read());
            touch();
            checkpoint();
            if (done) break;
            if (size + value.byteLength > expectedSize) throw new Error("Large-file response exceeded its declared size");
            for (let offset = 0; offset < value.byteLength; offset += 64 * 1024) {
              checkpoint();
              const chunk = value.subarray(offset, offset + 64 * 1024);
              digest.update(chunk);
              await onChunk(chunk);
              size += chunk.byteLength;
            }
          }
          if (size !== expectedSize) throw new Error(`Large-file response ended early (${size} of ${expectedSize} bytes)`);
          if (bytesToHex(digest.digest()) !== hash) throw new Error("Large-file content integrity check failed");
          checkpoint();
        } catch (error) {
          await reader.cancel().catch(() => {
          });
          throw error;
        } finally {
          reader.releaseLock();
          digest.destroy();
        }
      } catch (error) {
        if (!((_a = response.body) == null ? void 0 : _a.locked)) await ((_b = response.body) == null ? void 0 : _b.cancel().catch(() => {
        }));
        throw error;
      }
    });
  }
  async putBlob(hash, bytes2) {
    const body = exactArrayBuffer(bytes2);
    const response = await transport(() => (0, import_obsidian.requestUrl)({ url: this.url(`/v1/blobs/${hash}`), method: "PUT", headers: { ...this.clientHeaders(), Authorization: `Bearer ${this.settings().deviceToken}`, "Content-Type": "application/octet-stream" }, body, throw: false }));
    if (response.status < 200 || response.status >= 300) throw new ApiError(`Blob upload failed (${response.status})`, response.status, response.text);
  }
  async uploadRequest(path, method, body, signal, chunkHash) {
    var _a, _b;
    const response = await transport(() => fetch(this.url(path), { method, headers: { ...this.clientHeaders(), Authorization: `Bearer ${this.settings().deviceToken}`, "Content-Type": chunkHash ? "application/octet-stream" : "application/json", ...chunkHash ? { "X-Chunk-SHA256": chunkHash } : {} }, body, signal, cache: "no-store" }));
    let result;
    try {
      result = await response.json();
    } catch (e) {
    }
    if (!response.ok) throw new ApiError((_b = (_a = result == null ? void 0 : result.message) != null ? _a : result == null ? void 0 : result.error) != null ? _b : `Content upload failed (${response.status})`, response.status, result);
    return result;
  }
  beginContentUpload(hash, size, signal) {
    return this.uploadRequest("/v1/content-uploads", "POST", JSON.stringify({ hash, size }), signal);
  }
  putContentUploadChunk(id, index, bytes2, hash, signal) {
    return this.uploadRequest(`/v1/content-uploads/${encodeURIComponent(id)}/chunks/${index}`, "PUT", exactArrayBuffer(bytes2), signal, hash);
  }
  completeContentUpload(id, signal) {
    return this.uploadRequest(`/v1/content-uploads/${encodeURIComponent(id)}/complete`, "POST", "{}", signal);
  }
  cancelContentUpload(id, processingId, signal) {
    return this.uploadRequest(`/v1/content-uploads/${encodeURIComponent(id)}/cancel`, "POST", JSON.stringify({ processingId }), signal);
  }
  async putMirrorFile(snapshotId, path, hash, bytes2) {
    const response = await transport(() => (0, import_obsidian.requestUrl)({ url: this.url(`/v1/mirror/file?path=${encodeURIComponent(path)}`), method: "PUT", headers: { ...this.clientHeaders(), Authorization: `Bearer ${this.settings().deviceToken}`, "Content-Type": "application/octet-stream", "X-Gib-Sync-Snapshot": snapshotId, "X-Gib-Sync-Hash": hash }, body: exactArrayBuffer(bytes2), throw: false }));
    if (response.status < 200 || response.status >= 300) throw new ApiError(`Readable mirror upload failed for ${path} (${response.status})`, response.status, errorBody(response));
  }
};

// src/sync-recovery.ts
function isTransientSyncError(error) {
  return error instanceof ApiTransportError || error instanceof ApiError && [408, 409, 429, 500, 502, 503, 504].includes(error.status);
}
var SyncCancelledError = class extends Error {
};
async function recoverSync(operation, options) {
  const delays = [2e3, 5e3, 1e4];
  for (let attempt = 0; ; attempt++) {
    if (!options.shouldContinue()) throw new SyncCancelledError("Sync paused");
    try {
      return await operation();
    } catch (error) {
      if (!isTransientSyncError(error) || attempt >= delays.length) throw error;
      options.onRetry(error, attempt + 1, delays[attempt]);
      await options.wait(delays[attempt]);
    }
  }
}

// src/engine.ts
var import_obsidian2 = require("obsidian");

// src/settings.ts
var DEFAULT_SETTINGS = {
  packageHolds: {},
  configDir: ".obsidian",
  onboardingMode: "preserve-local",
  pendingMoves: [],
  fileCreationTimes: {},
  observedFolderSnapshotId: null,
  serverUrl: "",
  vaultId: "",
  vaultName: "",
  vaultKey: "",
  deviceId: "",
  deviceName: "",
  deviceToken: "",
  lastSnapshotId: null,
  initialized: false,
  autoSync: true,
  instantReceive: true,
  syncOnFileChange: true,
  paused: false,
  syncIntervalSeconds: 60,
  syncBookmarks: true,
  syncObsidianConfig: false,
  syncPlugins: false,
  pluginSyncBootstrapPending: false,
  desktopStatusIcon: true,
  desktopStatusText: true,
  mobileSidebarIndicator: true,
  mobileTopIndicator: false,
  animateStatusIndicator: true,
  showAttentionBadge: true,
  exclusions: [".trash/", ".git/", ".obsidian/plugins/gib-sync/"],
  vaultIdentity: "",
  pendingPaths: [],
  pendingPathTimes: {},
  pendingApplyPaths: [],
  pendingApplySnapshotId: null,
  pendingApplyBaseSnapshotId: null,
  pendingApplyPriorHashes: {},
  retiredPaths: {},
  folderCreateTimes: {},
  folderCleanupVersion: 5,
  lastFolderCleanupAt: 0,
  lastFolderCleanupError: "",
  retiredFolderCount: 0,
  retiredFolderNote: "",
  fullScanRequired: true,
  lastFullScanAt: null,
  pendingCommit: null,
  pendingApplyOperations: {},
  pendingApplyPriorEntries: {},
  localReconcileBases: {},
  storage: null,
  lastSuccessAt: null,
  lastErrorAt: null,
  lastError: "",
  lastResult: ""
};
var initialLiveStatus = (configured) => ({
  phase: configured ? "idle" : "not-configured",
  message: configured ? "Ready" : "Not configured",
  running: false,
  startedAt: null,
  completedAt: null,
  lastSuccessAt: null,
  lastErrorAt: null,
  lastError: "",
  lastResult: "",
  nextSyncAt: null,
  activities: []
});
function createSerializedSettingsWriter(read, write) {
  let tail = Promise.resolve();
  return () => {
    const queued = tail.catch(() => void 0).then(async () => {
      const snapshot = JSON.parse(JSON.stringify(read()));
      await write(snapshot);
    });
    tail = queued;
    return queued;
  };
}
async function loadSettings(plugin) {
  var _a, _b, _c;
  const stored = await plugin.loadData();
  const settings = Object.assign({}, DEFAULT_SETTINGS, stored != null ? stored : {});
  settings.packageHolds = (stored == null ? void 0 : stored.packageHolds) && typeof stored.packageHolds === "object" && !Array.isArray(stored.packageHolds) ? Object.fromEntries(Object.entries(stored.packageHolds).filter(([id, hold]) => /^[a-z0-9._-]+$/i.test(id) && hold && typeof hold.reason === "string" && typeof hold.at === "number" && Number.isFinite(hold.at)).map(([id, hold]) => [id, { reason: hold.reason.slice(0, 500), at: hold.at }])) : {};
  settings.configDir = normalizedConfigDir(typeof (stored == null ? void 0 : stored.configDir) === "string" ? stored.configDir : ".obsidian");
  settings.onboardingMode = (stored == null ? void 0 : stored.onboardingMode) === "server-first" ? "server-first" : "preserve-local";
  settings.pendingMoves = Array.isArray(stored == null ? void 0 : stored.pendingMoves) ? stored.pendingMoves.filter((move) => move && typeof move.from === "string" && isSafeVaultPath(move.from) && typeof move.to === "string" && isSafeVaultPath(move.to) && typeof move.at === "number" && Number.isFinite(move.at) && move.at > 0) : [];
  settings.fileCreationTimes = (stored == null ? void 0 : stored.fileCreationTimes) && typeof stored.fileCreationTimes === "object" && !Array.isArray(stored.fileCreationTimes) ? Object.fromEntries(Object.entries(stored.fileCreationTimes).filter(([path, time]) => Boolean(path) && typeof time === "number" && Number.isFinite(time) && time > 0)) : {};
  settings.observedFolderSnapshotId = typeof (stored == null ? void 0 : stored.observedFolderSnapshotId) === "string" ? stored.observedFolderSnapshotId : null;
  if ((stored == null ? void 0 : stored.syncPlugins) === void 0 && (stored == null ? void 0 : stored.syncObsidianConfig) === true) settings.syncPlugins = true;
  settings.pluginSyncBootstrapPending = settings.syncPlugins && ((stored == null ? void 0 : stored.pluginSyncBootstrapPending) === true || (stored == null ? void 0 : stored.pluginSyncBootstrapPending) === void 0);
  settings.pendingPaths = Array.isArray(stored == null ? void 0 : stored.pendingPaths) ? [...new Set(stored.pendingPaths.filter((path) => typeof path === "string" && isSafeVaultPath(path)))] : [];
  settings.pendingPathTimes = (stored == null ? void 0 : stored.pendingPathTimes) && typeof stored.pendingPathTimes === "object" && !Array.isArray(stored.pendingPathTimes) ? Object.fromEntries(Object.entries(stored.pendingPathTimes).filter(([path, time]) => Boolean(path) && typeof time === "number" && Number.isFinite(time) && time > 0)) : {};
  settings.pendingApplyPaths = Array.isArray(stored == null ? void 0 : stored.pendingApplyPaths) ? [...new Set(stored.pendingApplyPaths.filter((path) => typeof path === "string" && isSafeVaultPath(path)))] : [];
  settings.pendingApplySnapshotId = typeof (stored == null ? void 0 : stored.pendingApplySnapshotId) === "string" && stored.pendingApplySnapshotId ? stored.pendingApplySnapshotId : null;
  settings.pendingApplyBaseSnapshotId = typeof (stored == null ? void 0 : stored.pendingApplyBaseSnapshotId) === "string" && stored.pendingApplyBaseSnapshotId ? stored.pendingApplyBaseSnapshotId : null;
  settings.pendingApplyPriorHashes = (stored == null ? void 0 : stored.pendingApplyPriorHashes) && typeof stored.pendingApplyPriorHashes === "object" && !Array.isArray(stored.pendingApplyPriorHashes) ? Object.fromEntries(Object.entries(stored.pendingApplyPriorHashes).filter(([path, hash]) => isSafeVaultPath(path) && (hash === null || typeof hash === "string" && /^[a-f0-9]{64}$/i.test(hash)))) : {};
  const commit = stored == null ? void 0 : stored.pendingCommit;
  const validEntries = (value) => value && typeof value === "object" && !Array.isArray(value) ? Object.fromEntries(Object.entries(value).filter(([path, entry]) => isSafeVaultPath(path) && entry && typeof entry === "object" && entry.path === path && typeof entry.hash === "string" && /^[a-f0-9]{64}$/i.test(entry.hash) && typeof entry.size === "number" && Number.isSafeInteger(entry.size) && entry.size >= 0 && typeof entry.mtime === "number" && Number.isFinite(entry.mtime)).map(([path, entry]) => {
    const revision = entry.revision, validRevision = revision && typeof revision === "object" && typeof revision.id === "string" && (revision.parentId === null || typeof revision.parentId === "string") && typeof revision.deviceId === "string" && typeof revision.deviceName === "string" && typeof revision.modifiedAt === "number" && Number.isFinite(revision.modifiedAt);
    return [path, { path, hash: entry.hash, size: entry.size, mtime: entry.mtime, ...typeof entry.fileId === "string" ? { fileId: entry.fileId } : {}, ...validRevision ? { revision: { id: revision.id, parentId: revision.parentId, deviceId: revision.deviceId, deviceName: revision.deviceName, modifiedAt: revision.modifiedAt } } : {} }];
  })) : {};
  settings.pendingApplyPriorEntries = validEntries(stored == null ? void 0 : stored.pendingApplyPriorEntries);
  for (const [id, hold] of Object.entries(settings.packageHolds)) {
    const saved = (_a = stored == null ? void 0 : stored.packageHolds) == null ? void 0 : _a[id];
    if (!saved) continue;
    if (saved.kind === "incomplete" || saved.kind === "activation") hold.kind = saved.kind;
    if (Number.isSafeInteger(saved.attempts) && saved.attempts >= 0) hold.attempts = saved.attempts;
    if (typeof saved.retryAt === "number" && Number.isFinite(saved.retryAt) && saved.retryAt >= 0) hold.retryAt = saved.retryAt;
    if (typeof saved.fingerprint === "string" && /^[a-f0-9]{64}$/.test(saved.fingerprint)) hold.fingerprint = saved.fingerprint;
    const entries = validEntries(saved.priorEntries);
    for (const [path, entry] of Object.entries(entries)) {
      const source = (_c = (_b = saved.priorEntries) == null ? void 0 : _b[path]) == null ? void 0 : _c.sourcePath;
      if (typeof source === "string" && /^\.gib-sync\/package-hold-originals\/[0-9a-f-]{36}\.bin$/.test(source)) entry.sourcePath = source;
    }
    if (Object.keys(entries).length) hold.priorEntries = entries;
  }
  const operations = stored == null ? void 0 : stored.pendingApplyOperations;
  settings.pendingApplyOperations = operations && typeof operations === "object" && !Array.isArray(operations) ? Object.fromEntries(Object.entries(operations).filter(([path, operation]) => isSafeVaultPath(path) && operation && typeof operation === "object" && (!operation.namespacePath || isSafeVaultPath(operation.namespacePath)) && (operation.targetHash === null || typeof operation.targetHash === "string" && /^[a-f0-9]{64}$/i.test(operation.targetHash)) && (operation.priorHash === null || typeof operation.priorHash === "string" && /^[a-f0-9]{64}$/i.test(operation.priorHash)) && typeof operation.stagePath === "string" && /^\.gib-sync\/apply\/[a-f0-9]{64}\.stage$/.test(operation.stagePath) && typeof operation.backupPath === "string" && /^\.gib-sync\/apply\/[a-f0-9]{64}\.backup$/.test(operation.backupPath) && ["planned", "staged", "backed-up", "promoting", "applied"].includes(operation.phase))) : {};
  const replay = stored == null ? void 0 : stored.localReconcileBases;
  settings.localReconcileBases = { ...validEntries(replay), ...Object.fromEntries(Object.entries(replay && typeof replay === "object" && !Array.isArray(replay) ? replay : {}).filter(([path, entry]) => isSafeVaultPath(path) && entry === null)) };
  settings.pendingCommit = commit && (commit.parentId === null || typeof commit.parentId === "string" && Boolean(commit.parentId)) && typeof commit.fingerprint === "string" && /^[a-f0-9]{64}$/i.test(commit.fingerprint) && commit.priorHashes && typeof commit.priorHashes === "object" && !Array.isArray(commit.priorHashes) ? { parentId: commit.parentId, fingerprint: commit.fingerprint, priorHashes: Object.fromEntries(Object.entries(commit.priorHashes).filter(([path, hash]) => isSafeVaultPath(path) && (hash === null || typeof hash === "string" && /^[a-f0-9]{64}$/i.test(hash)))), ...commit.priorEntries ? { priorEntries: validEntries(commit.priorEntries) } : {}, ...Number.isSafeInteger(commit.intentSequence) && commit.intentSequence >= 0 ? { intentSequence: commit.intentSequence } : {} } : null;
  settings.retiredPaths = (stored == null ? void 0 : stored.retiredPaths) && typeof stored.retiredPaths === "object" && !Array.isArray(stored.retiredPaths) ? Object.fromEntries(Object.entries(stored.retiredPaths).filter(([path, value]) => Boolean(path) && Boolean(value) && typeof value === "object" && typeof value.hash === "string" && /^[a-f0-9]{64}$/i.test(value.hash) && typeof value.snapshotId === "string" && Boolean(value.snapshotId) && typeof value.retiredAt === "number" && Number.isFinite(value.retiredAt) && value.retiredAt > 0)) : {};
  settings.folderCreateTimes = (stored == null ? void 0 : stored.folderCreateTimes) && typeof stored.folderCreateTimes === "object" && !Array.isArray(stored.folderCreateTimes) ? Object.fromEntries(Object.entries(stored.folderCreateTimes).filter(([path, value]) => Boolean(path) && typeof value === "number" && Number.isFinite(value) && value > 0)) : {};
  const currentFolderCleanup = (stored == null ? void 0 : stored.folderCleanupVersion) === 5;
  settings.folderCleanupVersion = 5;
  settings.lastFolderCleanupAt = currentFolderCleanup && typeof (stored == null ? void 0 : stored.lastFolderCleanupAt) === "number" && Number.isFinite(stored.lastFolderCleanupAt) && stored.lastFolderCleanupAt > 0 ? stored.lastFolderCleanupAt : 0;
  settings.lastFolderCleanupError = typeof (stored == null ? void 0 : stored.lastFolderCleanupError) === "string" ? stored.lastFolderCleanupError.slice(0, 2e3) : "";
  settings.retiredFolderCount = currentFolderCleanup && typeof (stored == null ? void 0 : stored.retiredFolderCount) === "number" && Number.isInteger(stored.retiredFolderCount) && stored.retiredFolderCount > 0 ? stored.retiredFolderCount : 0;
  settings.retiredFolderNote = currentFolderCleanup && typeof (stored == null ? void 0 : stored.retiredFolderNote) === "string" ? stored.retiredFolderNote.slice(0, 2e3) : "";
  return settings;
}
function normalizedConfigDir(configDir = ".obsidian") {
  const normalized = configDir.replace(/\\/g, "/").replace(/^\/+|\/+$/g, "");
  return isSafeVaultPath(normalized) ? normalized : ".obsidian";
}
function canonicalConfigPath(path, configDir = ".obsidian") {
  const normalized = path.replace(/\\/g, "/").replace(/^\/+/, "");
  const root2 = normalizedConfigDir(configDir);
  return normalized.toLowerCase() === root2.toLowerCase() ? ".obsidian" : normalized.toLowerCase().startsWith(`${root2.toLowerCase()}/`) ? `.obsidian/${normalized.slice(root2.length + 1)}` : normalized;
}
function isDeviceLocalWorkspacePath(path, configDir = ".obsidian") {
  return /^\.obsidian\/workspace(?:-[^/]+)?\.json$/i.test(canonicalConfigPath(path, configDir));
}
function obsidianPluginPath(path, configDir = ".obsidian") {
  var _a;
  const normalized = canonicalConfigPath(path, configDir);
  const match = /^\.obsidian\/plugins\/([^/]+)(?:\/(.*))?$/i.exec(normalized);
  return match ? { id: match[1], relative: (_a = match[2]) != null ? _a : "" } : null;
}
function isPluginDataPath(path, configDir = ".obsidian") {
  var _a;
  return ((_a = obsidianPluginPath(path, configDir)) == null ? void 0 : _a.relative.toLowerCase()) === "data.json";
}
function isGeneratedPluginPath(path, configDir = ".obsidian") {
  const plugin = obsidianPluginPath(path, configDir);
  if (!plugin) return false;
  const generatedFolders = /* @__PURE__ */ new Set([".cache", "cache", "caches", "embeddings", "index-data", "indexes", "logs", "node_modules", "search-index", "temp", "tmp"]);
  return plugin.relative.split("/").some((segment) => generatedFolders.has(segment.toLowerCase())) || /\.(?:log|tmp)$/i.test(plugin.relative);
}
function isLegacyObsidianConflictPath(path, configDir = ".obsidian") {
  const normalized = canonicalConfigPath(path, configDir);
  return normalized.toLowerCase().startsWith(".obsidian/") && isGibSyncConflictPath(normalized);
}
function isGibSyncConflictPath(path) {
  const normalized = path.replace(/\\/g, "/").replace(/^\/+/g, "");
  return / \(conflict - .+ - \d{4}-\d{2}-\d{2} \d{2}-\d{2}-\d{2} UTC(?: - \d+)?\)(?:\.[^/]+)?$/i.test(normalized);
}
function isDeviceLocalObsidianPath(path, configDir = ".obsidian") {
  return isDeviceLocalWorkspacePath(path, configDir) || isGeneratedPluginPath(path, configDir) || isLegacyObsidianConflictPath(path, configDir);
}
function isObsidianSystemPath(path, configDir = ".obsidian") {
  return canonicalConfigPath(path, configDir).toLowerCase().startsWith(".obsidian/");
}
function shouldSyncChangedPath(path, settings) {
  if (!isSafeVaultPath(path)) return false;
  const actual = path.replace(/\\/g, "/").replace(/^\/+/, ""), normalized = canonicalConfigPath(actual, settings.configDir).toLowerCase();
  if (!normalized || normalized === ".gib-sync" || normalized.startsWith(".gib-sync/") || normalized === ".trash" || normalized.startsWith(".trash/")) return false;
  if (normalized === ".obsidian/plugins/gib-sync" || normalized.startsWith(".obsidian/plugins/gib-sync/")) return false;
  if (/^\.obsidian\/plugins\/\.gib-sync-package-[0-9a-f-]+\.(?:stage|original|probe)(?:\/|$)/i.test(normalized)) return false;
  if (isDeviceLocalObsidianPath(normalized)) return false;
  if (normalized === ".obsidian/core-plugins.json") return false;
  const obsidianRoot = normalized === ".obsidian";
  const bookmarks = normalized.toLowerCase() === ".obsidian/bookmarks.json";
  const pluginPath = normalized === ".obsidian/plugins" || normalized.startsWith(".obsidian/plugins/") || normalized === ".obsidian/community-plugins.json";
  if (obsidianRoot && !settings.syncBookmarks && !settings.syncObsidianConfig && !settings.syncPlugins) return false;
  if (bookmarks && !settings.syncBookmarks) return false;
  if (pluginPath && !settings.syncPlugins) return false;
  if (!bookmarks && !pluginPath && !obsidianRoot && !settings.syncObsidianConfig && normalized.startsWith(".obsidian/")) return false;
  return !settings.exclusions.some((prefix) => {
    const excluded = prefix.replace(/\\/g, "/").replace(/^\/+/, "").replace(/\/+$/, "");
    const canonicalExcluded = canonicalConfigPath(excluded, settings.configDir).toLowerCase();
    return Boolean(excluded) && (actual.toLowerCase() === excluded.toLowerCase() || actual.toLowerCase().startsWith(`${excluded.toLowerCase()}/`) || normalized === canonicalExcluded || normalized.startsWith(`${canonicalExcluded}/`));
  });
}
function isSafeVaultPath(path) {
  const normalized = path.replace(/\\/g, "/").replace(/\/+$/, "");
  return Boolean(normalized) && !normalized.startsWith("/") && !/^[a-z]:/i.test(normalized) && !normalized.includes("\0") && !normalized.split("/").some((part) => !part || part === "." || part === "..");
}

// src/system-merge.ts
function stringArray(text) {
  const value = JSON.parse(text);
  if (!Array.isArray(value) || value.some((item) => typeof item !== "string")) throw new Error("Expected an array of plugin ids");
  return [...new Set(value)];
}
function mergeCommunityPluginEnablement(baseText, localText, remoteText, preferred, desktopOnlyIds, mobile) {
  try {
    const base = stringArray(baseText), local = stringArray(localText), remote = stringArray(remoteText), baseSet = new Set(base), localSet = new Set(local), remoteSet = new Set(remote);
    const ids = /* @__PURE__ */ new Set([...base, ...local, ...remote]), enabled = /* @__PURE__ */ new Set();
    let protectedDesktopOnly = 0;
    for (const id of ids) {
      const b = baseSet.has(id), l = localSet.has(id), r = remoteSet.has(id);
      let keep;
      if (mobile && desktopOnlyIds.has(id)) {
        keep = r;
        if (l !== r) protectedDesktopOnly++;
      } else keep = l === r ? l : l === b ? r : r === b ? l : preferred === "local" ? l : r;
      if (keep) enabled.add(id);
    }
    const order = preferred === "local" ? [...local, ...remote, ...base] : [...remote, ...local, ...base], merged = [...new Set(order)].filter((id) => enabled.has(id));
    return { text: `${JSON.stringify(merged, null, 2)}
`, semantic: true, overlaps: 0, reason: protectedDesktopOnly ? `preserved ${protectedDesktopOnly} desktop-only plugin state${protectedDesktopOnly === 1 ? "" : "s"} from the server; compatible plugin toggles combined normally` : "plugin enablement changes combined by plugin id" };
  } catch (e) {
    return mergeSystemJson(baseText, localText, remoteText, preferred);
  }
}
function mergeSystemJson(baseText, localText, remoteText, preferred, schema) {
  try {
    const { value, overlaps } = mergeJsonValues(JSON.parse(baseText), JSON.parse(localText), JSON.parse(remoteText), preferred === "local", schema);
    return { text: `${JSON.stringify(value, null, 2)}
`, semantic: true, overlaps, reason: overlaps ? `${overlaps} overlapping setting value${overlaps === 1 ? "" : "s"} used the newer ${preferred} version` : "independent setting keys and stable-id records combined" };
  } catch (e) {
    return { text: preferred === "local" ? localText : remoteText, semantic: false, overlaps: 1, reason: `invalid or non-standard JSON used the newer ${preferred} whole file` };
  }
}

// src/body-cache.ts
var BodyCache = class extends Map {
  constructor(budgetBytes) {
    super();
    this.budgetBytes = budgetBytes;
    __publicField(this, "retained", 0);
  }
  get(key) {
    const value = super.get(key);
    if (value) {
      super.delete(key);
      super.set(key, value);
    }
    return value;
  }
  set(key, value) {
    this.delete(key);
    if (value.byteLength > this.budgetBytes) return this;
    while (this.retained + value.byteLength > this.budgetBytes) {
      const oldest = this.keys().next().value;
      if (oldest === void 0) break;
      this.delete(oldest);
    }
    super.set(key, value);
    this.retained += value.byteLength;
    return this;
  }
  delete(key) {
    const value = super.get(key);
    if (!value) return false;
    this.retained -= value.byteLength;
    return super.delete(key);
  }
  clear() {
    super.clear();
    this.retained = 0;
  }
  get retainedBytes() {
    return this.retained;
  }
};

// src/file-io.ts
var AdapterFileChangedError = class extends Error {
  constructor(path) {
    super(`${path} changed while its content was being verified.`);
    this.path = path;
    __publicField(this, "name", "AdapterFileChangedError");
  }
};
async function streamAdapterFile(adapter, path, expectedHash, expectedSize, onChunk, checkpoint, cooperate) {
  const before = await adapter.stat(path);
  checkpoint();
  if ((before == null ? void 0 : before.type) !== "file" || before.size !== expectedSize) throw new AdapterFileChangedError(path);
  const resource = adapter.getResourcePath;
  if (typeof resource !== "function") {
    if (expectedSize >= 8 * 1024 * 1024) throw new Error("This adapter cannot safely stream this large file; it remains local and sync will retry.");
    const bytes2 = new Uint8Array(await adapter.readBinary(path));
    checkpoint();
    if (bytes2.length !== expectedSize || await hashBytes(bytes2) !== expectedHash) throw new AdapterFileChangedError(path);
    for (let offset = 0; offset < bytes2.length; offset += 64 * 1024) {
      await onChunk(bytes2.subarray(offset, offset + 64 * 1024));
      await cooperate();
    }
    const after = await adapter.stat(path);
    checkpoint();
    if ((after == null ? void 0 : after.type) !== "file" || after.size !== before.size || after.mtime !== before.mtime || after.ctime !== before.ctime) throw new AdapterFileChangedError(path);
    return;
  }
  await controlledIo(checkpoint, async (signal, touch) => {
    const response = await fetch(resource.call(adapter, path), { signal, cache: "no-store" });
    checkpoint();
    if (!response.ok || !response.body) throw new Error("This adapter could not stream the saved file safely; it was left unchanged.");
    const reader = response.body.getReader(), digest = sha256.create();
    let size = 0;
    const cancel = () => {
      void reader.cancel().catch(() => {
      });
    };
    signal.addEventListener("abort", cancel, { once: true });
    try {
      for (; ; ) {
        checkpoint();
        const { done, value } = await reader.read();
        checkpoint();
        if (done) break;
        touch();
        if (size + value.byteLength > expectedSize) throw new AdapterFileChangedError(path);
        for (let offset = 0; offset < value.length; offset += 64 * 1024) {
          const chunk = value.subarray(offset, offset + 64 * 1024);
          digest.update(chunk);
          size += chunk.length;
          await onChunk(chunk);
          await cooperate();
        }
      }
      const after = await adapter.stat(path);
      checkpoint();
      if (size !== expectedSize || bytesToHex(digest.digest()) !== expectedHash || (after == null ? void 0 : after.type) !== "file" || after.size !== before.size || after.mtime !== before.mtime || after.ctime !== before.ctime) throw new AdapterFileChangedError(path);
    } finally {
      signal.removeEventListener("abort", cancel);
      digest.destroy();
      await reader.cancel().catch(() => {
      });
      reader.releaseLock();
    }
  });
}
async function hashAdapterFile(adapter, path, checkpoint, cooperate, allowBufferedFallback = true) {
  const before = await adapter.stat(path);
  checkpoint();
  if (!before || before.type !== "file") throw new AdapterFileChangedError(path);
  const verify = async (hash, size) => {
    const after = await adapter.stat(path);
    checkpoint();
    if (!after || after.type !== "file" || before.size !== size || after.size !== size || before.mtime !== after.mtime || before.ctime !== after.ctime) throw new AdapterFileChangedError(path);
    return hash;
  };
  const resource = adapter.getResourcePath;
  if (typeof resource === "function" && typeof fetch === "function") {
    const result = await controlledIo(checkpoint, async (signal, touch) => {
      var _a;
      let response;
      try {
        response = await fetch(resource.call(adapter, path), { signal, cache: "no-store" });
      } catch (error) {
        if (signal.aborted) throw error;
      }
      checkpoint();
      if ((response == null ? void 0 : response.ok) && response.body) {
        const hash = sha256.create(), reader = response.body.getReader();
        let size = 0;
        const cancel = () => {
          void reader.cancel().catch(() => void 0);
        };
        signal.addEventListener("abort", cancel, { once: true });
        try {
          for (; ; ) {
            checkpoint();
            const { done, value } = await reader.read();
            checkpoint();
            if (done) break;
            touch();
            size += value.byteLength;
            if (size > before.size) throw new AdapterFileChangedError(path);
            for (let offset = 0; offset < value.byteLength; offset += 64 * 1024) {
              hash.update(value.subarray(offset, offset + 64 * 1024));
              await cooperate();
            }
          }
          return await verify(bytesToHex(hash.digest()), size);
        } finally {
          signal.removeEventListener("abort", cancel);
          hash.destroy();
          await reader.cancel().catch(() => void 0);
          reader.releaseLock();
        }
      }
      await ((_a = response == null ? void 0 : response.body) == null ? void 0 : _a.cancel().catch(() => {
      }));
      return null;
    });
    if (result !== null) return result;
  }
  if (!allowBufferedFallback) throw new Error("This adapter cannot safely stream this large file; it remains local and sync will retry. Update Obsidian or use a native filesystem vault.");
  checkpoint();
  const bytes2 = new Uint8Array(await adapter.readBinary(path));
  checkpoint();
  return verify(await hashBytes(bytes2), bytes2.byteLength);
}

// src/outbound-stream.ts
var CHUNK_BYTES = 256 * 1024;
async function uploadAdapterFile(adapter, path, hash, size, api, checkpoint, cooperate, processing = () => {
}) {
  const before = await adapter.stat(path);
  checkpoint();
  if ((before == null ? void 0 : before.type) !== "file" || before.size !== size) throw new AdapterFileChangedError(path);
  const resource = adapter.getResourcePath;
  if (typeof resource !== "function") throw new Error("This adapter cannot safely stream this large file; it remains local and sync will retry. Update Obsidian or use a native filesystem vault.");
  return controlledIo(checkpoint, async (signal, touch) => {
    let session;
    try {
      session = await api.beginContentUpload(hash, size, signal);
    } catch (error) {
      if (error instanceof ApiError && error.status === 404) {
        api.disableStreamUpload();
        return false;
      }
      throw error;
    }
    checkpoint();
    touch();
    if (!session || session.hash !== hash || session.size !== size || session.chunkBytes !== CHUNK_BYTES || typeof session.id !== "string" || !session.id || typeof session.complete !== "boolean" || !Number.isSafeInteger(session.offset) || session.offset < 0 || session.offset > size || session.complete && session.offset !== size || session.offset !== size && session.offset % CHUNK_BYTES !== 0) throw new Error("The server returned an invalid resumable upload state");
    const response = await fetch(resource.call(adapter, path), { signal, cache: "no-store" });
    checkpoint();
    if (!response.ok || !response.body) throw new Error("This device could not stream the saved file safely. Its content was not committed.");
    const reader = response.body.getReader(), digest = sha256.create(), chunk = new Uint8Array(CHUNK_BYTES);
    let read = 0, filled = 0, uploaded = session.offset, processingId = session.processingId;
    const cancel = () => {
      void reader.cancel().catch(() => {
      });
    };
    signal.addEventListener("abort", cancel, { once: true });
    const send = async () => {
      const start = read - filled;
      if (read > session.offset) {
        if (start < session.offset) throw new Error("The upload resume offset does not align with its chunks");
        checkpoint();
        const body = chunk.subarray(0, filled), receipt = await api.putContentUploadChunk(session.id, start / CHUNK_BYTES, body, await hashBytes(body), signal);
        checkpoint();
        touch();
        if (receipt.id !== session.id || receipt.offset !== read) throw new Error("The server returned an invalid upload chunk receipt");
        uploaded = receipt.offset;
      }
      filled = 0;
    };
    try {
      for (; ; ) {
        checkpoint();
        const { done, value } = await reader.read();
        checkpoint();
        if (done) break;
        touch();
        if (read + value.byteLength > size) throw new AdapterFileChangedError(path);
        for (let offset = 0; offset < value.byteLength; ) {
          const length = Math.min(64 * 1024, CHUNK_BYTES - filled, value.byteLength - offset), part = value.subarray(offset, offset + length);
          digest.update(part);
          chunk.set(part, filled);
          filled += length;
          read += length;
          offset += length;
          if (filled === CHUNK_BYTES) await send();
          await cooperate();
        }
      }
      if (filled) await send();
      const after = await adapter.stat(path);
      checkpoint();
      if (read !== size || bytesToHex(digest.digest()) !== hash || (after == null ? void 0 : after.type) !== "file" || after.size !== before.size || after.mtime !== before.mtime || after.ctime !== before.ctime) throw new AdapterFileChangedError(path);
      if (uploaded !== size) throw new Error("The resumable upload did not acknowledge the complete file");
      if (!session.complete) {
        let previousStage;
        for (; ; ) {
          checkpoint();
          const completed = await api.completeContentUpload(session.id, signal);
          if (completed.id !== session.id || completed.hash !== hash || completed.size !== size || completed.offset !== size || completed.chunkBytes !== CHUNK_BYTES || typeof completed.complete !== "boolean") throw new Error("The server did not verify the completed large-file upload");
          if (typeof completed.processingId === "string") processingId = completed.processingId;
          checkpoint();
          touch();
          if (completed.complete) break;
          if (completed.processing !== true || !completed.stage || !["verifying", "uploading", "checking", "waiting"].includes(completed.stage)) throw new Error("The server returned an invalid upload processing state");
          if (previousStage !== completed.stage) {
            processing(completed.stage);
            previousStage = completed.stage;
          }
          await new Promise((resolve, reject) => {
            const abort = () => {
              clearTimeout(timer);
              signal.removeEventListener("abort", abort);
              reject(new Error("Upload paused"));
            }, timer = setTimeout(() => {
              signal.removeEventListener("abort", abort);
              resolve();
            }, 1e3);
            signal.addEventListener("abort", abort, { once: true });
            if (signal.aborted) abort();
          });
          checkpoint();
        }
      }
      const finalStat = await adapter.stat(path);
      checkpoint();
      if ((finalStat == null ? void 0 : finalStat.type) !== "file" || finalStat.size !== before.size || finalStat.mtime !== before.mtime || finalStat.ctime !== before.ctime) throw new AdapterFileChangedError(path);
      return true;
    } catch (error) {
      let ownerStopped = signal.aborted;
      if (!ownerStopped) try {
        checkpoint();
      } catch (e) {
        ownerStopped = true;
      }
      if (ownerStopped && processingId && typeof api.cancelContentUpload === "function") {
        const cancelling = new AbortController(), timer = setTimeout(() => cancelling.abort(), 2e3);
        try {
          await api.cancelContentUpload(session.id, processingId, cancelling.signal);
        } catch (e) {
        } finally {
          clearTimeout(timer);
        }
      }
      throw error;
    } finally {
      signal.removeEventListener("abort", cancel);
      digest.destroy();
      await reader.cancel().catch(() => {
      });
      reader.releaseLock();
    }
  });
}

// src/vault-inventory.ts
var ROOT = ".gib-sync/inventory-v2";
var MAX_BUCKET_BYTES = 4 * 1024 * 1024;
var MAX_FILES = 2e5;
var AUDIT_MS = 6 * 60 * 60 * 1e3;
var encoder2 = new TextEncoder();
var decoder = new TextDecoder();
var validStamp = (stamp) => [stamp.size, stamp.mtime, stamp.ctime].every((value) => Number.isFinite(value) && value >= 0);
var VaultInventory = class {
  constructor(adapter, scopeValue, cooperate, canBuffer = () => true, allowed = () => {
  }) {
    this.adapter = adapter;
    this.scopeValue = scopeValue;
    this.cooperate = cooperate;
    this.canBuffer = canBuffer;
    this.allowed = allowed;
    __publicField(this, "entries", /* @__PURE__ */ new Map());
    __publicField(this, "sessionVerified", /* @__PURE__ */ new Set());
    __publicField(this, "dirty", /* @__PURE__ */ new Set());
    __publicField(this, "dirtyScope", "");
    __publicField(this, "dirtyGenerations", /* @__PURE__ */ new Map());
    __publicField(this, "dirtyBuckets", /* @__PURE__ */ new Set());
    __publicField(this, "buckets", /* @__PURE__ */ new Map());
    __publicField(this, "loaded", null);
    __publicField(this, "stopped", false);
    __publicField(this, "tail", Promise.resolve());
    __publicField(this, "auditCursor", 0);
    __publicField(this, "auditPaths", []);
    __publicField(this, "keysChanged", true);
    __publicField(this, "scope", "");
  }
  get pendingVerification() {
    return Math.max(0, this.entries.size - this.sessionVerified.size);
  }
  get size() {
    return this.entries.size;
  }
  known(path) {
    const entry = this.entries.get(path);
    return entry ? { ...entry } : void 0;
  }
  paths() {
    return [...this.entries.keys()];
  }
  ready() {
    return this.load();
  }
  stop() {
    this.stopped = true;
  }
  checkpoint() {
    if (this.stopped) throw new SyncCancelledError("Background verification stopped safely.");
    this.allowed();
  }
  async bucket(path) {
    let bucket = this.buckets.get(path);
    if (!bucket) {
      bucket = (await hashBytes(encoder2.encode(path))).slice(0, 2);
      this.buckets.set(path, bucket);
    }
    return bucket;
  }
  async load() {
    const scope = this.scopeValue();
    if (this.loaded && this.scope === scope) return this.loaded;
    if (this.dirtyScope !== scope) {
      this.dirty.clear();
      this.dirtyGenerations.clear();
    }
    this.dirtyScope = scope;
    this.scope = scope;
    this.entries.clear();
    this.sessionVerified.clear();
    this.dirtyBuckets.clear();
    this.buckets.clear();
    this.auditCursor = 0;
    this.auditPaths = [];
    this.keysChanged = true;
    this.loaded = (async () => {
      let files = [];
      try {
        files = (await this.adapter.list(ROOT)).files;
      } catch (e) {
        return;
      }
      for (const path of files) {
        this.checkpoint();
        if (!/^\.gib-sync\/inventory-v2\/[a-f0-9]{2}\.json$/.test(path)) continue;
        try {
          const stat = await this.adapter.stat(path);
          if ((stat == null ? void 0 : stat.type) !== "file" || stat.size > MAX_BUCKET_BYTES) continue;
          const packed = JSON.parse(decoder.decode(new Uint8Array(await this.adapter.readBinary(path))));
          if (packed.version !== 2 || packed.scope !== scope || typeof packed.payload !== "string" || await hashBytes(encoder2.encode(packed.payload)) !== packed.hash) continue;
          const rows = JSON.parse(packed.payload);
          if (!Array.isArray(rows)) continue;
          let processed = 0;
          for (const row of rows) {
            if (++processed % 64 === 0) {
              this.checkpoint();
              await this.cooperate();
            }
            if (this.entries.size >= MAX_FILES) break;
            if (!row || !isSafeVaultPath(row.path) || !validStamp({ size: row.size, mtime: row.mtime, ctime: row.ctime }) || !/^[a-f0-9]{64}$/.test(row.hash) || !Number.isFinite(row.verifiedAt) || row.verifiedAt < 0) continue;
            this.entries.set(row.path, row);
            this.buckets.set(row.path, path.slice(-7, -5));
          }
        } catch (e) {
        }
        await this.cooperate();
      }
    })();
    return this.loaded;
  }
  markDirty(path) {
    var _a;
    if (isSafeVaultPath(path)) {
      const scope = this.scopeValue();
      if (this.dirtyScope !== scope) {
        this.dirty.clear();
        this.dirtyGenerations.clear();
        this.dirtyScope = scope;
      }
      this.dirtyGenerations.set(path, ((_a = this.dirtyGenerations.get(path)) != null ? _a : 0) + 1);
      this.dirty.add(path);
      this.sessionVerified.delete(path);
    }
  }
  markMove(from, to) {
    for (const path of this.entries.keys()) if (path === from || path.startsWith(`${from}/`)) {
      this.markDirty(path);
      this.markDirty(path === from ? to : `${to}${path.slice(from.length)}`);
    }
  }
  async inspect(path, force = false) {
    var _a, _b, _c;
    await this.load();
    this.checkpoint();
    const generation = (_a = this.dirtyGenerations.get(path)) != null ? _a : 0, stat = await this.adapter.stat(path);
    if (generation !== ((_b = this.dirtyGenerations.get(path)) != null ? _b : 0)) throw new AdapterFileChangedError(path);
    if ((stat == null ? void 0 : stat.type) !== "file") {
      if (this.entries.delete(path)) {
        this.dirtyBuckets.add(await this.bucket(path));
        this.keysChanged = true;
      }
      this.sessionVerified.delete(path);
      this.dirty.delete(path);
      return null;
    }
    const saved = this.entries.get(path), same2 = saved && saved.size === stat.size && saved.mtime === stat.mtime && saved.ctime === stat.ctime;
    if (!force && same2 && !this.dirty.has(path)) return { ...saved };
    const hash = await hashAdapterFile(this.adapter, path, () => this.checkpoint(), this.cooperate, this.canBuffer(stat.size));
    this.checkpoint();
    const after = await this.adapter.stat(path);
    if (generation !== ((_c = this.dirtyGenerations.get(path)) != null ? _c : 0)) throw new AdapterFileChangedError(path);
    if ((after == null ? void 0 : after.type) !== "file") return null;
    const next = { ...saved, path, hash, size: after.size, mtime: after.mtime, ctime: after.ctime, verifiedAt: Date.now() };
    this.entries.set(path, next);
    if (!saved) this.keysChanged = true;
    this.sessionVerified.add(path);
    this.dirty.delete(path);
    this.dirtyBuckets.add(await this.bucket(path));
    return { ...next };
  }
  async finishListing(paths) {
    await this.load();
    const visible = new Set(paths);
    for (const path of [...this.entries.keys()]) if (!visible.has(path)) {
      this.entries.delete(path);
      this.keysChanged = true;
      this.sessionVerified.delete(path);
      this.dirty.delete(path);
      this.dirtyBuckets.add(await this.bucket(path));
    }
    await this.flush();
  }
  async verifyStep(maxFiles = 16, maxBytes = 8 * 1024 * 1024, maxMilliseconds = 16) {
    await this.load();
    this.checkpoint();
    if (this.keysChanged) {
      this.auditPaths = [...this.entries.keys()];
      this.keysChanged = false;
    }
    const paths = this.auditPaths, changedPaths = [];
    let checked = 0, bytes2 = 0, visited = 0;
    const started = performance.now(), now = Date.now();
    while (paths.length && visited < Math.min(paths.length, 512) && checked < maxFiles) {
      this.checkpoint();
      if (visited && performance.now() - started >= maxMilliseconds) break;
      const path = paths[this.auditCursor++ % paths.length];
      visited++;
      if (visited % 64 === 0) await this.cooperate();
      const before = this.entries.get(path);
      if (!before) continue;
      const due = !this.sessionVerified.has(path) || now < before.verifiedAt || now - before.verifiedAt >= AUDIT_MS || this.dirty.has(path);
      if (!due) continue;
      const after = await this.inspect(path, true);
      checked++;
      bytes2 += before.size;
      if (!after || after.hash !== before.hash) changedPaths.push(path);
      await this.cooperate();
      if (bytes2 >= maxBytes || performance.now() - started >= maxMilliseconds) break;
    }
    await this.flush();
    return { changedPaths, pending: this.pendingVerification, checked };
  }
  async flush() {
    const writing = this.tail.catch(() => {
    }).then(async () => {
      await this.load();
      const buckets = [...this.dirtyBuckets], remaining = new Set(buckets);
      this.dirtyBuckets.clear();
      if (!buckets.length) return;
      try {
        if (!await this.adapter.exists(".gib-sync")) await this.adapter.mkdir(".gib-sync");
        if (!await this.adapter.exists(ROOT)) await this.adapter.mkdir(ROOT);
        const wanted = new Set(buckets), rowsByBucket = new Map(buckets.map((bucket) => [bucket, []]));
        let visited = 0;
        for (const [path, row] of this.entries) {
          const bucket = await this.bucket(path);
          if (wanted.has(bucket)) rowsByBucket.get(bucket).push(row);
          if (++visited % 64 === 0) await this.cooperate();
        }
        for (const bucket of buckets) {
          this.checkpoint();
          const payload = JSON.stringify(rowsByBucket.get(bucket)), packed = { version: 2, scope: this.scope, payload, hash: await hashBytes(encoder2.encode(payload)) };
          await this.adapter.writeBinary(`${ROOT}/${bucket}.json`, encoder2.encode(JSON.stringify(packed)).buffer);
          remaining.delete(bucket);
          await this.cooperate();
        }
      } catch (error) {
        for (const bucket of remaining) this.dirtyBuckets.add(bucket);
        throw error;
      }
    });
    this.tail = writing;
    return writing;
  }
};

// src/intent-journal.ts
function indexedIntentCreates(events) {
  const result = /* @__PURE__ */ new Map();
  for (const event of events) {
    if (event.kind === "move" && event.from) {
      const matches = event.entity === "file" ? [...[result.get(`file:${event.from}`)].filter((item) => Boolean(item))] : [...result.values()].filter((item) => item.path === event.from || item.path.startsWith(`${event.from}/`));
      for (const item of matches) {
        result.delete(`${item.entity}:${item.path}`);
        const path = `${event.path}${item.path.slice(event.from.length)}`;
        result.set(`${item.entity}:${path}`, { ...item, path });
      }
    } else if (event.kind === "create" || event.kind === "delete") {
      if (event.entity === "folder" && event.kind === "delete") {
        for (const [key, item] of result) if (item.path.startsWith(`${event.path}/`)) result.delete(key);
      }
      result.set(`${event.entity}:${event.path}`, { ...event });
    }
  }
  return result;
}
var ROOT2 = ".gib-sync/intents-v2";
var encoder3 = new TextEncoder();
var decoder2 = new TextDecoder();
var UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
var IntentJournal = class {
  constructor(adapter, scope, cooperate) {
    this.adapter = adapter;
    this.scope = scope;
    this.cooperate = cooperate;
    __publicField(this, "events", []);
    __publicField(this, "loadedScope", "");
    __publicField(this, "loaded", null);
    __publicField(this, "tail", Promise.resolve());
    __publicField(this, "sequence", 0);
    __publicField(this, "frozenSequence", 0);
    __publicField(this, "pending", /* @__PURE__ */ new Map());
  }
  async root(scope) {
    return `${ROOT2}/${(await hashBytes(encoder3.encode(scope))).slice(0, 32)}`;
  }
  async mkdir(path) {
    for (const prefix of path.split("/").map((_, index, parts) => parts.slice(0, index + 1).join("/"))) if (!await this.adapter.exists(prefix)) await this.adapter.mkdir(prefix);
  }
  async load(scope = this.scope()) {
    if (this.loaded && this.loadedScope === scope) return this.loaded;
    if (this.loaded) await this.loaded.catch(() => {
    });
    this.events = [];
    this.sequence = 0;
    this.frozenSequence = 0;
    this.loadedScope = scope;
    this.loaded = (async () => {
      const root2 = await this.root(scope);
      let paths;
      try {
        paths = (await this.adapter.list(root2)).files;
      } catch (e) {
        return;
      }
      for (const path of paths) {
        if (!/\/[0-9a-f-]+\.json$/.test(path)) continue;
        const stat = await this.adapter.stat(path);
        if ((stat == null ? void 0 : stat.type) !== "file" || stat.size > 16 * 1024) throw new Error("The durable change journal contains an invalid record; local files were retained");
        let record;
        try {
          record = JSON.parse(decoder2.decode(new Uint8Array(await this.adapter.readBinary(path))));
        } catch (e) {
          throw new Error("A change journal record was interrupted; syncing is held without deleting local files");
        }
        if (record.scope !== scope || await hashBytes(encoder3.encode(record.payload)) !== record.hash) throw new Error("A change journal failed its scope or checksum; local files were retained");
        const event = JSON.parse(record.payload);
        if (!UUID.test(event.id) || path !== `${root2}/${event.id}.json` || event.targetId !== void 0 && !UUID.test(event.targetId) || !Number.isFinite(event.at) || event.at < 0 || !Number.isSafeInteger(event.sequence) || event.sequence < 1 || !isSafeVaultPath(event.path) || event.from && !isSafeVaultPath(event.from) || !["create", "modify", "delete", "move", "observe"].includes(event.kind) || !["file", "folder"].includes(event.entity)) throw new Error("Invalid durable change intent");
        this.events.push(event);
        this.sequence = Math.max(this.sequence, event.sequence);
        await this.cooperate();
      }
      this.events.sort((a, b) => a.sequence - b.sequence || a.id.localeCompare(b.id));
    })();
    return this.loaded;
  }
  record(kind, path, entity = "file", from) {
    if (!isSafeVaultPath(path) || from && !isSafeVaultPath(from)) return Promise.reject(new Error("Unsafe intent path"));
    const scope = this.scope();
    const recording = this.tail.then(async () => {
      await this.load(scope);
      if (kind === "modify") {
        const previous = [...this.events].reverse().find((event2) => event2.path === path && event2.entity === entity);
        if ((previous == null ? void 0 : previous.kind) === "modify" && previous.sequence > this.frozenSequence) return { ...previous };
      }
      const event = { id: crypto.randomUUID(), sequence: ++this.sequence, kind, entity, path, ...from ? { from } : {}, at: Date.now(), ...kind === "create" ? { targetId: crypto.randomUUID() } : {} };
      this.pending.set(event.id, { event, scope });
      await this.persist(event, scope);
      this.pending.delete(event.id);
      this.events.push(event);
      return event;
    });
    this.tail = recording.then(() => {
    }, () => {
    });
    return recording;
  }
  async persist(event, scope) {
    const root2 = await this.root(scope);
    await this.mkdir(root2);
    const payload = JSON.stringify(event), hash = await hashBytes(encoder3.encode(payload)), path = `${root2}/${event.id}.json`;
    await this.adapter.writeBinary(path, encoder3.encode(JSON.stringify({ scope, payload, hash })).buffer);
    const saved = JSON.parse(decoder2.decode(new Uint8Array(await this.adapter.readBinary(path))));
    if (saved.hash !== hash || saved.payload !== payload) throw new Error("The vault intent did not persist exactly");
  }
  async flush() {
    await this.tail;
    for (const { event, scope } of this.pending.values()) {
      await this.persist(event, scope);
      if (scope === this.loadedScope && !this.events.some((saved) => saved.id === event.id)) this.events.push(event);
      this.pending.delete(event.id);
    }
    await this.load();
  }
  async snapshot() {
    await this.flush();
    this.frozenSequence = this.sequence;
    return this.events.map((event) => ({ ...event }));
  }
  async latestCreation(path) {
    const events = await this.snapshot();
    for (let index = events.length - 1; index >= 0; index--) {
      const event = events[index];
      if (event.path === path && event.entity === "file") {
        if (event.kind === "create") return event;
        if (event.kind === "delete") return void 0;
      }
    }
    return void 0;
  }
  async acknowledge(sequence) {
    await this.flush();
    const root2 = await this.root(this.loadedScope);
    for (const event of this.events.filter((event2) => event2.sequence <= sequence)) {
      await this.adapter.remove(`${root2}/${event.id}.json`);
      await this.cooperate();
    }
    this.events = this.events.filter((event) => event.sequence > sequence);
  }
};

// src/operation-journal.ts
var ROOT3 = ".gib-sync/operation-journal-v2";
var encoder4 = new TextEncoder();
var decoder3 = new TextDecoder();
var UUID2 = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
var HASH = /^[a-f0-9]{64}$/;
var safePath = (path) => typeof path === "string" && path.length <= 4e3 && isSafeVaultPath(path);
var ownedPath = (path, root2) => {
  const id = path.slice(root2.length + 9, -5);
  return UUID2.test(id) && path === `${root2}/current-${id}.json`;
};
var content = (value) => {
  const row = value;
  return Boolean(row) && HASH.test(row.hash) && Number.isSafeInteger(row.size) && row.size >= 0 && Number.isFinite(row.mtime) && row.mtime >= 0;
};
function validRecord(record) {
  var _a, _b;
  const batch = record.batch;
  if (!batch || !UUID2.test(batch.batchId) || batch.baseSnapshotId !== null && !UUID2.test(batch.baseSnapshotId) || typeof batch.message !== "string" || batch.message.length > 500 || !Array.isArray(batch.operations) || batch.operations.length > 2e5 || !["prepared", "submitted", "accepted"].includes(record.phase) || !Number.isSafeInteger(record.intentSequence) || record.intentSequence < 0 || !record.priorHashes || !record.priorEntries) return false;
  const ids = /* @__PURE__ */ new Set();
  for (const op of batch.operations) {
    if (!UUID2.test(op.operationId) || ids.has(op.operationId) || !UUID2.test(op.targetId) || op.baseRevisionId !== null && !UUID2.test(op.baseRevisionId)) return false;
    ids.add(op.operationId);
    switch (op.kind) {
      case "create":
        if (op.baseRevisionId !== null || !safePath(op.path) || !content(op.content)) return false;
        break;
      case "edit":
        if (!content(op.content)) return false;
        break;
      case "move":
        if (!safePath(op.newPath)) return false;
        break;
      case "move-folder":
        if (!safePath(op.newPath) || !Array.isArray(op.descendants) || op.descendants.length > 2e5 || op.descendants.some((child) => !UUID2.test(child.targetId) || !UUID2.test(child.baseRevisionId))) return false;
        break;
      case "recreate":
        if (!UUID2.test(op.newTargetId) || !safePath(op.path) || !content(op.content) || op.deletedByOperationId !== void 0 && !UUID2.test(op.deletedByOperationId)) return false;
        break;
      case "mkdir":
        if (!safePath(op.path) || op.newTargetId !== void 0 && !UUID2.test(op.newTargetId) || op.deletedByOperationId !== void 0 && !UUID2.test(op.deletedByOperationId)) return false;
        break;
      case "delete":
      case "rmdir":
        break;
      default:
        return false;
    }
  }
  if (Array.isArray(record.priorHashes) || Array.isArray(record.priorEntries) || Object.entries(record.priorHashes).some(([path, hash]) => !safePath(path) || hash !== null && !HASH.test(hash)) || Object.entries(record.priorEntries).some(([path, entry]) => !safePath(path) || entry.path !== path || !content(entry) || entry.fileId !== void 0 && !UUID2.test(entry.fileId))) return false;
  if (record.phase === "accepted" && (!record.receipt || record.receipt.batchId !== batch.batchId || !Number.isSafeInteger(record.receipt.sequence) || !record.receipt.snapshot || !UUID2.test(record.receipt.snapshot.id) || !Array.isArray(record.receipt.snapshot.entries) || record.receipt.snapshot.entries.some((entry) => !safePath(entry.path) || !content(entry)))) return false;
  const action = record.conflictAction;
  if (action && (!UUID2.test(action.id) || !["resolve", "undo"].includes(action.kind) || action.kind === "resolve" && !["this", "other", "combine", "both"].includes((_a = action.choice) != null ? _a : "") || action.kind === "undo" && !UUID2.test((_b = action.resolutionId) != null ? _b : "") || !Array.isArray(action.before) || !Array.isArray(action.after) || [...action.before, ...action.after].some((proof) => !safePath(proof.path) || proof.hash !== null && !HASH.test(proof.hash)))) return false;
  return true;
}
var OperationJournal = class {
  constructor(adapter, scope) {
    this.adapter = adapter;
    this.scope = scope;
    __publicField(this, "tail", Promise.resolve());
  }
  async root(scope) {
    return `${ROOT3}/${(await hashBytes(encoder4.encode(scope))).slice(0, 32)}`;
  }
  async load(scope = this.scope()) {
    const root2 = await this.root(scope);
    let paths;
    try {
      paths = (await this.adapter.list(root2)).files;
    } catch (e) {
      return null;
    }
    const records2 = [];
    let corruption;
    for (const path of paths) {
      if (!ownedPath(path, root2)) continue;
      try {
        const stat = await this.adapter.stat(path);
        if ((stat == null ? void 0 : stat.type) !== "file" || stat.size > 96 * 1024 * 1024) throw new Error("Durable operation metadata exceeds its bounded record limit");
        const packed = JSON.parse(decoder3.decode(new Uint8Array(await this.adapter.readBinary(path))));
        if (packed.scope !== scope || await hashBytes(encoder4.encode(packed.payload)) !== packed.hash || !Number.isSafeInteger(packed.sequence)) throw new Error("Incomplete durable operation journal");
        const record = JSON.parse(packed.payload);
        if (!validRecord(record)) throw new Error("Invalid durable operation journal");
        records2.push({ record, sequence: packed.sequence });
      } catch (error) {
        corruption = error;
      }
    }
    if (!records2.length) {
      if (corruption) throw new Error("The durable operation journal could not be verified. Local content was retained.", { cause: corruption });
      return null;
    }
    records2.sort((a, b) => b.sequence - a.sequence);
    return records2[0].record;
  }
  save(record) {
    if (!validRecord(record)) return Promise.reject(new Error("Invalid durable operation proposal"));
    const scope = this.scope(), writing = this.tail.catch(() => {
    }).then(async () => {
      const root2 = await this.root(scope);
      for (const prefix of root2.split("/").map((_, index, parts) => parts.slice(0, index + 1).join("/"))) if (!await this.adapter.exists(prefix)) await this.adapter.mkdir(prefix);
      const oldFiles = (await this.adapter.list(root2)).files;
      let sequence = 0;
      for (const old of oldFiles) try {
        if (!ownedPath(old, root2)) continue;
        const stat = await this.adapter.stat(old);
        if ((stat == null ? void 0 : stat.type) !== "file" || stat.size > 96 * 1024 * 1024) continue;
        const saved = JSON.parse(decoder3.decode(new Uint8Array(await this.adapter.readBinary(old))));
        if (saved.scope === scope && Number.isSafeInteger(saved.sequence)) sequence = Math.max(sequence, saved.sequence);
      } catch (e) {
      }
      const payload = JSON.stringify(record), path = `${root2}/current-${crypto.randomUUID()}.json`, hash = await hashBytes(encoder4.encode(payload));
      await this.adapter.writeBinary(path, encoder4.encode(JSON.stringify({ scope, payload, hash, sequence: sequence + 1 })).buffer);
      const verified = JSON.parse(decoder3.decode(new Uint8Array(await this.adapter.readBinary(path))));
      if (verified.payload !== payload || verified.hash !== hash) throw new Error("Operation journal did not persist exactly");
      for (const old of oldFiles) if (ownedPath(old, root2)) await this.adapter.remove(old);
    });
    this.tail = writing;
    return writing;
  }
  async clear() {
    await this.tail.catch(() => {
    });
    const root2 = await this.root(this.scope());
    let paths;
    try {
      paths = (await this.adapter.list(root2)).files;
    } catch (e) {
      return;
    }
    for (const path of paths) if (ownedPath(path, root2)) await this.adapter.remove(path);
  }
};

// src/operation-plan.ts
async function buildOperationBatch(tree, entries, folders, intents, message = "Sync", uuid = () => crypto.randomUUID(), desiredFolderIds = /* @__PURE__ */ new Map(), preserveFolders = /* @__PURE__ */ new Set(), cooperate = async () => {
}) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k;
  let steps = 0;
  const tick = async () => {
    if (++steps % 256 === 0) await cooperate();
  };
  const operations = [], files = [], directories = [];
  for (const entry of tree.files) {
    files.push({ ...entry });
    await tick();
  }
  for (const entry of tree.folders) {
    directories.push({ ...entry });
    await tick();
  }
  const preservedIds = new Set(directories.filter((entry) => preserveFolders.has(entry.path)).map((entry) => entry.folderId)), deletedAt = /* @__PURE__ */ new Map();
  const base = (id, revision) => ({ operationId: uuid(), targetId: id, baseRevisionId: revision });
  const creationIndex = indexedIntentCreates(intents), latestCreate = (path, entity) => {
    const event = creationIndex.get(`${entity}:${path}`);
    return (event == null ? void 0 : event.kind) === "create" ? event : void 0;
  }, tombstones = /* @__PURE__ */ new Map();
  for (const item of tree.tombstones) {
    await tick();
    const old = tombstones.get(item.path);
    if (!old || item.deletedSequence > old.deletedSequence || item.deletedSequence === old.deletedSequence && ((_a = item.deletedOrdinal) != null ? _a : 0) > ((_b = old.deletedOrdinal) != null ? _b : 0) || item.deletedSequence === old.deletedSequence && ((_c = item.deletedOrdinal) != null ? _c : 0) === ((_d = old.deletedOrdinal) != null ? _d : 0) && (item.revision.modifiedAt > old.revision.modifiedAt || item.revision.modifiedAt === old.revision.modifiedAt && item.revision.id > old.revision.id)) tombstones.set(item.path, item);
  }
  const tombstoneFor = (path) => tombstones.get(path);
  const destinations = new Map([...desiredFolderIds].map(([path, id]) => [id, path]));
  if (!destinations.size) for (const directory of directories) {
    let path = directory.path;
    for (const intent of intents) if (intent.entity === "folder" && intent.kind === "move" && intent.from && (path === intent.from || path.startsWith(`${intent.from}/`))) path = `${intent.path}${path.slice(intent.from.length)}`;
    destinations.set(directory.folderId, path);
  }
  const finalFileIds = new Set(entries.flatMap((entry) => entry.fileId ? [entry.fileId] : [])), finalFolderIds = new Set(desiredFolderIds.values());
  for (const destination of new Set(directories.filter((entry) => destinations.has(entry.folderId) && destinations.get(entry.folderId) !== entry.path).map((entry) => destinations.get(entry.folderId)))) {
    await tick();
    const root2 = directories.find((entry) => entry.path === destination && destinations.get(entry.folderId) !== destination), file = files.find((entry) => {
      var _a2;
      return entry.path === destination && !finalFileIds.has((_a2 = entry.fileId) != null ? _a2 : "");
    });
    if (file) {
      if (!file.fileId || !file.revision) throw new Error("A retired move destination lacks identity");
      const deletion = { ...base(file.fileId, file.revision.id), kind: "delete" };
      operations.push(deletion);
      deletedAt.set(file.path, deletion);
      files.splice(files.indexOf(file), 1);
    }
    if (root2 && !finalFolderIds.has(root2.folderId) && !preservedIds.has(root2.folderId)) {
      const children = files.filter((entry) => entry.path.startsWith(`${destination}/`)), childFolders = directories.filter((entry) => entry.path === destination || entry.path.startsWith(`${destination}/`));
      if (children.some((entry) => {
        var _a2;
        return finalFileIds.has((_a2 = entry.fileId) != null ? _a2 : "");
      }) || childFolders.some((entry) => finalFolderIds.has(entry.folderId) || preservedIds.has(entry.folderId))) continue;
      for (const entry of children) {
        if (!entry.fileId || !entry.revision) throw new Error("A retired subtree lacks identity");
        const deletion = { ...base(entry.fileId, entry.revision.id), kind: "delete" };
        operations.push(deletion);
        deletedAt.set(entry.path, deletion);
        files.splice(files.indexOf(entry), 1);
      }
      for (const entry of childFolders.sort((a, b) => b.path.length - a.path.length)) {
        const deletion = { ...base(entry.folderId, entry.revision.id), kind: "rmdir" };
        operations.push(deletion);
        deletedAt.set(entry.path, deletion);
        directories.splice(directories.indexOf(entry), 1);
      }
    }
  }
  const relocate = (root2, to) => {
    const from = root2.path, under = (path) => path.startsWith(`${from}/`), children = files.filter((entry) => under(entry.path)), childFolders = directories.filter((entry) => under(entry.path));
    if (children.some((entry) => !entry.fileId || !entry.revision)) throw new Error("A folder subtree lacks safe file identities");
    operations.push({ ...base(root2.folderId, root2.revision.id), kind: "move-folder", newPath: to, descendants: [...children.map((entry) => ({ targetId: entry.fileId, baseRevisionId: entry.revision.id })), ...childFolders.map((entry) => ({ targetId: entry.folderId, baseRevisionId: entry.revision.id }))] });
    for (const entry of [...children, ...childFolders]) entry.path = `${to}${entry.path.slice(from.length)}`;
    root2.path = to;
  };
  for (let remaining = directories.length * 3 + 1; remaining > 0; remaining--) {
    await tick();
    const moving = directories.filter((entry) => destinations.has(entry.folderId) && destinations.get(entry.folderId) !== entry.path).sort((a, b) => a.path.split("/").length - b.path.split("/").length);
    if (!moving.length) break;
    const available = moving.find((entry) => !directories.some((other) => other.folderId !== entry.folderId && other.path === destinations.get(entry.folderId)) && !files.some((file) => file.path === destinations.get(entry.folderId)));
    if (available) {
      relocate(available, destinations.get(available.folderId));
      continue;
    }
    const candidate = moving.find((entry) => directories.some((other) => other.folderId !== entry.folderId && other.path === destinations.get(entry.folderId) && destinations.has(other.folderId) && destinations.get(other.folderId) !== other.path));
    if (!candidate) throw new Error("An independently occupied folder destination was retained; no namespace overwrite was sent");
    relocate(candidate, `.gib-sync-move-${uuid()}`);
  }
  if (directories.some((entry) => destinations.has(entry.folderId) && destinations.get(entry.folderId) !== entry.path)) throw new Error("Folder moves could not be planned safely");
  const parents = /* @__PURE__ */ new Set();
  for (const raw of [...folders, ...entries.map((entry) => entry.path.split("/").slice(0, -1).join("/"))]) {
    const parts = raw.split("/").filter(Boolean);
    for (let index = 1; index <= parts.length; index++) parents.add(parts.slice(0, index).join("/"));
    await tick();
  }
  const wanted = /* @__PURE__ */ new Set([...folders, ...parents, ...directories.filter((entry) => preservedIds.has(entry.folderId)).map((entry) => entry.path)]), folderByPath = new Map(directories.map((entry) => [entry.path, entry]));
  const replacedFolders = directories.filter((entry) => {
    var _a2;
    return wanted.has(entry.path) && (desiredFolderIds.get(entry.path) && desiredFolderIds.get(entry.path) !== entry.folderId || ((_a2 = latestCreate(entry.path, "folder")) == null ? void 0 : _a2.targetId) && latestCreate(entry.path, "folder").targetId !== entry.folderId);
  }).map((entry) => entry.path);
  for (const entry of entries) {
    if (replacedFolders.some((path) => entry.path.startsWith(`${path}/`))) entry.fileId = (_f = (_e = latestCreate(entry.path, "file")) == null ? void 0 : _e.targetId) != null ? _f : uuid();
    await tick();
  }
  const byId = /* @__PURE__ */ new Map(), byPath = /* @__PURE__ */ new Map();
  for (const entry of files) {
    if (entry.fileId) byId.set(entry.fileId, entry);
    byPath.set(entry.path, entry);
    await tick();
  }
  const used = /* @__PURE__ */ new Set(), edits = [], creates = [], moves = [];
  for (const entry of entries) {
    await tick();
    const creation = latestCreate(entry.path, "file"), old = entry.fileId ? byId.get(entry.fileId) : creation ? void 0 : byPath.get(entry.path), content2 = { hash: entry.hash, size: entry.size, mtime: entry.mtime };
    if (old) {
      if (!old.fileId || !old.revision || used.has(old.fileId)) throw new Error("Server file identity is unavailable or claimed by two paths");
      used.add(old.fileId);
      entry.fileId = old.fileId;
      if (old.path !== entry.path) moves.push({ entry, old });
      if (old.hash !== entry.hash || old.size !== entry.size) edits.push({ ...base(old.fileId, old.revision.id), kind: "edit", content: content2 });
    } else {
      const targetId = (_h = (_g = creation == null ? void 0 : creation.targetId) != null ? _g : entry.fileId) != null ? _h : uuid();
      entry.fileId = targetId;
      creates.push({ entry, targetId });
    }
  }
  for (const entry of files) {
    await tick();
    if (entry.fileId && !used.has(entry.fileId)) {
      if (!entry.revision) throw new Error("Server revision is missing");
      const deletion = { ...base(entry.fileId, entry.revision.id), kind: "delete" };
      operations.push(deletion);
      deletedAt.set(entry.path, deletion);
    }
  }
  const pending = new Map(moves.map((move) => [move.old.fileId, move])), occupied = new Map(files.filter((file) => {
    var _a2;
    return used.has((_a2 = file.fileId) != null ? _a2 : "");
  }).map((file) => [file.path, file.fileId]));
  const moveTo = (item, path) => {
    operations.push({ ...base(item.old.fileId, item.old.revision.id), kind: "move", newPath: path });
    occupied.delete(item.old.path);
    occupied.set(path, item.old.fileId);
    item.old.path = path;
  };
  for (const start of pending.keys()) {
    if (!pending.has(start)) continue;
    const chain = [], seen = /* @__PURE__ */ new Set();
    let id = start;
    while (id) {
      await tick();
      const item = pending.get(id);
      if (!item) throw new Error("A file move destination belongs to an unchanged independent file");
      if (seen.has(id)) {
        moveTo(item, `.gib-sync-move-${uuid()}`);
        break;
      }
      seen.add(id);
      chain.push(item);
      id = occupied.get(item.entry.path);
      if (id === item.old.fileId) break;
    }
    for (const item of chain.reverse()) {
      await tick();
      const occupant = occupied.get(item.entry.path);
      if (occupant && occupant !== item.old.fileId) throw new Error("File move destinations could not be freed safely");
      if (item.old.path !== item.entry.path) moveTo(item, item.entry.path);
      pending.delete(item.old.fileId);
    }
  }
  for (const edit of edits) {
    operations.push(edit);
    await tick();
  }
  for (const directory of [...directories].sort((a, b) => b.path.split("/").length - a.path.split("/").length)) {
    const replaced = replacedFolders.some((path) => directory.path === path || directory.path.startsWith(`${path}/`));
    if (!wanted.has(directory.path) || replaced) {
      const removal = { ...base(directory.folderId, directory.revision.id), kind: "rmdir" };
      operations.push(removal);
      deletedAt.set(directory.path, removal);
      folderByPath.delete(directory.path);
    }
  }
  for (const path of [...wanted].sort((a, b) => a.split("/").length - b.split("/").length || a.localeCompare(b))) {
    await tick();
    if (folderByPath.has(path)) continue;
    const deletion = deletedAt.get(path), tombstone = tombstoneFor(path), targetId = replacedFolders.some((root2) => path.startsWith(`${root2}/`)) ? uuid() : (_k = (_j = desiredFolderIds.get(path)) != null ? _j : (_i = latestCreate(path, "folder")) == null ? void 0 : _i.targetId) != null ? _k : uuid();
    if (deletion) operations.push({ ...base(deletion.targetId, deletion.baseRevisionId), kind: "mkdir", newTargetId: targetId, path, deletedByOperationId: deletion.operationId });
    else if (tombstone) operations.push({ ...base(tombstone.targetId, tombstone.revision.id), kind: "mkdir", newTargetId: targetId, path });
    else operations.push({ ...base(targetId, null), kind: "mkdir", path });
  }
  for (const { entry, targetId } of creates) {
    await tick();
    const content2 = { hash: entry.hash, size: entry.size, mtime: entry.mtime }, deletion = deletedAt.get(entry.path), tombstone = tombstoneFor(entry.path);
    if (deletion) operations.push({ ...base(deletion.targetId, deletion.baseRevisionId), kind: "recreate", newTargetId: targetId, path: entry.path, content: content2, deletedByOperationId: deletion.operationId });
    else if (tombstone) operations.push({ ...base(tombstone.targetId, tombstone.revision.id), kind: "recreate", newTargetId: targetId, path: entry.path, content: content2 });
    else operations.push({ ...base(targetId, null), kind: "create", path: entry.path, content: content2 });
  }
  return { batchId: uuid(), baseSnapshotId: tree.snapshotId, message, operations };
}

// src/plugin-runtime.ts
var PackageRuntimeHoldError = class extends Error {
  constructor(pluginId, message) {
    super(message);
    this.pluginId = pluginId;
    this.name = "PackageRuntimeHoldError";
  }
};
var sharedHooks = /* @__PURE__ */ new WeakMap();
var sharedComponents = /* @__PURE__ */ new WeakMap();
var PluginRuntimeCoordinator = class {
  constructor(app, prototype, manager, adapter, pluginRoot, isMobile, checkpoint, cooperate, hold, settingsWriteTimeoutMs = 15e3) {
    this.app = app;
    this.prototype = prototype;
    this.manager = manager;
    this.adapter = adapter;
    this.pluginRoot = pluginRoot;
    this.isMobile = isMobile;
    this.checkpoint = checkpoint;
    this.cooperate = cooperate;
    this.hold = hold;
    this.settingsWriteTimeoutMs = settingsWriteTimeoutMs;
    __publicField(this, "guards", /* @__PURE__ */ new Map());
    __publicField(this, "originalLoad");
    __publicField(this, "originalSave");
    __publicField(this, "wrappedLoad");
    __publicField(this, "wrappedSave");
    __publicField(this, "hooks");
    __publicField(this, "originalInstanceSaves", /* @__PURE__ */ new WeakMap());
    __publicField(this, "activeFences", /* @__PURE__ */ new Map());
    __publicField(this, "closed", false);
    var _a, _b;
    const existing = sharedHooks.get(prototype);
    this.originalLoad = (_a = existing == null ? void 0 : existing.originalLoad) != null ? _a : prototype.loadData;
    this.originalSave = (_b = existing == null ? void 0 : existing.originalSave) != null ? _b : prototype.saveData;
    const owner = this;
    this.wrappedLoad = async function() {
      const guard = owner.guard(this), token = guard == null ? void 0 : guard.loadToken;
      if (!guard || guard.phase !== "loading" || !token) return owner.originalLoad.call(this);
      if (!guard.cleanup) owner.checkpoint();
      const path = `${owner.pluginRoot(guard.id)}/data.json`;
      if (await owner.hash(path, guard.cleanup) !== guard.expected) throw new Error("Plugin settings changed before their fresh runtime load");
      const value = await owner.originalLoad.call(this);
      if (owner.guards.get(guard.id) !== guard || guard.phase !== "loading" || guard.loadToken !== token) throw new Error("Plugin settings load belongs to a retired runtime attempt");
      if (await owner.hash(path, guard.cleanup) !== guard.expected) throw new Error("Plugin settings changed during their fresh runtime load");
      if (owner.guards.get(guard.id) !== guard || guard.phase !== "loading" || guard.loadToken !== token) throw new Error("Plugin settings load belongs to a retired runtime attempt");
      guard.approved.add(this);
      return value;
    };
    this.wrappedSave = async function(value) {
      const guard = owner.guard(this);
      if (!guard) return owner.originalSave.call(this, value);
      if (guard.phase === "unloading" && this === guard.previous || guard.approved.has(this)) return owner.trackWrite(guard, () => owner.originalSave.call(this, value), this !== guard.previous);
      await owner.preserveSave(guard.id, value, this);
    };
    if (existing) {
      this.hooks = existing;
      existing.owners.add(this);
    } else {
      const owners = /* @__PURE__ */ new Set([this]), originalLoad = this.originalLoad, originalSave = this.originalSave;
      const load = async function() {
        for (const instance of owners) if (instance.guard(this)) return instance.wrappedLoad.call(this);
        return originalLoad.call(this);
      };
      const save = async function(value) {
        for (const instance of owners) if (instance.guard(this)) return instance.wrappedSave.call(this, value);
        return originalSave.call(this, value);
      };
      this.hooks = { owners, originalLoad, originalSave, load, save };
      sharedHooks.set(prototype, this.hooks);
      prototype.loadData = load;
      prototype.saveData = save;
    }
  }
  guard(instance) {
    var _a, _b;
    return instance.app === this.app && ((_a = instance.manifest) == null ? void 0 : _a.id) !== "gib-sync" ? this.guards.get((_b = instance.manifest) == null ? void 0 : _b.id) : void 0;
  }
  components() {
    let map = sharedComponents.get(this.app);
    if (!map) {
      map = /* @__PURE__ */ new Map();
      sharedComponents.set(this.app, map);
    }
    return map;
  }
  newGuard(id, manager) {
    return { id, previous: manager.plugins[id], wanted: manager.enabledPlugins.has(id), phase: "unloading", expected: null, approved: /* @__PURE__ */ new WeakSet(), writes: /* @__PURE__ */ new Set(), activated: false };
  }
  retire(component) {
    const guard = component.guard;
    guard.loadToken = void 0;
    guard.approved = /* @__PURE__ */ new WeakSet();
    guard.phase = "quiesced";
    guard.activated = false;
    component.needsRecovery = true;
  }
  owned(component) {
    return this.components().get(component.guard.id) === component && component.owner === this && this.guards.get(component.guard.id) === component.guard;
  }
  async lifecycle(component, kind, operation) {
    const guard = component.guard;
    if (!this.owned(component) || component.pending) throw new PackageRuntimeHoldError(guard.id, "An earlier plugin runtime operation still owns this component");
    if (!guard.cleanup) {
      if (this.closed) throw new PackageRuntimeHoldError(guard.id, "The runtime coordinator was disposed before activation");
      this.checkpoint();
    }
    const attempt = { token: Symbol(kind), kind, settled: false, failed: false, promise: Promise.resolve() };
    component.pending = attempt;
    attempt.promise = Promise.resolve().then(operation).then((value) => {
      attempt.settled = true;
      return value;
    }, (error) => {
      attempt.settled = true;
      throw error;
    });
    void attempt.promise.catch(() => {
    });
    let timer;
    const deadline = Date.now() + this.settingsWriteTimeoutMs;
    const watchdog = new Promise((_, reject) => {
      const inspect = () => {
        try {
          if (!this.owned(component) || component.pending !== attempt) throw new Error("Plugin runtime attempt ownership changed");
          if (!guard.cleanup) {
            if (this.closed) throw new Error("The runtime coordinator was disposed during activation");
            this.checkpoint();
          }
          if (Date.now() >= deadline) throw new Error(`Plugin runtime ${kind} timed out; this component is held until the original operation finishes`);
          timer = setTimeout(inspect, Math.min(25, Math.max(1, deadline - Date.now())));
        } catch (error) {
          reject(error);
        }
      };
      inspect();
    });
    try {
      const result = await Promise.race([attempt.promise, watchdog]);
      if (!this.owned(component) || component.pending !== attempt) throw new Error("Plugin runtime attempt ownership changed");
      component.pending = void 0;
      return result;
    } catch (error) {
      attempt.failed = true;
      this.retire(component);
      if (kind === "enable") guard.activationFailed = true;
      const message = error instanceof Error ? error.message : String(error);
      throw new PackageRuntimeHoldError(guard.id, kind === "settings recovery" ? `Runtime settings recovery remains held; ${message}` : message);
    } finally {
      if (timer !== void 0) clearTimeout(timer);
    }
  }
  async begin(id, manager) {
    var _a;
    const map = this.components();
    let component = map.get(id);
    if (component == null ? void 0 : component.busy) throw new PackageRuntimeHoldError(id, "Another managed runtime attempt is still working on this plugin");
    if (component && component.owner !== this) {
      if (!component.owner.closed) throw new PackageRuntimeHoldError(id, "Another coordinator owns this plugin runtime");
      await component.owner.recoverExternal(component);
      component = map.get(id);
      if (component) throw new PackageRuntimeHoldError(id, "The previous runtime still protects unfinished work for this plugin");
    }
    if (component && component.manager !== manager) throw new PackageRuntimeHoldError(id, "The plugin manager changed while protected runtime work is unfinished");
    if (!component) {
      const guard = (_a = this.guards.get(id)) != null ? _a : this.newGuard(id, manager);
      this.guards.set(id, guard);
      component = { owner: this, guard, manager, busy: false, needsRecovery: false };
      map.set(id, component);
    }
    component.busy = true;
    try {
      if (component.needsRecovery || component.pending) await this.recover(component);
      return component;
    } catch (error) {
      this.end(component);
      throw error;
    }
  }
  end(component) {
    component.busy = false;
    if (this.closed && !component.pending && !component.needsRecovery && this.owned(component)) {
      this.components().delete(component.guard.id);
      this.guards.delete(component.guard.id);
      this.detachHooksIfSafe();
    }
  }
  async recoverExternal(component) {
    if (component.busy) throw new PackageRuntimeHoldError(component.guard.id, "Plugin recovery is already owned by an earlier attempt");
    component.busy = true;
    try {
      await this.recover(component);
    } finally {
      this.end(component);
    }
  }
  async recover(component) {
    const { guard, manager } = component;
    if (!this.owned(component)) throw new PackageRuntimeHoldError(guard.id, "The protected runtime recovery owner changed");
    if (component.pending && !component.pending.settled) throw new PackageRuntimeHoldError(guard.id, "The previous plugin runtime operation has not finished; only this component remains held");
    component.pending = void 0;
    this.retire(component);
    const cleanup = guard.cleanup;
    guard.cleanup = true;
    try {
      const instance = manager.plugins[guard.id];
      if (instance) {
        try {
          this.fence(guard, instance);
        } catch (e) {
          this.hold(guard.id, "The plugin has an unsupported settings override; all verified checkpoints remain protected");
        }
        guard.approved.delete(instance);
        await this.lifecycle(component, "disable", () => manager.disablePlugin(guard.id));
        if (manager.plugins[guard.id]) throw new Error("The failed plugin remained active after managed suspension");
        this.activeFences.delete(instance);
      }
      await this.drain(guard, guard.incoming !== void 0);
      if (guard.incoming) await this.lifecycle(component, "settings recovery", () => this.restoreIncoming(guard));
      component.needsRecovery = false;
    } catch (error) {
      component.needsRecovery = true;
      throw error instanceof PackageRuntimeHoldError ? error : new PackageRuntimeHoldError(guard.id, "Runtime settings recovery remains held; all verified checkpoints were retained");
    } finally {
      guard.cleanup = cleanup;
    }
  }
  require(id) {
    if (this.closed || id === "gib-sync" || !isSafeVaultPath(id) || /[\\/:*?"<>|\x00-\x1f]/.test(id) || id.endsWith(".") || id.trim() !== id || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(id)) throw new Error("Invalid managed plugin runtime scope");
    const manager = this.manager();
    if (!manager || !manager.plugins || !manager.manifests || !(manager.enabledPlugins instanceof Set) || typeof manager.disablePlugin !== "function" || typeof manager.enablePlugin !== "function" || typeof manager.loadManifest !== "function") throw new PackageRuntimeHoldError(id, "This Obsidian version cannot safely refresh a complete plugin package; existing settings and files were retained");
    return manager;
  }
  async hash(path, cleanup = false) {
    const stat = await this.adapter.stat(path);
    if (!stat) return null;
    if (stat.type !== "file") throw new Error("A managed plugin file is not a regular file; runtime activation remains held");
    return hashAdapterFile(this.adapter, path, cleanup ? () => {
    } : this.checkpoint, cleanup ? () => new Promise((resolve) => setTimeout(resolve, 0)) : this.cooperate, stat.size < 8 * 1024 * 1024);
  }
  async proof(id, cleanup = false) {
    const root2 = this.pluginRoot(id);
    return { manifest: await this.hash(`${root2}/manifest.json`, cleanup), main: await this.hash(`${root2}/main.js`, cleanup), data: await this.hash(`${root2}/data.json`, cleanup) };
  }
  complete(proof) {
    return proof.manifest !== null && proof.main !== null;
  }
  async mkdir(path) {
    for (const prefix of path.split("/").map((_, index, parts) => parts.slice(0, index + 1).join("/"))) if (!await this.adapter.exists(prefix)) await this.adapter.mkdir(prefix);
  }
  recoveryRoot(id) {
    return `.gib-sync/local-recovery/runtime-${crypto.randomUUID()}/.obsidian/plugins/${id}`;
  }
  trackWrite(guard, save, verify) {
    const writing = Promise.resolve().then(save).then(async () => {
      if (verify && guard.phase === "loading") guard.verifiedData = await this.hash(`${this.pluginRoot(guard.id)}/data.json`, true);
    }).catch((error) => {
      guard.writeFailure = error instanceof Error ? error.message : String(error);
      throw error;
    });
    guard.writes.add(writing);
    void writing.then(() => guard.writes.delete(writing), () => guard.writes.delete(writing));
    return writing;
  }
  async drain(guard, ignoreFailure = false) {
    const deadline = Date.now() + this.settingsWriteTimeoutMs;
    for (let rounds = 0; guard.writes.size && rounds < 16; rounds++) {
      const remaining = deadline - Date.now();
      if (remaining <= 0) throw new Error("Plugin settings writes timed out; no incoming files were activated");
      let timer;
      try {
        await Promise.race([Promise.allSettled([...guard.writes]), new Promise((_, reject) => {
          timer = setTimeout(() => reject(new Error("Plugin settings writes timed out; no incoming files were activated")), remaining);
        })]);
      } finally {
        if (timer !== void 0) clearTimeout(timer);
      }
    }
    if (guard.writes.size) throw new Error("Plugin settings writes did not finish their managed suspension");
    if (guard.writeFailure && !ignoreFailure) throw new Error(`Plugin settings could not be persisted: ${guard.writeFailure}`);
  }
  fence(guard, instance) {
    var _a;
    const saved = (_a = this.originalInstanceSaves.get(instance)) != null ? _a : Object.hasOwn(instance, "saveData") ? instance.saveData : this.originalSave;
    this.originalInstanceSaves.set(instance, saved);
    const descriptor = Object.getOwnPropertyDescriptor(instance, "saveData"), owner = this;
    const wrapper = async function(value) {
      if (guard.phase === "unloading" && instance === guard.previous || guard.approved.has(instance)) return owner.trackWrite(guard, () => saved.call(instance, value), instance !== guard.previous);
      await owner.preserveSave(guard.id, value, instance);
    };
    Object.defineProperty(instance, "saveData", { configurable: true, writable: true, value: wrapper });
    this.activeFences.set(instance, { descriptor, wrapper });
  }
  restoreFence(instance) {
    const fence = this.activeFences.get(instance);
    if (!fence || instance.saveData !== fence.wrapper) return;
    if (fence.descriptor) Object.defineProperty(instance, "saveData", fence.descriptor);
    else delete instance.saveData;
    this.activeFences.delete(instance);
  }
  async protectIncoming(guard, proof) {
    if (typeof this.adapter.copy !== "function" || typeof this.adapter.rename !== "function") throw new Error("This adapter cannot protect incoming plugin settings during runtime activation");
    const incoming = { proof };
    if (proof.data !== null) {
      const root2 = this.recoveryRoot(guard.id);
      await this.mkdir(root2);
      const destination = `${root2}/data.json`;
      await this.adapter.copy(`${this.pluginRoot(guard.id)}/data.json`, destination);
      if (await this.hash(destination, true) !== proof.data || await this.hash(`${this.pluginRoot(guard.id)}/data.json`, guard.cleanup) !== proof.data) throw new Error("Incoming settings changed while their runtime checkpoint was being protected");
      incoming.dataCopy = destination;
    }
    guard.incoming = incoming;
  }
  async restoreIncoming(guard) {
    const incoming = guard.incoming;
    if (!incoming) return;
    const path = `${this.pluginRoot(guard.id)}/data.json`, current = await this.hash(path, true);
    if (current === incoming.proof.data) return;
    if (incoming.proof.data !== null && (!incoming.dataCopy || await this.hash(incoming.dataCopy, true) !== incoming.proof.data)) throw new Error("Protected incoming settings failed verification; runtime activation remains held");
    let recovery = incoming.recovery;
    if (!recovery) {
      const root2 = this.recoveryRoot(guard.id);
      await this.mkdir(root2);
      recovery = { path: `${root2}/data.json`, expected: current, vacated: current === null };
      incoming.recovery = recovery;
    } else {
      const moved = await this.hash(recovery.path, true);
      if (!recovery.vacated && moved === recovery.expected && moved !== null && current === null) recovery.vacated = true;
      if (recovery.vacated && recovery.expected !== null && moved !== recovery.expected) throw new Error("Moved runtime settings changed after protection; their bytes and incoming checkpoints were retained");
      if (recovery.vacated && current !== null || !recovery.vacated && current !== recovery.expected) throw new Error("Competing settings appeared after an interrupted recovery; their public file and both checkpoints were retained");
    }
    if (!recovery.vacated && current !== null) {
      if (await this.hash(path, true) !== current) throw new Error("Runtime settings changed before their recovery move; all checkpoints were retained");
      await this.adapter.rename(path, recovery.path);
      recovery.vacated = true;
      if (await this.hash(recovery.path, true) !== current) throw new Error("Runtime settings changed during their recovery move; all moved bytes and incoming checkpoints were retained");
    }
    if (await this.adapter.exists(path)) throw new Error("Competing settings appeared during recovery; their public file and both protected copies were retained");
    if (incoming.proof.data !== null) await this.adapter.copy(incoming.dataCopy, path);
    if (await this.hash(path, true) !== incoming.proof.data) throw new Error("Incoming settings restoration did not verify; both protected copies were retained");
    this.hold(guard.id, "A plugin wrote settings outside its fresh-load fence; incoming and runtime-written versions were protected", false);
  }
  async preserveSave(id, value, instance) {
    try {
      const root2 = this.recoveryRoot(id);
      await this.mkdir(root2);
      const shadow = Object.create(instance);
      shadow.manifest = { ...instance.manifest, dir: root2 };
      await this.originalSave.call(shadow, value);
      if (await this.hash(`${root2}/data.json`, true) === null) throw new Error("The protected late plugin settings save was not persisted");
      this.hold(id, "A stale plugin runtime save was protected in local recovery instead of replacing incoming settings", false);
    } catch (error) {
      this.hold(id, "A late plugin save could not be protected; incoming settings were not overwritten");
      throw error;
    }
  }
  async quiesce(id) {
    this.checkpoint();
    const manager = this.require(id), component = await this.begin(id, manager);
    try {
      await this.quiesceOwned(component);
    } finally {
      this.end(component);
    }
  }
  async quiesceOwned(component) {
    const { manager } = component, id = component.guard.id;
    let guard = component.guard;
    if ((guard == null ? void 0 : guard.phase) === "quiesced") {
      try {
        await this.drain(guard);
        if (manager.plugins[id]) throw new Error("The plugin is still running while its package is held");
        if (!guard.prior) guard.prior = await this.proof(id);
        this.checkpoint();
        return;
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        this.hold(id, message);
        throw new PackageRuntimeHoldError(id, message);
      }
    }
    if (guard.phase === "active") {
      guard.loadToken = void 0;
      guard = this.newGuard(id, manager);
      component.guard = guard;
      this.guards.set(id, guard);
    }
    try {
      if (guard.previous) {
        this.fence(guard, guard.previous);
        await this.lifecycle(component, "disable", () => manager.disablePlugin(id));
        await this.drain(guard);
        if (manager.plugins[id]) throw new Error("The plugin did not finish its managed suspension");
      }
      guard.phase = "quiesced";
      if (guard.previous) this.activeFences.delete(guard.previous);
      guard.prior = await this.proof(id);
      this.checkpoint();
    } catch (error) {
      guard.phase = "quiesced";
      guard.loadToken = void 0;
      guard.approved = /* @__PURE__ */ new WeakSet();
      if (guard.previous) {
        if (manager.plugins[id] === guard.previous && (!component.pending || component.pending.settled)) {
          this.restoreFence(guard.previous);
          this.guards.delete(id);
          if (this.owned(component)) this.components().delete(id);
          else if (this.components().get(id) === component) this.components().delete(id);
        } else if (manager.plugins[id] !== guard.previous) this.activeFences.delete(guard.previous);
      }
      const message = error instanceof Error ? error.message : String(error);
      this.hold(id, message);
      throw new PackageRuntimeHoldError(id, message);
    }
  }
  async wanted(id, fallback) {
    const root2 = this.pluginRoot(id), directory = root2.slice(0, root2.lastIndexOf("/plugins/")), path = `${directory}/community-plugins.json`, stat = await this.adapter.stat(path);
    if ((stat == null ? void 0 : stat.type) !== "file") return fallback;
    if (stat.size > 512 * 1024) throw new Error("Plugin enablement exceeds its safe runtime budget");
    const enabled = JSON.parse(new TextDecoder().decode(new Uint8Array(await this.adapter.readBinary(path))));
    if (!Array.isArray(enabled) || enabled.some((value) => typeof value !== "string")) throw new Error("Plugin enablement is not a valid list");
    return enabled.includes(id);
  }
  async refreshManifest(component, id, proof, cleanup = false) {
    const { manager } = component;
    const path = `${this.pluginRoot(id)}/manifest.json`, stat = await this.adapter.stat(path);
    if ((stat == null ? void 0 : stat.type) !== "file" || stat.size > 128 * 1024) throw new Error("The plugin manifest exceeds its safe runtime budget");
    const raw = JSON.parse(new TextDecoder().decode(new Uint8Array(await this.adapter.readBinary(path))));
    if (raw.id !== id || typeof raw.version !== "string" || raw.isDesktopOnly !== void 0 && typeof raw.isDesktopOnly !== "boolean") throw new Error("The complete plugin manifest is invalid for managed runtime activation");
    await this.lifecycle(component, "manifest", () => manager.loadManifest(this.pluginRoot(id)));
    const manifest = manager.manifests[id];
    if (!manifest || manifest.id !== id || manifest.version !== raw.version || Boolean(manifest.isDesktopOnly) !== Boolean(raw.isDesktopOnly) || await this.hash(path, cleanup) !== proof.manifest) throw new Error("The updated plugin manifest cache did not refresh safely");
    return manifest;
  }
  async activate(id, expectedDataHash) {
    let loading, manager, component;
    try {
      let guard = this.guards.get(id);
      if (!(guard == null ? void 0 : guard.cleanup)) this.checkpoint();
      manager = this.require(id);
      component = await this.begin(id, manager);
      guard = component.guard;
      if (guard.phase !== "quiesced") {
        await this.quiesceOwned(component);
        guard = component.guard;
      }
      const proof = await this.proof(id, guard.cleanup);
      if (!this.complete(proof) || proof.data !== expectedDataHash) throw new PackageRuntimeHoldError(id, "The complete plugin and incoming settings must verify before runtime activation");
      const manifest = await this.refreshManifest(component, id, proof, guard.cleanup);
      const desired = await this.wanted(id, guard.wanted);
      guard.expected = expectedDataHash;
      guard.phase = "loading";
      if (!desired || this.isMobile && manifest.isDesktopOnly) {
        guard.activated = true;
        guard.phase = "quiesced";
        manager.enabledPlugins.delete(id);
        return;
      }
      await this.protectIncoming(guard, proof);
      loading = guard;
      guard.verifiedData = void 0;
      guard.writeFailure = void 0;
      const before = await this.proof(id, guard.cleanup);
      if (before.main !== proof.main || before.manifest !== proof.manifest || before.data !== proof.data) throw new Error("The complete plugin changed before its verified runtime activation");
      guard.loadToken = Symbol("fresh settings activation");
      guard.activationFailed = false;
      const result = await this.lifecycle(component, "enable", () => manager.enablePlugin(id)), instance = manager.plugins[id];
      await this.drain(guard);
      const after = await this.proof(id, guard.cleanup);
      if (after.main !== proof.main || after.manifest !== proof.manifest || after.data !== (guard.verifiedData === void 0 ? expectedDataHash : guard.verifiedData)) throw new Error("The plugin changed its package or settings outside the verified runtime fence");
      if (result === false || !instance || expectedDataHash !== null && !guard.approved.has(instance)) throw new Error("Fresh plugin settings were not acknowledged by the updated runtime");
      guard.approved.add(instance);
      this.fence(guard, instance);
      if (!guard.cleanup) this.checkpoint();
      guard.loadToken = void 0;
      guard.phase = "active";
      guard.activated = true;
      manager.enabledPlugins.add(id);
    } catch (error) {
      if (component && (loading || component.needsRecovery)) {
        this.retire(component);
        if (loading) loading.activationFailed = true;
        if (!component.pending || component.pending.settled) try {
          await this.recover(component);
        } catch (recovery) {
          this.hold(id, recovery instanceof Error ? recovery.message : String(recovery));
          throw recovery instanceof PackageRuntimeHoldError ? recovery : new PackageRuntimeHoldError(id, "Runtime settings recovery remains held; all verified checkpoints were retained");
        }
      }
      if (error instanceof PackageRuntimeHoldError) throw error;
      const message = error instanceof Error ? error.message : String(error);
      this.hold(id, message);
      throw new PackageRuntimeHoldError(id, message);
    } finally {
      if (component) this.end(component);
    }
  }
  async finish() {
    const manager = this.manager();
    if (!manager) return;
    for (const guard of this.guards.values()) {
      const component = this.components().get(guard.id);
      if ((component == null ? void 0 : component.busy) || (component == null ? void 0 : component.pending) && !component.pending.settled) {
        this.hold(guard.id, "Unfinished plugin runtime work remains protected; other vault content can finish syncing");
        continue;
      }
      if (guard.activated || guard.phase === "active" || guard.activationFailed || !guard.wanted) continue;
      try {
        guard.cleanup = true;
        const current = await this.proof(guard.id, true);
        if (!guard.prior || !this.complete(current) || current.main !== guard.prior.main || current.manifest !== guard.prior.manifest || current.data !== guard.prior.data) {
          this.hold(guard.id, "The interrupted package is protected until its complete recovery can resume");
          continue;
        }
        await this.activate(guard.id, current.data);
      } catch (error) {
        this.hold(guard.id, error instanceof Error ? error.message : String(error));
      }
    }
  }
  detachHooksIfSafe() {
    if (!this.closed || [...this.components().values()].some((component) => component.owner === this && (component.pending || component.needsRecovery || component.busy))) return;
    this.hooks.owners.delete(this);
    if (!this.hooks.owners.size) {
      if (this.prototype.loadData === this.hooks.load) this.prototype.loadData = this.originalLoad;
      if (this.prototype.saveData === this.hooks.save) this.prototype.saveData = this.originalSave;
      sharedHooks.delete(this.prototype);
    }
  }
  dispose() {
    var _a, _b;
    this.closed = true;
    for (const [instance] of this.activeFences) if (((_a = this.guards.get(instance.manifest.id)) == null ? void 0 : _a.phase) === "active" && ((_b = this.guards.get(instance.manifest.id)) == null ? void 0 : _b.approved.has(instance))) this.restoreFence(instance);
    for (const [id, component] of this.components()) if (component.owner === this) {
      if (!component.pending && !component.needsRecovery && !component.busy) this.components().delete(id);
      else this.retire(component);
    }
    this.detachHooksIfSafe();
  }
};

// src/atomic-package.ts
var ROOT4 = ".gib-sync/packages-v2";
var encoder5 = new TextEncoder();
var decoder4 = new TextDecoder();
var UUID3 = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
var AtomicPackageInstaller = class {
  constructor(adapter, scope, checkpoint, cooperate, hash, expected, beforeSwitch = async () => {
  }) {
    this.adapter = adapter;
    this.scope = scope;
    this.checkpoint = checkpoint;
    this.cooperate = cooperate;
    this.hash = hash;
    this.expected = expected;
    this.beforeSwitch = beforeSwitch;
    __publicField(this, "qualifiedParents", /* @__PURE__ */ new Set());
    __publicField(this, "journalSequences", /* @__PURE__ */ new Map());
    __publicField(this, "readSequences", /* @__PURE__ */ new WeakMap());
  }
  async mkdir(path) {
    for (const prefix of path.split("/").map((_, index, parts) => parts.slice(0, index + 1).join("/"))) if (!await this.adapter.exists(prefix)) await this.adapter.mkdir(prefix);
  }
  parent(root2) {
    return root2.slice(0, root2.lastIndexOf("/"));
  }
  privatePath(root2, id, suffix) {
    return `${this.parent(root2)}/.gib-sync-package-${id}.${suffix}`;
  }
  async managedHashes(root2, paths) {
    const result = {};
    for (const relative of paths) {
      const hash = await this.hash(`${root2}/${relative}`);
      if (hash) result[relative] = hash;
      await this.cooperate();
    }
    return result;
  }
  equal(a, b) {
    const keys = Object.keys(a);
    return keys.length === Object.keys(b).length && keys.every((path) => a[path] === b[path]);
  }
  async unmanaged(root2, managed) {
    const result = [];
    if (!await this.adapter.exists(root2)) return result;
    const queue = [""];
    while (queue.length) {
      this.checkpoint();
      const relative = queue.shift(), listing = await this.adapter.list(relative ? `${root2}/${relative}` : root2);
      for (const path of [...listing.files, ...listing.folders]) {
        const child = path.slice(root2.length + 1);
        if (managed.has(child)) continue;
        if ([...managed].some((item) => item.startsWith(`${child}/`))) {
          queue.push(child);
          continue;
        }
        result.push(child);
      }
      await this.cooperate();
    }
    return result;
  }
  async persist(_path, journal) {
    var _a;
    const payload = JSON.stringify(journal), hash = await hashBytes(encoder5.encode(payload)), sequence = ((_a = this.journalSequences.get(journal.id)) != null ? _a : 0) + 1, path = `${ROOT4}/${journal.id}-${crypto.randomUUID()}.journal.json`;
    await this.adapter.writeBinary(path, encoder5.encode(JSON.stringify({ payload, hash, sequence })).buffer);
    const saved = JSON.parse(decoder4.decode(new Uint8Array(await this.adapter.readBinary(path))));
    if (saved.payload !== payload || saved.hash !== hash) throw new Error("The complete plugin package journal did not persist exactly");
    this.journalSequences.set(journal.id, sequence);
    for (const old of (await this.adapter.list(ROOT4)).files) if (old !== path && old.startsWith(`${ROOT4}/${journal.id}-`) && old.endsWith(".journal.json")) await this.adapter.remove(old);
  }
  validHashes(value) {
    return value && typeof value === "object" && !Array.isArray(value) && Object.entries(value).every(([path, hash]) => isSafeVaultPath(path) && /^[a-f0-9]{64}$/.test(hash));
  }
  async read(path) {
    var _a;
    const saved = JSON.parse(decoder4.decode(new Uint8Array(await this.adapter.readBinary(path))));
    if (await hashBytes(encoder5.encode(saved.payload)) !== saved.hash) throw new Error("Incomplete package recovery journal; all versions were retained");
    const journal = JSON.parse(saved.payload);
    if (journal.scope !== this.scope()) return null;
    if (journal.version !== 2 || !UUID3.test(journal.id) || !isSafeVaultPath(journal.root) || !/^.+\/plugins\/(?!gib-sync$)[^/]+$/.test(journal.root) || journal.stage !== this.privatePath(journal.root, journal.id, "stage") || journal.backup !== this.privatePath(journal.root, journal.id, "original") || !["prepared", "backed-up", "promoting", "installed", "local-changed"].includes(journal.phase) || !this.validHashes(journal.prior) || !this.validHashes(journal.target) || !Array.isArray(journal.unmanaged) || journal.unmanaged.some((relative) => !isSafeVaultPath(relative)) || !new RegExp(`^${ROOT4.replaceAll(".", "\\.")}/${journal.id}-[0-9a-f-]+\\.journal\\.json$`).test(path) || !Number.isSafeInteger(saved.sequence)) throw new Error("Invalid package recovery ownership");
    this.journalSequences.set(journal.id, Math.max((_a = this.journalSequences.get(journal.id)) != null ? _a : 0, saved.sequence));
    this.readSequences.set(journal, saved.sequence);
    return journal;
  }
  async records() {
    let paths;
    try {
      paths = (await this.adapter.list(ROOT4)).files;
    } catch (e) {
      return [];
    }
    const records2 = /* @__PURE__ */ new Map(), invalid = [];
    for (const path of paths) {
      if (!/^\.gib-sync\/packages-v2\/[0-9a-f-]+\.journal\.json$/.test(path)) continue;
      try {
        const journal = await this.read(path);
        if (!journal) continue;
        const sequence = this.readSequences.get(journal);
        if (!records2.has(journal.id) || records2.get(journal.id).sequence < sequence) records2.set(journal.id, { path, journal, sequence });
      } catch (e) {
        invalid.push(path);
      }
    }
    for (const path of invalid) {
      const id = path.slice(ROOT4.length + 1, ROOT4.length + 37);
      if (!records2.has(id)) throw new Error("A complete-package recovery record could not be verified; all directories were retained");
    }
    return [...records2.values()];
  }
  async qualify(root2) {
    const parent = this.parent(root2);
    if (this.qualifiedParents.has(parent)) return;
    if (typeof this.adapter.getResourcePath !== "function" || typeof this.adapter.copy !== "function" || typeof this.adapter.rename !== "function") throw new PackageRuntimeHoldError(root2.split("/").at(-1), "This adapter does not expose native complete-package activation. Existing plugin files and settings are unchanged.");
    await this.mkdir(parent);
    const id = crypto.randomUUID(), probe = this.privatePath(root2, id, "probe"), source = `${probe}/source`, collision = `${probe}/collision`, destination = `${probe}/destination`, marker = encoder5.encode("gib-sync-directory-probe-v2");
    await this.mkdir(source);
    await this.mkdir(collision);
    await this.adapter.writeBinary(`${source}/marker`, marker.buffer);
    await this.adapter.writeBinary(`${collision}/racer`, marker.buffer);
    let collisionRejected = false;
    try {
      await this.adapter.rename(source, collision);
    } catch (e) {
      collisionRejected = true;
    }
    const expectedHash = await hashBytes(marker);
    if (!collisionRejected || await this.hash(`${source}/marker`) !== expectedHash || await this.hash(`${collision}/racer`) !== expectedHash) throw new Error("Directory activation collision semantics are unsupported; the private probe and all plugin originals were retained.");
    let finished = false, failed;
    const switching = this.adapter.rename(source, destination).then(() => {
      finished = true;
    }, (error) => {
      failed = error;
      finished = true;
    });
    let overlapping = false;
    while (!finished) {
      const observed = await this.adapter.list(probe);
      if (observed.folders.includes(source) && observed.folders.includes(destination)) overlapping = true;
      await this.cooperate();
    }
    await switching;
    this.checkpoint();
    if (failed || overlapping || await this.adapter.exists(source) || await this.hash(`${destination}/marker`) !== expectedHash) throw new Error("The adapter did not demonstrate a native whole-directory switch; plugin activation is safely held.");
    await this.adapter.remove(`${destination}/marker`);
    await this.adapter.remove(`${collision}/racer`);
    await this.adapter.rmdir(destination, false);
    await this.adapter.rmdir(collision, false);
    await this.adapter.rmdir(probe, false);
    this.qualifiedParents.add(parent);
  }
  async moveUnmanaged(journal, path) {
    for (const relative of journal.unmanaged) {
      const source = `${journal.backup}/${relative}`, destination = `${journal.stage}/${relative}`, hasSource = await this.adapter.exists(source), hasDestination = await this.adapter.exists(destination);
      if (hasSource && hasDestination) throw new Error("Two device-local cache copies exist during package recovery; both were retained");
      if (!hasSource && !hasDestination) throw new Error("Device-local package content is missing from both saved locations; activation is held");
      if (hasSource) {
        await this.mkdir(destination.slice(0, destination.lastIndexOf("/")));
        await this.adapter.rename(source, destination);
        this.checkpoint();
      }
      await this.cooperate();
    }
    await this.persist(path, journal);
  }
  async restoreChangedOriginal(journal, path) {
    var _a;
    journal.phase = "local-changed";
    await this.persist(path, journal);
    this.checkpoint();
    if (!await this.adapter.exists(journal.backup)) {
      if (await this.adapter.exists(journal.root)) return;
      throw new Error("The changed original package is unavailable; all saved directories were retained");
    }
    const managed = /* @__PURE__ */ new Set([...Object.keys(journal.prior), ...Object.keys(journal.target)]);
    if (await this.adapter.exists(journal.root)) {
      if (!this.equal(await this.managedHashes(journal.root, managed), journal.target) || await this.adapter.exists(journal.stage)) throw new AdapterFileChangedError(journal.root);
      this.expected(journal.root, "folder");
      await this.adapter.rename(journal.root, journal.stage);
      this.checkpoint();
      if (!this.equal(await this.managedHashes(journal.stage, managed), journal.target)) throw new Error("Incoming package changed during reversal; both complete copies were retained");
    }
    for (const relative of journal.unmanaged) {
      const source = `${journal.stage}/${relative}`, destination = `${journal.backup}/${relative}`;
      if (!await this.adapter.exists(source)) continue;
      if (await this.adapter.exists(destination)) throw new Error("Concurrent device-local package content exists in both originals; activation is held without discarding either copy");
      await this.mkdir(destination.slice(0, destination.lastIndexOf("/")));
      await this.adapter.rename(source, destination);
      this.checkpoint();
    }
    if (await this.adapter.exists(journal.root)) throw new AdapterFileChangedError(journal.root);
    const changed = await this.managedHashes(journal.backup, managed);
    for (const relative of managed) this.expected(`${journal.root}/${relative}`, (_a = changed[relative]) != null ? _a : null);
    this.expected(journal.root, "folder");
    await this.adapter.rename(journal.backup, journal.root);
    this.checkpoint();
    await this.persist(path, journal);
  }
  async guardOriginal(journal, path) {
    const managed = /* @__PURE__ */ new Set([...Object.keys(journal.prior), ...Object.keys(journal.target)]);
    if (await this.adapter.exists(journal.backup) && !this.equal(await this.managedHashes(journal.backup, managed), journal.prior)) {
      await this.beforeSwitch(journal.root);
      await this.restoreChangedOriginal(journal, path);
      throw new AdapterFileChangedError(journal.root);
    }
  }
  async recover(snapshotId) {
    const handled = /* @__PURE__ */ new Set();
    for (const { path, journal } of await this.records()) {
      this.checkpoint();
      const managed = /* @__PURE__ */ new Set([...Object.keys(journal.prior), ...Object.keys(journal.target)]);
      if (journal.phase === "local-changed") {
        if (await this.adapter.exists(journal.backup)) {
          await this.beforeSwitch(journal.root);
          await this.restoreChangedOriginal(journal, path);
        }
        continue;
      }
      if (journal.phase === "installed") {
        await this.guardOriginal(journal, path);
        if (journal.snapshotId === snapshotId && this.equal(await this.managedHashes(journal.root, managed), journal.target)) handled.add(journal.root);
        continue;
      }
      await this.beforeSwitch(journal.root);
      await this.qualify(journal.root);
      const current = await this.managedHashes(journal.root, managed);
      if (this.equal(current, journal.target) && await this.adapter.exists(journal.root)) {
        await this.guardOriginal(journal, path);
        journal.phase = "installed";
        await this.persist(path, journal);
        if (journal.snapshotId === snapshotId) handled.add(journal.root);
        continue;
      }
      if (journal.phase === "prepared" && !await this.adapter.exists(journal.backup) && await this.adapter.exists(journal.root)) {
        await this.adapter.remove(path);
        continue;
      }
      if (await this.adapter.exists(journal.root)) throw new AdapterFileChangedError(journal.root);
      await this.guardOriginal(journal, path);
      if (!this.equal(await this.managedHashes(journal.backup, managed), journal.prior) || !this.equal(await this.managedHashes(journal.stage, managed), journal.target)) throw new Error("A saved complete plugin package failed verification; originals were retained");
      if (!Object.keys(journal.target).length) {
        journal.phase = "installed";
        await this.persist(path, journal);
        continue;
      }
      journal.unmanaged = [.../* @__PURE__ */ new Set([...journal.unmanaged, ...await this.unmanaged(journal.backup, managed)])];
      await this.persist(path, journal);
      await this.moveUnmanaged(journal, path);
      await this.guardOriginal(journal, path);
      journal.phase = "promoting";
      await this.persist(path, journal);
      this.checkpoint();
      await this.adapter.rename(journal.stage, journal.root);
      this.checkpoint();
      if (!this.equal(await this.managedHashes(journal.root, managed), journal.target)) throw new Error("The promoted package did not verify; original settings remain in local recovery");
      await this.guardOriginal(journal, path);
      journal.phase = "installed";
      await this.persist(path, journal);
      if (journal.snapshotId === snapshotId) handled.add(journal.root);
    }
    return handled;
  }
  async install(root2, desired, observed, snapshotId, stageFile) {
    var _a;
    this.checkpoint();
    await this.qualify(root2);
    await this.mkdir(ROOT4);
    const id = crypto.randomUUID(), stage = this.privatePath(root2, id, "stage"), backup = this.privatePath(root2, id, "original"), journalPath = `${ROOT4}/${id}.journal.json`;
    await this.mkdir(stage);
    const managed = new Set([...desired, ...observed].map((entry) => entry.path.slice(root2.length + 1))), prior = await this.managedHashes(root2, managed);
    for (const entry of observed) if (prior[entry.path.slice(root2.length + 1)] !== entry.hash) throw new AdapterFileChangedError(entry.path);
    const unmanaged = await this.unmanaged(root2, managed);
    for (const entry of desired) {
      const destination = `${stage}/${entry.path.slice(root2.length + 1)}`;
      await this.mkdir(destination.slice(0, destination.lastIndexOf("/")));
      await stageFile(entry, destination);
      if (await this.hash(destination) !== entry.hash) throw new Error(`Staged plugin file did not verify: ${entry.path}`);
      await this.cooperate();
    }
    const target = await this.managedHashes(stage, managed);
    if (!this.equal(prior, await this.managedHashes(root2, managed))) throw new AdapterFileChangedError(root2);
    const journal = { version: 2, id, scope: this.scope(), root: root2, stage, backup, phase: "prepared", prior, target, unmanaged, snapshotId };
    await this.persist(journalPath, journal);
    this.checkpoint();
    for (const relative of managed) this.expected(`${root2}/${relative}`, (_a = target[relative]) != null ? _a : null);
    if (await this.adapter.exists(root2)) {
      await this.adapter.rename(root2, backup);
      this.checkpoint();
      if (!this.equal(prior, await this.managedHashes(backup, managed))) {
        if (!await this.adapter.exists(root2)) await this.adapter.rename(backup, root2);
        throw new AdapterFileChangedError(root2);
      }
    }
    if (await this.adapter.exists(backup)) journal.unmanaged = [.../* @__PURE__ */ new Set([...journal.unmanaged, ...await this.unmanaged(backup, managed)])];
    journal.phase = "backed-up";
    await this.persist(journalPath, journal);
    this.checkpoint();
    if (!desired.length) {
      journal.phase = "installed";
      await this.persist(journalPath, journal);
      return;
    }
    await this.moveUnmanaged(journal, journalPath);
    await this.guardOriginal(journal, journalPath);
    if (await this.adapter.exists(root2)) throw new AdapterFileChangedError(root2);
    journal.phase = "promoting";
    await this.persist(journalPath, journal);
    this.checkpoint();
    await this.adapter.rename(stage, root2);
    this.checkpoint();
    if (!this.equal(target, await this.managedHashes(root2, managed))) throw new Error("Activated complete package did not verify; original settings remain recoverable");
    await this.guardOriginal(journal, journalPath);
    journal.phase = "installed";
    await this.persist(journalPath, journal);
  }
  async originals() {
    const result = [];
    for (const { journal } of await this.records()) if (await this.adapter.exists(journal.backup)) result.push({ path: journal.backup, packageRoot: journal.root, snapshotId: journal.snapshotId });
    return result;
  }
};

// src/conflict-store.ts
var ROOT5 = ".gib-sync/conflicts-v2";
var encoder6 = new TextEncoder();
var decoder5 = new TextDecoder();
var ConflictStore = class {
  constructor(adapter, scope) {
    this.adapter = adapter;
    this.scope = scope;
    __publicField(this, "tail", Promise.resolve());
    __publicField(this, "sequences", /* @__PURE__ */ new Map());
  }
  async records() {
    var _a;
    let files;
    try {
      files = (await this.adapter.list(ROOT5)).files;
    } catch (e) {
      return [];
    }
    const records2 = /* @__PURE__ */ new Map(), invalid = [];
    for (const path of files) {
      if (!/^\.gib-sync\/conflicts-v2\/[0-9a-f-]+\.json$/.test(path)) continue;
      try {
        const packed = JSON.parse(decoder5.decode(new Uint8Array(await this.adapter.readBinary(path))));
        if (packed.scope !== this.scope()) continue;
        if (await hashBytes(encoder6.encode(packed.payload)) !== packed.hash || !Number.isSafeInteger(packed.sequence)) throw new Error("Unverified conflict record");
        const item = JSON.parse(packed.payload);
        if (!item.id || !isSafeVaultPath(item.path) || !Array.isArray(item.versions) || item.versions.some((side) => !isSafeVaultPath(side.path) || (side.hash === null ? side.deleted !== true || side.size !== 0 : !/^[a-f0-9]{64}$/.test(side.hash)) || side.sourcePath && !/^\.gib-sync\/conflict-originals\/[0-9a-f-]+\.bin$/.test(side.sourcePath))) throw new Error("Invalid preserved conflict record");
        this.sequences.set(item.id, Math.max((_a = this.sequences.get(item.id)) != null ? _a : 0, packed.sequence));
        if (!records2.has(item.id) || records2.get(item.id).sequence < packed.sequence) records2.set(item.id, { item, path, sequence: packed.sequence });
      } catch (e) {
        invalid.push(path);
      }
    }
    for (const path of invalid) {
      const id = path.slice(ROOT5.length + 1, ROOT5.length + 37);
      if (!records2.has(id)) throw new Error("A preserved conflict record is incomplete. Original copies were retained.");
    }
    return [...records2.values()];
  }
  async list() {
    await this.tail.catch(() => {
    });
    return (await this.records()).map((record) => record.item).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }
  save(item) {
    const scope = this.scope(), saving = this.tail.catch(() => {
    }).then(async () => {
      var _a;
      await this.records();
      if (!await this.adapter.exists(".gib-sync")) await this.adapter.mkdir(".gib-sync");
      if (!await this.adapter.exists(ROOT5)) await this.adapter.mkdir(ROOT5);
      const payload = JSON.stringify(item), hash = await hashBytes(encoder6.encode(payload)), path = `${ROOT5}/${item.id}-${crypto.randomUUID()}.json`, sequence = ((_a = this.sequences.get(item.id)) != null ? _a : 0) + 1;
      await this.adapter.writeBinary(path, encoder6.encode(JSON.stringify({ scope, payload, hash, sequence })).buffer);
      const packed = JSON.parse(decoder5.decode(new Uint8Array(await this.adapter.readBinary(path))));
      if (packed.payload !== payload || packed.hash !== hash) throw new Error("The conflict metadata did not persist exactly");
      this.sequences.set(item.id, sequence);
      for (const old of (await this.adapter.list(ROOT5)).files) if (old !== path && old.startsWith(`${ROOT5}/${item.id}-`)) await this.adapter.remove(old);
    });
    this.tail = saving;
    return saving;
  }
};

// src/folder-reconciliation.ts
function observeLocalFolders(base, remote, paths, intents, deviceId, deviceName) {
  const observed = [], claimed = /* @__PURE__ */ new Set(), latestCreation = new Map([...indexedIntentCreates(intents).values()].filter((event) => event.entity === "folder").map((event) => [event.path, event]));
  const remotePaths = new Map(remote.map((folder) => [folder.path, folder])), revision = (event, prior) => {
    var _a, _b, _c, _d;
    return { id: (_b = (_a = event == null ? void 0 : event.id) != null ? _a : prior == null ? void 0 : prior.id) != null ? _b : crypto.randomUUID(), parentId: (_c = prior == null ? void 0 : prior.id) != null ? _c : null, deviceId, deviceName, modifiedAt: (_d = event == null ? void 0 : event.at) != null ? _d : Date.now() };
  };
  for (const entry of base) {
    let path = entry.path, last;
    for (const event of intents) {
      if (event.entity !== "folder" || event.kind !== "move" || !event.from) continue;
      if (path === event.from || path.startsWith(`${event.from}/`)) {
        path = `${event.path}${path.slice(event.from.length)}`;
        last = event;
      }
    }
    if (!paths.has(path)) continue;
    const creation = latestCreation.get(path);
    if ((creation == null ? void 0 : creation.kind) === "create" && creation.targetId !== entry.folderId) continue;
    observed.push({ ...entry, path, ...last ? { revision: revision(last, entry.revision) } : {} });
    claimed.add(path);
  }
  for (const path of paths) {
    if (claimed.has(path)) continue;
    const creation = latestCreation.get(path);
    if ((creation == null ? void 0 : creation.kind) === "create" && creation.targetId) observed.push({ folderId: creation.targetId, path, revision: revision(creation) });
    else {
      const accepted = remotePaths.get(path);
      observed.push(accepted ? { ...accepted } : { folderId: crypto.randomUUID(), path, revision: revision() });
    }
  }
  return observed;
}
function reconcileAndAlignFolders(baseFolders, localFolders, remoteFolders, base, local, remote) {
  var _a, _b;
  const plan = reconcileFolders({ base: baseFolders, local: localFolders, remote: remoteFolders }), selected = new Map(plan.folders.map((folder) => [folder.folderId, folder])), byPath = new Map(plan.folders.map((folder) => [folder.path.normalize("NFC").toLowerCase(), folder])), groups = /* @__PURE__ */ new Map();
  const baseById = new Map(baseFolders.map((folder) => [folder.folderId, folder])), localById = new Map(localFolders.map((folder) => [folder.folderId, folder])), remoteById = new Map(remoteFolders.map((folder) => [folder.folderId, folder]));
  for (const id of /* @__PURE__ */ new Set([...baseById.keys(), ...localById.keys(), ...remoteById.keys()])) if (!selected.has(id)) {
    const list = (entry) => entry ? [entry] : [], tentative = reconcileFolders({ base: list(baseById.get(id)), local: list(localById.get(id)), remote: list(remoteById.get(id)) }).folders[0], canonical = tentative && byPath.get(tentative.path.normalize("NFC").toLowerCase());
    if (canonical) selected.set(id, canonical);
  }
  const align = (folders, files, side) => {
    var _a2, _b2;
    const aliases = folders.flatMap((folder) => {
      const chosen = selected.get(folder.folderId);
      return chosen && chosen.path !== folder.path ? [{ from: folder.path, to: chosen.path }] : [];
    }).sort((a, b) => b.from.length - a.from.length), next = /* @__PURE__ */ new Map();
    for (const [original, entry] of files) {
      const alias = aliases.find((item) => original.startsWith(`${item.from}/`)), path = alias ? `${alias.to}${original.slice(alias.from.length)}` : original, mapped = { ...entry, path, ...side === "local" && path !== original ? { sourcePath: (_a2 = entry.sourcePath) != null ? _a2 : original } : {} };
      const versions = (_b2 = groups.get(path)) != null ? _b2 : [];
      versions.push({ side, entry: mapped, originalPath: original });
      groups.set(path, versions);
      next.set(path, mapped);
    }
    files.clear();
    for (const [path, entry] of next) files.set(path, entry);
  };
  align(baseFolders, base, "base");
  align(localFolders, local, "local");
  align(remoteFolders, remote, "remote");
  const fileCollisions = [];
  for (const [path, versions] of groups) {
    const current = versions.filter((version) => version.side !== "base"), identities = new Set(current.map((version) => {
      var _a2;
      return (_a2 = version.entry.fileId) != null ? _a2 : `${version.originalPath}:${version.entry.hash}`;
    }));
    const namespaceCollision = ["base", "local", "remote"].some((side) => new Set(versions.filter((version) => version.side === side).map((version) => {
      var _a2;
      return (_a2 = version.entry.fileId) != null ? _a2 : version.originalPath;
    })).size > 1);
    if (identities.size < 2 || !namespaceCollision) continue;
    fileCollisions.push({ path, versions });
    const canonical = (_b = (_a = current.find((version) => version.side === "remote" && version.originalPath === path)) != null ? _a : current.find((version) => version.side === "remote")) != null ? _b : current[0], id = canonical.entry.fileId;
    for (const [side, map] of [["base", base], ["local", local], ["remote", remote]]) {
      const sameGeneration = versions.find((version) => version.side === side && version.entry.fileId === id);
      if (sameGeneration) map.set(path, sameGeneration.entry);
      else map.delete(path);
    }
  }
  return { ...plan, fileCollisions };
}

// src/engine.ts
var TEXT_EXTENSIONS = /* @__PURE__ */ new Set(["md", "txt", "canvas", "json", "jsonl", "css", "js", "ts", "yaml", "yml", "xml", "csv", "svg", "html"]);
var decoder6 = new TextDecoder();
var encoder7 = new TextEncoder();
var LOW_MEMORY_DOWNLOAD_BYTES = 8 * 1024 * 1024;
var MOBILE_WORK_BATCH = 2;
var DESKTOP_WORK_BATCH = 8;
var RETIRED_PATH_MAX_AGE = 90 * 24 * 60 * 60 * 1e3;
var RETIRED_PATH_LIMIT = 5e3;
var PROTECTED_FOLDER_ROOTS = /* @__PURE__ */ new Set([".obsidian", ".obsidian/plugins", ".obsidian/themes", ".trash", ".git", ".gib-sync"]);
var DISPOSABLE_FOLDER_METADATA = /* @__PURE__ */ new Set([".ds_store", ".nomedia", "desktop.ini", "thumbs.db"]);
function cooperativeYield() {
  const taskScheduler = globalThis.scheduler;
  if (typeof (taskScheduler == null ? void 0 : taskScheduler.yield) === "function") return taskScheduler.yield();
  if (typeof MessageChannel !== "undefined") return new Promise((resolve) => {
    const channel = new MessageChannel();
    channel.port1.onmessage = () => {
      channel.port1.close();
      channel.port2.close();
      resolve();
    };
    channel.port2.postMessage(void 0);
  });
  return Promise.resolve();
}
function exactArrayBuffer2(bytes2) {
  if (bytes2.buffer instanceof ArrayBuffer && bytes2.byteOffset === 0 && bytes2.byteLength === bytes2.buffer.byteLength) return bytes2.buffer;
  return bytes2.slice().buffer;
}
async function commitFingerprint(entries, folders = []) {
  const parents = /* @__PURE__ */ new Set();
  for (const entry of entries) {
    const parts = entry.path.split("/");
    for (let i = 1; i < parts.length; i++) parents.add(parts.slice(0, i).join("/"));
  }
  const files = entries.map(({ path, hash, size }) => [path, hash, size]).sort((a, b) => String(a[0]) < String(b[0]) ? -1 : String(a[0]) > String(b[0]) ? 1 : 0);
  const explicit = [...new Set(folders)].filter((path) => !parents.has(path)).sort();
  return hashBytes(encoder7.encode(JSON.stringify({ files, folders: explicit })));
}
var SyncSafetyError = class extends Error {
  constructor() {
    super(...arguments);
    __publicField(this, "name", "SyncSafetyError");
  }
};
var FileChangedDuringReadError = class extends Error {
  constructor(path) {
    super(`${path} changed or was deleted while Gib Sync was reading it. It was not uploaded; sync will quietly retry the current vault state.`);
    this.path = path;
    __publicField(this, "name", "FileChangedDuringReadError");
  }
};
var SyncEngine = class {
  constructor(adapter, api, getSettings, saveSettings, status, wait = (milliseconds) => new Promise((resolve) => window.setTimeout(resolve, milliseconds)), observeExpectedMutation = () => {
  }, yieldControl = cooperativeYield, isMobileDevice = false, canApplyLocalMutation = () => true, shouldContinue = () => true, packageRuntime) {
    this.adapter = adapter;
    this.api = api;
    this.getSettings = getSettings;
    this.saveSettings = saveSettings;
    this.status = status;
    this.wait = wait;
    this.observeExpectedMutation = observeExpectedMutation;
    this.yieldControl = yieldControl;
    this.isMobileDevice = isMobileDevice;
    this.canApplyLocalMutation = canApplyLocalMutation;
    this.shouldContinue = shouldContinue;
    this.packageRuntime = packageRuntime;
    __publicField(this, "running", null);
    __publicField(this, "operationTail", Promise.resolve());
    __publicField(this, "generation", 0);
    __publicField(this, "activeGeneration", 0);
    __publicField(this, "preparedPaths", /* @__PURE__ */ new Set());
    __publicField(this, "workSinceYield", 0);
    __publicField(this, "lastYieldAt", 0);
    __publicField(this, "inventory");
    __publicField(this, "intents");
    __publicField(this, "operations");
    __publicField(this, "packages");
    __publicField(this, "conflictStore");
    __publicField(this, "backgroundInventory", null);
    __publicField(this, "lastInventoryListingAt", 0);
    __publicField(this, "observedInventoryFolders", null);
    __publicField(this, "configAliases", []);
    __publicField(this, "canonicalNamespace", false);
    __publicField(this, "pendingRuntimeActivation", /* @__PURE__ */ new Map());
    __publicField(this, "pendingRuntimeFingerprints", /* @__PURE__ */ new Map());
    __publicField(this, "firstRun", true);
    __publicField(this, "workBatch", typeof navigator !== "undefined" && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent) ? MOBILE_WORK_BATCH : DESKTOP_WORK_BATCH);
    const scope = () => JSON.stringify([this.getSettings().vaultId, this.getSettings().deviceId, this.getSettings().vaultIdentity, this.getSettings().configDir, this.getSettings().syncBookmarks, this.getSettings().syncObsidianConfig, this.getSettings().syncPlugins, this.getSettings().exclusions]);
    this.inventory = new VaultInventory(this.adapter, scope, this.yieldControl, (size) => size < LOW_MEMORY_DOWNLOAD_BYTES || typeof this.api.supportsStreamUpload !== "function" || !this.api.supportsStreamUpload(), () => this.checkpoint());
    const journalScope = () => JSON.stringify([this.getSettings().vaultId, this.getSettings().deviceId]);
    this.intents = new IntentJournal(this.adapter, journalScope, this.yieldControl);
    this.operations = new OperationJournal(this.adapter, journalScope);
    this.packages = new AtomicPackageInstaller(this.adapter, journalScope, () => this.checkpoint(), () => this.cooperate(), (path) => this.savedHash(path), (path, hash) => this.expectLocalMutation(path, hash), (root2) => {
      var _a, _b;
      return (_b = (_a = this.packageRuntime) == null ? void 0 : _a.quiesce(root2.split("/").at(-1))) != null ? _b : Promise.resolve();
    });
    this.conflictStore = new ConflictStore(this.adapter, journalScope);
  }
  get verificationPending() {
    return this.inventory.pendingVerification;
  }
  expectLocalMutation(path, hash) {
    this.inventory.markDirty(path);
    this.observeExpectedMutation(path, hash);
  }
  setConfigAliases(aliases) {
    this.canonicalNamespace = true;
    this.configAliases = [...new Set(aliases)].filter((alias) => alias && alias !== ".obsidian").sort((a, b) => b.length - a.length);
  }
  get logicalConfigDir() {
    return this.canonicalNamespace ? ".obsidian" : this.getSettings().configDir;
  }
  canonicalSnapshot(snapshot) {
    var _a;
    if (!snapshot || !this.configAliases.length) return snapshot;
    const path = (value) => {
      for (const alias of this.configAliases) if (value === alias || value.startsWith(`${alias}/`)) return `.obsidian${value.slice(alias.length)}`;
      return value;
    };
    const entries = /* @__PURE__ */ new Map();
    for (const entry of [...snapshot.entries].sort((a, b) => Number(a.path === path(a.path)) - Number(b.path === path(b.path)))) {
      const normalized = path(entry.path), mapped = { ...entry, path: this.include(normalized) ? normalized : entry.path }, prior = entries.get(mapped.path);
      if (!prior || entry.path === mapped.path) entries.set(mapped.path, mapped);
    }
    const folderEntries = /* @__PURE__ */ new Map();
    for (const entry of [...(_a = snapshot.folderEntries) != null ? _a : []].sort((a, b) => Number(a.path === path(a.path)) - Number(b.path === path(b.path)))) {
      const mapped = { ...entry, path: path(entry.path) };
      if (!folderEntries.has(mapped.path) || entry.path === mapped.path) folderEntries.set(mapped.path, mapped);
    }
    return { ...snapshot, entries: [...entries.values()], folders: snapshot.folders ? [...new Set(snapshot.folders.map(path))] : void 0, folderEntries: [...folderEntries.values()], ...snapshot.folderRepair ? { folderRepair: { ...snapshot.folderRepair, retiredFolders: snapshot.folderRepair.retiredFolders.map(path).filter((value) => value !== ".obsidian" && !value.startsWith(".obsidian/")) } } : {} };
  }
  stop() {
    this.cancel();
    this.inventory.stop();
  }
  async recordIntent(kind, path, entity = "file", from) {
    this.inventory.markDirty(path);
    if (from) this.inventory.markMove(from, path);
    await this.intents.record(kind, path, entity, from);
  }
  verifyInventory() {
    if (this.backgroundInventory) return this.backgroundInventory;
    const requestedGeneration = this.generation;
    this.backgroundInventory = this.operationTail.catch(() => {
    }).then(async () => {
      this.activeGeneration = requestedGeneration;
      this.checkpoint();
      await this.inventory.ready();
      const changed = /* @__PURE__ */ new Set();
      if (!this.lastInventoryListingAt || Date.now() - this.lastInventoryListingAt >= 5 * 60 * 1e3) {
        const folders = /* @__PURE__ */ new Set(), paths = await this.listFiles("", folders), priorPaths = new Set(this.inventory.paths());
        for (const folder of this.acceptedFolders(paths)) folders.delete(folder);
        for (const path of paths) {
          await this.cooperate();
          const before = this.inventory.known(path), after = await this.inspectLocalFile(path);
          if (after && (before == null ? void 0 : before.hash) !== after.hash) changed.add(path);
          priorPaths.delete(path);
        }
        for (const path of priorPaths) changed.add(path);
        if (this.observedInventoryFolders && (folders.size !== this.observedInventoryFolders.size || [...folders].some((path) => !this.observedInventoryFolders.has(path)))) this.getSettings().fullScanRequired = true;
        this.observedInventoryFolders = folders;
        await this.inventory.finishListing(paths);
        this.lastInventoryListingAt = Date.now();
      }
      const result = await this.inventory.verifyStep();
      for (const path of result.changedPaths) changed.add(path);
      return { ...result, changedPaths: [...changed] };
    }).finally(() => {
      this.backgroundInventory = null;
    });
    this.operationTail = this.backgroundInventory;
    return this.backgroundInventory;
  }
  cancel() {
    this.generation++;
  }
  get isRunning() {
    return this.running !== null;
  }
  checkpoint() {
    if (this.activeGeneration !== this.generation || !this.shouldContinue()) throw new SyncCancelledError("Sync paused safely; accepted updates will resume from their saved checkpoint.");
  }
  async cooperate(force = false) {
    this.checkpoint();
    const now = typeof performance !== "undefined" ? performance.now() : Date.now();
    this.workSinceYield++;
    if (!force && this.workSinceYield < this.workBatch && now - this.lastYieldAt < 8) return;
    this.workSinceYield = 0;
    this.lastYieldAt = now;
    await this.yieldControl();
    this.checkpoint();
  }
  progress(current, total) {
    return current === 1 || current === total || current % 10 === 0;
  }
  sync() {
    if (this.running) return this.running;
    if (this.backgroundInventory) this.generation++;
    const requestedGeneration = this.generation;
    this.running = this.operationTail.catch(() => void 0).then(() => {
      this.activeGeneration = requestedGeneration;
      this.checkpoint();
      return this.run(0);
    }).finally(async () => {
      var _a;
      try {
        await ((_a = this.packageRuntime) == null ? void 0 : _a.finish());
        await this.cleanPreparedResults();
      } finally {
        this.running = null;
      }
    });
    this.operationTail = this.running;
    return this.running;
  }
  restoreAcceptedSnapshot() {
    if (this.backgroundInventory) this.generation++;
    const requestedGeneration = this.generation;
    const restoring = this.operationTail.catch(() => void 0).then(() => {
      this.activeGeneration = requestedGeneration;
      this.checkpoint();
      return this.restore();
    }).finally(() => {
      var _a;
      return (_a = this.packageRuntime) == null ? void 0 : _a.finish();
    });
    this.operationTail = restoring;
    return restoring;
  }
  ownedOperation(operation) {
    if (this.backgroundInventory) this.generation++;
    const requested = this.generation, task = this.operationTail.catch(() => {
    }).then(() => {
      this.activeGeneration = requested;
      this.checkpoint();
      return operation();
    }).finally(() => {
      var _a;
      return (_a = this.packageRuntime) == null ? void 0 : _a.finish();
    });
    this.operationTail = task;
    return task;
  }
  async activatePackages() {
    var _a, _b, _c;
    for (const [id, hash] of this.pendingRuntimeActivation) {
      this.checkpoint();
      try {
        await ((_a = this.packageRuntime) == null ? void 0 : _a.activate(id, hash));
        delete this.getSettings().packageHolds[id];
        this.pendingRuntimeActivation.delete(id);
        this.pendingRuntimeFingerprints.delete(id);
      } catch (error) {
        if (!(error instanceof PackageRuntimeHoldError)) throw error;
        const previous = this.getSettings().packageHolds[id], attempts = ((_b = previous == null ? void 0 : previous.attempts) != null ? _b : 0) + 1;
        this.getSettings().packageHolds[id] = { ...previous, fingerprint: (_c = this.pendingRuntimeFingerprints.get(id)) != null ? _c : previous == null ? void 0 : previous.fingerprint, kind: "activation", reason: error.message, at: Date.now(), attempts, retryAt: Date.now() + Math.min(3e5, 1e4 * 2 ** Math.min(attempts - 1, 5)) };
        this.pendingRuntimeActivation.delete(id);
        this.pendingRuntimeFingerprints.delete(id);
        this.status({ phase: "applying", message: error.message, level: "warning" });
      }
    }
  }
  async packageFingerprint(entries) {
    return hashBytes(encoder7.encode(JSON.stringify(entries.map((entry) => [entry.path, entry.hash, entry.size]).sort(([a], [b]) => String(a).localeCompare(String(b))))));
  }
  async queuePackageActivation(id, hash, entries) {
    this.pendingRuntimeActivation.set(id, hash);
    this.pendingRuntimeFingerprints.set(id, await this.packageFingerprint(entries));
  }
  async holdPackage(id, reason, kind, desired, observed) {
    var _a, _b, _c;
    const settings = this.getSettings(), previous = settings.packageHolds[id], fingerprint = await this.packageFingerprint(desired), same2 = (previous == null ? void 0 : previous.fingerprint) === fingerprint, attempts = same2 ? ((_a = previous == null ? void 0 : previous.attempts) != null ? _a : 0) + 1 : 1, priorEntries = (_b = previous == null ? void 0 : previous.priorEntries) != null ? _b : {};
    for (const entry of observed) {
      if (priorEntries[entry.path]) continue;
      const sourcePath = `.gib-sync/package-hold-originals/${crypto.randomUUID()}.bin`;
      await this.ensureParent(sourcePath);
      await this.adapter.copy((_c = entry.sourcePath) != null ? _c : entry.path, sourcePath);
      this.checkpoint();
      if (await this.savedHash(sourcePath) !== entry.hash) throw new FileChangedDuringReadError(entry.path);
      priorEntries[entry.path] = { ...this.manifestEntry(entry), sourcePath };
    }
    settings.packageHolds[id] = { reason, kind, at: Date.now(), attempts, retryAt: Date.now() + (kind === "incomplete" ? 3e5 : Math.min(3e5, 1e4 * 2 ** Math.min(attempts - 1, 5))), fingerprint, priorEntries };
  }
  async listConflictInbox() {
    const local = await this.conflictStore.list(), byId = new Map(local.map((item) => [item.id, item]));
    if (typeof this.api.conflictInbox === "function") try {
      for (const item of await this.api.conflictInbox()) {
        const prior = byId.get(item.id);
        byId.set(item.id, { ...item, versions: item.versions.map((side) => {
          var _a;
          return { ...side, ...((_a = prior == null ? void 0 : prior.versions.find((saved) => saved.id === side.id)) == null ? void 0 : _a.sourcePath) ? { sourcePath: prior.versions.find((saved) => saved.id === side.id).sourcePath } : {} };
        }) });
      }
    } catch (error) {
      if (!(error instanceof ApiError && error.status === 404)) throw error;
    }
    return [...byId.values()].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }
  async previewConflict(id) {
    const item = (await this.listConflictInbox()).find((item2) => item2.id === id);
    if (!item) throw new SyncSafetyError("This recorded conflict is no longer available");
    const texts = [];
    for (const side of item.versions) {
      if (side.hash === null || side.deleted || side.size > 128 * 1024 || !this.text(item.path)) {
        texts.push({ id: side.id, text: null, truncated: side.size > 128 * 1024 });
        continue;
      }
      const clear = side.sourcePath && await this.adapter.exists(side.sourcePath) ? new Uint8Array(await this.adapter.readBinary(side.sourcePath)) : await this.remoteBytes({ path: side.path, hash: side.hash, size: side.size, mtime: 0 }, this.bodyCache());
      if (await hashBytes(clear) !== side.hash) throw new SyncSafetyError("A preserved original did not verify; it was not used for preview or resolution");
      texts.push({ id: side.id, text: decoder6.decode(clear), truncated: false });
    }
    return { item, texts };
  }
  packageRecoveryOriginals() {
    return this.packages.originals();
  }
  resolveConflict(id, choice, combinedText) {
    return this.ownedOperation(async () => {
      var _a, _b;
      await this.recoverPendingBatch();
      const item = (await this.listConflictInbox()).find((item2) => item2.id === id);
      if (!item || item.state !== "open" || !item.originSnapshotId) throw new SyncSafetyError("This conflict is not ready for a new decision");
      if (!this.api.supportsOperationsV2()) throw new SyncSafetyError("The server must support safe operation decisions before this conflict can be resolved");
      const tree = await this.api.syncTree(), origin = this.canonicalSnapshot(await this.api.snapshot(item.originSnapshotId)), byPath = new Map(tree.files.map((entry) => [entry.path, entry])), originPaths = new Map(origin.entries.map((entry) => [entry.path, entry])), paths = [...new Set(item.versions.map((side) => {
        var _a2;
        return (_a2 = side.annotatedPath) != null ? _a2 : side.path;
      }))];
      for (const path of paths) {
        const current = byPath.get(path), atConflict = originPaths.get(path), expected = (_a = item.versions.find((side) => {
          var _a2;
          return ((_a2 = side.annotatedPath) != null ? _a2 : side.path) === path;
        })) == null ? void 0 : _a.annotatedHash;
        if (!current || current.hash !== expected || !current.revision || !(atConflict == null ? void 0 : atConflict.revision) || current.fileId !== atConflict.fileId || current.revision.id !== atConflict.revision.id) throw new SyncSafetyError("A newer edit exists in this conflict. Your files were not overwritten; review the newest version first");
      }
      const final = new Map(tree.files.map((entry) => [entry.path, { ...entry }])), before = paths.map((path) => {
        var _a2, _b2;
        return { path, hash: (_b2 = (_a2 = byPath.get(path)) == null ? void 0 : _a2.hash) != null ? _b2 : null };
      }), cache = this.bodyCache();
      if (choice === "both" && paths.length === 1 && !item.versions.some((side) => side.deleted)) {
      } else if (choice === "both") {
        for (const side of item.versions) {
          if (side.hash === null || side.deleted) continue;
          const path = (_b = side.annotatedPath) != null ? _b : side.path, current = byPath.get(path);
          final.set(path, { ...current, hash: side.hash, size: side.size, mtime: Date.now(), ...side.sourcePath ? { sourcePath: side.sourcePath } : {} });
        }
      } else {
        for (const path of paths) final.delete(path);
        const current = byPath.get(item.path);
        if (choice === "combine") {
          if (item.versions.some((side) => side.deleted) || typeof combinedText !== "string" || encoder7.encode(combinedText).length > 1024 * 1024) throw new SyncSafetyError("A combined decision requires two text originals and a result under 1 MB");
          await this.prepareResult(item.path, encoder7.encode(combinedText), final, cache);
          const entry = final.get(item.path);
          entry.fileId = current == null ? void 0 : current.fileId;
          entry.revision = current == null ? void 0 : current.revision;
        } else {
          const side = item.versions[choice === "this" ? 0 : 1];
          if (!side) throw new SyncSafetyError("The selected original is unavailable");
          if (side.hash !== null && !side.deleted) final.set(item.path, { ...current, path: item.path, hash: side.hash, size: side.size, mtime: Date.now(), ...side.sourcePath ? { sourcePath: side.sourcePath } : {} });
        }
      }
      const after = paths.map((path) => {
        var _a2, _b2;
        return { path, hash: (_b2 = (_a2 = final.get(path)) == null ? void 0 : _a2.hash) != null ? _b2 : null };
      });
      await this.commitDecision(tree, final, { id, kind: "resolve", choice, before, after }, cache);
    });
  }
  undoConflict(id) {
    return this.ownedOperation(async () => {
      var _a;
      await this.recoverPendingBatch();
      const item = (await this.listConflictInbox()).find((item2) => item2.id === id), resolution = item == null ? void 0 : item.resolution;
      if (!item || item.state !== "resolved" || !(resolution == null ? void 0 : resolution.undoable) || !resolution.before || !resolution.after || !resolution.afterIdentity || !item.originSnapshotId) throw new SyncSafetyError("This decision cannot be undone automatically after newer edits; preserved originals remain available");
      const tree = await this.api.syncTree();
      for (const guard of resolution.afterIdentity) {
        const entity = guard.deleted ? tree.tombstones.find((entry) => entry.targetId === guard.targetId) : tree.files.find((entry) => entry.fileId === guard.targetId);
        if (!entity || entity.path !== guard.path || ((_a = entity.revision) == null ? void 0 : _a.id) !== guard.revisionId) throw new SyncSafetyError("A newer causal revision prevents undo. No content was overwritten");
      }
      const origin = this.canonicalSnapshot(await this.api.snapshot(item.originSnapshotId)), final = new Map(tree.files.map((entry) => [entry.path, { ...entry }])), intents = [];
      for (const before of resolution.before) {
        if (before.hash === null) {
          final.delete(before.path);
          continue;
        }
        const original = origin.entries.find((entry) => entry.path === before.path && entry.hash === before.hash);
        if (!original) throw new SyncSafetyError("The exact undo original is unavailable; current files were retained");
        const current = tree.files.find((entry) => entry.path === before.path);
        final.set(before.path, { ...original, ...current ? { fileId: current.fileId, revision: current.revision } : { fileId: crypto.randomUUID() }, mtime: Date.now() });
        if (!current) intents.push({ id: crypto.randomUUID(), sequence: 0, kind: "create", entity: "file", path: before.path, at: Date.now(), targetId: final.get(before.path).fileId });
      }
      await this.commitDecision(tree, final, { id, kind: "undo", resolutionId: resolution.id, before: resolution.after, after: resolution.before }, this.bodyCache(), intents);
    });
  }
  restoreLocalRecovery(sourcePath) {
    return this.ownedOperation(async () => {
      await this.recoverPendingBatch();
      let path = null;
      if (sourcePath.startsWith(".gib-sync/local-recovery/")) path = sourcePath.split("/").slice(3).join("/");
      else {
        const packageOriginal = (await this.packages.originals()).find((item) => sourcePath.startsWith(`${item.path}/`));
        if (packageOriginal) path = `${packageOriginal.packageRoot}${sourcePath.slice(packageOriginal.path.length)}`;
      }
      if (!path || !this.include(path)) throw new SyncSafetyError("This protected copy belongs to an excluded or device-local path. The recovery original is unchanged");
      const stat = await this.adapter.stat(sourcePath);
      if ((stat == null ? void 0 : stat.type) !== "file") throw new SyncSafetyError("The recovery original is unavailable");
      const hash = await this.savedHash(sourcePath);
      if (!hash) throw new SyncSafetyError("The recovery original could not be verified");
      if (!this.api.supportsOperationsV2()) throw new SyncSafetyError("Update the server to safely restore a protected original through the sync ledger");
      const tree = await this.api.syncTree(), current = tree.files.find((entry) => entry.path === path), final = new Map(tree.files.map((entry) => [entry.path, { ...entry }]));
      final.set(path, { ...current, path, hash, size: stat.size, mtime: Date.now(), sourcePath });
      const intents = current ? [] : [{ id: crypto.randomUUID(), sequence: 0, kind: "create", entity: "file", path, at: Date.now(), targetId: crypto.randomUUID() }];
      await this.commitDecision(tree, final, void 0, this.bodyCache(), intents);
    });
  }
  async recordDecision(record) {
    const action = record.conflictAction;
    if (!action || !record.receipt) return;
    if (action.kind === "resolve") await this.api.recordConflictResolution(action.id, record.batch.batchId, action.choice, action.after, action.before);
    else await this.api.recordConflictUndo(action.id, record.batch.batchId, action.resolutionId);
    const saved = (await this.listConflictInbox()).find((item) => item.id === action.id);
    if (saved) await this.conflictStore.save(saved);
  }
  async commitDecision(tree, final, conflictAction, bytes2, extraIntents = []) {
    var _a;
    const scanned = await this.scan(), physical = scanned.files, changed = new Set([.../* @__PURE__ */ new Set([...final.keys(), ...physical.keys()])].filter((path) => {
      var _a2, _b;
      return this.include(path) && ((_a2 = final.get(path)) == null ? void 0 : _a2.hash) !== ((_b = physical.get(path)) == null ? void 0 : _b.hash);
    }));
    for (const path of changed) {
      const accepted = tree.files.find((entry) => entry.path === path);
      if (await this.savedHash(path) !== ((_a = accepted == null ? void 0 : accepted.hash) != null ? _a : null) || !this.canApplyLocalMutation(path)) throw new FileChangedDuringReadError(path);
    }
    const intents = await this.intents.snapshot(), entries = [...final.values()].map((entry) => this.manifestEntry(entry)), batch = await buildOperationBatch(tree, entries, tree.folders.map((entry) => entry.path), [...intents, ...extraIntents], conflictAction ? "Resolve preserved conflict" : "Restore protected original", void 0, void 0, void 0, () => this.cooperate(true)), record = { batch, phase: "prepared", intentSequence: 0, priorHashes: Object.fromEntries([...changed].map((path) => {
      var _a2, _b;
      return [path, (_b = (_a2 = physical.get(path)) == null ? void 0 : _a2.hash) != null ? _b : null];
    })), priorEntries: Object.fromEntries([...changed].flatMap((path) => {
      const entry = physical.get(path);
      return entry ? [[path, this.manifestEntry(entry)]] : [];
    })), ...conflictAction ? { conflictAction } : {} };
    await this.operations.save(record);
    this.checkpoint();
    const remoteHashes = new Set(tree.files.map((entry) => entry.hash));
    for (const entry of final.values()) if (!remoteHashes.has(entry.hash) && entry.sourcePath) await this.uploadLocalFile(entry, bytes2);
    record.phase = "submitted";
    await this.operations.save(record);
    this.checkpoint();
    record.receipt = await this.api.operationBatch(batch);
    this.assertOwnedReceipt(record.receipt, batch);
    if (record.receipt.batchId !== batch.batchId) throw new SyncSafetyError("A decision received the wrong operation receipt");
    record.phase = "accepted";
    await this.operations.save(record);
    this.checkpoint();
    await this.stageAndApply(record.receipt.snapshot.id, final, this.snapshotFolders(record.receipt.snapshot), physical, /* @__PURE__ */ new Set(), scanned, [], bytes2, this.bodyCache(), record.receipt.snapshot.folderRepair, record.receipt.snapshot.createdAt);
    await this.recordDecision(record);
    await this.operations.clear();
    this.getSettings().fullScanRequired = true;
    await this.saveSettings();
  }
  async restore() {
    const settings = this.getSettings();
    if (!settings.deviceToken || !settings.vaultKey) throw new Error("Gib Sync is not configured");
    const scanned = await this.scan(), local = scanned.files, head = (await this.api.state()).head;
    this.checkpoint();
    if (!head && local.size) throw new SyncSafetyError("The server has no accepted snapshot to restore. Local files were left unchanged.");
    const canonicalHead = this.canonicalSnapshot(head), remote = this.map(canonicalHead);
    for (const path of scanned.unreadableConflictPaths) {
      const accepted = remote.get(path);
      if (accepted) local.set(path, accepted);
    }
    if (!head) return { downloaded: 0, deleted: 0, prunedFolders: 0 };
    await this.archiveInterruptedApplyForRestore();
    const result = await this.stageAndApply(head.id, remote, this.snapshotFolders(canonicalHead), local, /* @__PURE__ */ new Set(), scanned, [], this.bodyCache(), this.bodyCache(), canonicalHead == null ? void 0 : canonicalHead.folderRepair, head.createdAt);
    return { downloaded: result.downloaded, deleted: result.deleted, prunedFolders: result.prunedFolders };
  }
  async archiveInterruptedApplyForRestore() {
    var _a;
    const settings = this.getSettings();
    if (!settings.pendingApplySnapshotId) return;
    const target = await this.optionalSnapshot(settings.pendingApplySnapshotId);
    if (!target) throw new SyncSafetyError("The interrupted copy's accepted snapshot is unavailable; its original, current and staged versions were retained.");
    const entries = new Map(target.entries.map((entry) => [entry.path, entry])), cache = this.bodyCache(), desktopOnly = /* @__PURE__ */ new Set();
    if (this.isMobileDevice) for (const entry of target.entries) {
      const plugin = this.pluginPath(entry.path);
      if ((plugin == null ? void 0 : plugin.relative.toLowerCase()) !== "manifest.json") continue;
      try {
        if (JSON.parse(decoder6.decode(await this.remoteBytes(entry, cache))).isDesktopOnly === true) desktopOnly.add(plugin.id);
      } catch (e) {
      }
    }
    for (const path of settings.pendingApplyPaths) {
      await this.cooperate();
      const entry = entries.get(path), priorHash = (_a = settings.pendingApplyPriorHashes[path]) != null ? _a : null, targetHash = entry ? this.isMobileDevice && path === this.enablementPath ? (await this.deviceBytes(path, entry, cache, desktopOnly)).hash : entry.hash : null;
      await this.loadOperation(path, targetHash, priorHash);
    }
    await this.finishOperations(true);
  }
  bodyCache() {
    return new BodyCache(this.isMobileDevice ? 8 * 1024 * 1024 : 32 * 1024 * 1024);
  }
  configPath(path) {
    return canonicalConfigPath(path, this.logicalConfigDir);
  }
  pluginPath(path) {
    return obsidianPluginPath(path, this.logicalConfigDir);
  }
  systemPath(path) {
    return isObsidianSystemPath(path, this.logicalConfigDir);
  }
  pluginDataPath(path) {
    return isPluginDataPath(path, this.logicalConfigDir);
  }
  heldPackagePath(path) {
    var _a;
    const id = (_a = this.pluginPath(path)) == null ? void 0 : _a.id;
    return Boolean(id && this.getSettings().packageHolds[id]);
  }
  pluginFile(id, name) {
    return (0, import_obsidian2.normalizePath)(`${this.logicalConfigDir}/plugins/${id}/${name}`);
  }
  get enablementPath() {
    return (0, import_obsidian2.normalizePath)(`${this.logicalConfigDir}/community-plugins.json`);
  }
  async entropy(bytes2) {
    if (bytes2.length < 1024) return 0;
    const counts = new Uint32Array(256);
    for (let start = 0; start < bytes2.length; start += 64 * 1024) {
      for (const value of bytes2.subarray(start, start + 64 * 1024)) counts[value]++;
      await this.cooperate();
    }
    let result = 0;
    for (const count of counts) if (count) {
      const probability = count / bytes2.length;
      result -= probability * Math.log2(probability);
    }
    return result;
  }
  include(path) {
    let normalized = (0, import_obsidian2.normalizePath)(path);
    if (this.canonicalNamespace) {
      for (const alias of this.configAliases) if (normalized === alias || normalized.startsWith(`${alias}/`)) {
        normalized = `.obsidian${normalized.slice(alias.length)}`;
        break;
      }
    }
    return shouldSyncChangedPath(normalized, this.getSettings());
  }
  async disappeared(path) {
    try {
      if (!await this.adapter.exists(path)) return true;
    } catch (e) {
    }
    try {
      return !await this.adapter.stat(path);
    } catch (e) {
      return false;
    }
  }
  pluginSyncPath(path) {
    const normalized = (0, import_obsidian2.normalizePath)(path);
    if (normalized === this.enablementPath) return true;
    const plugin = this.pluginPath(normalized);
    return Boolean(plugin && plugin.id.toLowerCase() !== "gib-sync");
  }
  async listFiles(path = "", folders = /* @__PURE__ */ new Set()) {
    let listing;
    try {
      listing = await this.adapter.list(path);
    } catch (error) {
      if (path && await this.disappeared(path)) {
        folders.delete((0, import_obsidian2.normalizePath)(path));
        return [];
      }
      throw error;
    }
    const files = listing.files.filter((file) => this.include(file));
    for (const folder of listing.folders.filter((item) => this.include(item))) {
      await this.cooperate();
      const normalized = (0, import_obsidian2.normalizePath)(folder);
      if (this.managedTopLevelFolder(normalized)) folders.add(normalized);
      for (const file of await this.listFiles(normalized, folders)) files.push(file);
    }
    return files;
  }
  async scan() {
    var _a;
    const output = /* @__PURE__ */ new Map(), folders = /* @__PURE__ */ new Set(), unreadableConflictPaths = /* @__PURE__ */ new Set();
    const paths = await this.listFiles("", folders);
    let current = 0;
    for (const path of paths) {
      await this.cooperate();
      let hash, stat;
      try {
        const observed = await this.inspectLocalFile(path, this.getSettings().pendingPaths.includes(path));
        if (!observed) {
          current++;
          continue;
        }
        hash = observed.hash;
        stat = { type: "file", size: observed.size, mtime: observed.mtime };
      } catch (error) {
        if (await this.disappeared(path)) {
          current++;
          continue;
        }
        if (!isGibSyncConflictPath(path)) throw error;
        unreadableConflictPaths.add(path);
        this.status({ phase: "scanning", message: `Isolated unreadable generated conflict copy \xB7 ${path} \xB7 accepted server version preserved`, level: "warning" });
        current++;
        continue;
      }
      if (!stat || stat.type !== "file") {
        current++;
        continue;
      }
      output.set(path, { path, hash, size: stat.size, mtime: (_a = stat.mtime) != null ? _a : Date.now() });
      current++;
      if (current === 1 || current === paths.length || current % 25 === 0) this.status({ phase: "scanning", message: "Scanning local vault", current, total: paths.length });
    }
    for (const folder of this.acceptedFolders(paths)) folders.delete(folder);
    await this.inventory.finishListing(paths);
    this.observedInventoryFolders = new Set(folders);
    this.lastInventoryListingAt = Date.now();
    return { files: output, folders, unreadableConflictPaths };
  }
  async scanIncremental(baseSnapshot, changedPaths) {
    const output = this.map(baseSnapshot), folders = this.manifestFolders(baseSnapshot), unreadableConflictPaths = /* @__PURE__ */ new Set();
    let current = 0;
    for (const rawPath of changedPaths) {
      await this.cooperate();
      const path = (0, import_obsidian2.normalizePath)(rawPath);
      current++;
      if (!this.include(path)) {
        output.delete(path);
        continue;
      }
      let stat;
      try {
        stat = await this.adapter.stat(path);
      } catch (error) {
        if (await this.disappeared(path)) {
          output.delete(path);
          continue;
        }
        throw error;
      }
      if (!stat) {
        output.delete(path);
        continue;
      }
      if (stat.type !== "file") throw new SyncSafetyError("A changed folder requires a full vault reconciliation before syncing.");
      try {
        const observed = await this.inspectLocalFile(path, true);
        if (!observed) {
          output.delete(path);
          continue;
        }
        output.set(path, { path, hash: observed.hash, size: observed.size, mtime: observed.mtime });
      } catch (error) {
        if (await this.disappeared(path)) {
          output.delete(path);
          continue;
        }
        if (!isGibSyncConflictPath(path)) throw error;
        output.delete(path);
        unreadableConflictPaths.add(path);
        this.status({ phase: "scanning", message: `Isolated unreadable generated conflict copy \xB7 ${path} \xB7 accepted server version preserved`, level: "warning" });
      }
      if (this.progress(current, changedPaths.length)) this.status({ phase: "scanning", message: "Checking changed files", current, total: changedPaths.length });
    }
    return { files: output, folders, unreadableConflictPaths };
  }
  map(snapshot) {
    var _a;
    return new Map(((_a = snapshot == null ? void 0 : snapshot.entries) != null ? _a : []).filter((entry) => this.include(entry.path)).map((entry) => [entry.path, { ...entry }]));
  }
  async localBytes(path, entry, cache) {
    var _a;
    const cached = cache.get(entry.hash);
    if (cached) return cached;
    const sourcePath = (_a = entry.sourcePath) != null ? _a : path;
    let clear;
    try {
      clear = new Uint8Array(await this.adapter.readBinary(sourcePath));
    } catch (error) {
      if (await this.disappeared(sourcePath)) throw new FileChangedDuringReadError(sourcePath);
      throw error;
    }
    if (await hashBytes(clear) !== entry.hash) throw new FileChangedDuringReadError(sourcePath);
    cache.set(entry.hash, clear);
    return clear;
  }
  async remoteBytes(entry, cache) {
    var _a;
    const existing = cache.get(entry.hash);
    if (existing) return existing;
    if ((_a = entry.sourcePath) == null ? void 0 : _a.startsWith(".gib-sync/package-hold-originals/")) return this.localBytes(entry.path, entry, cache);
    if (entry.size >= LOW_MEMORY_DOWNLOAD_BYTES) {
      const bytes3 = await this.api.getContent(entry.hash, entry.size);
      this.checkpoint();
      if (bytes3.byteLength !== entry.size || await hashBytes(bytes3) !== entry.hash) throw new Error(`Large-file integrity check failed for ${entry.path}`);
      return bytes3;
    }
    const bytes2 = await decryptBlob(await this.api.getBlob(entry.hash), this.getSettings().vaultKey, entry.hash);
    cache.set(entry.hash, bytes2);
    return bytes2;
  }
  async uploadLocalFile(entry, cache) {
    var _a;
    const sourcePath = (_a = entry.sourcePath) != null ? _a : entry.path;
    if (entry.size >= LOW_MEMORY_DOWNLOAD_BYTES && typeof this.api.supportsStreamUpload === "function" && this.api.supportsStreamUpload()) {
      const checkpoint = () => {
        this.checkpoint();
        const observedPath = sourcePath.startsWith(".gib-sync/") ? entry.path : sourcePath;
        if (!this.canApplyLocalMutation(observedPath)) {
          this.getSettings().fullScanRequired = true;
          throw new FileChangedDuringReadError(observedPath);
        }
      };
      try {
        if (await uploadAdapterFile(this.adapter, sourcePath, entry.hash, entry.size, this.api, checkpoint, () => this.cooperate(), (stage) => this.status({ phase: "uploading", message: stage === "waiting" ? `Waiting for safe server processing \xB7 ${entry.path}` : stage === "checking" ? `Verifying the stored large file \xB7 ${entry.path}` : stage === "verifying" ? `Verifying complete large upload \xB7 ${entry.path}` : `Saving the verified large upload \xB7 ${entry.path}` }))) return;
      } catch (error) {
        if (error instanceof AdapterFileChangedError) throw new FileChangedDuringReadError(sourcePath);
        throw error;
      }
    }
    const clear = await this.localBytes(entry.path, entry, cache), encrypted = await encryptBlob(clear, this.getSettings().vaultKey, entry.hash);
    this.checkpoint();
    await this.api.putBlob(entry.hash, encrypted);
    this.checkpoint();
  }
  async ensureParent(path) {
    const parts = (0, import_obsidian2.normalizePath)(path).split("/").slice(0, -1);
    let current = "";
    for (const part of parts) {
      current = current ? `${current}/${part}` : part;
      if (!await this.adapter.exists(current)) {
        this.checkpoint();
        this.expectLocalMutation(current, "folder");
        await this.adapter.mkdir(current);
      }
    }
  }
  disposableMetadata(path) {
    var _a, _b;
    const name = (_b = (_a = (0, import_obsidian2.normalizePath)(path).split("/").at(-1)) == null ? void 0 : _a.toLowerCase()) != null ? _b : "";
    return DISPOSABLE_FOLDER_METADATA.has(name) || name.startsWith("._");
  }
  async localRecoveryPath(batch, path) {
    const base = (0, import_obsidian2.normalizePath)(`.gib-sync/local-recovery/${batch}-${crypto.randomUUID()}/${path}`);
    let candidate = base, index = 2;
    while (await this.adapter.exists(candidate)) {
      const dot = base.lastIndexOf("."), slash = base.lastIndexOf("/"), stem = dot > slash ? base.slice(0, dot) : base, extension = dot > slash ? base.slice(dot) : "";
      candidate = `${stem} - ${index++}${extension}`;
    }
    return candidate;
  }
  async currentFolderFile(path) {
    if (!this.include(path)) return false;
    const retired = this.getSettings().retiredPaths[path];
    if (!retired) return true;
    try {
      return await this.hashLocalFile(path) !== retired.hash;
    } catch (error) {
      if (error instanceof SyncCancelledError) throw error;
      return true;
    }
  }
  hasLocalFolderIntent(path, after = 0) {
    const normalized = (0, import_obsidian2.normalizePath)(path);
    return Object.entries(this.getSettings().folderCreateTimes).some(([createdAtPath, createdAt]) => {
      if (createdAt <= after) return false;
      const created = (0, import_obsidian2.normalizePath)(createdAtPath);
      return created === normalized || created.startsWith(`${normalized}/`) || normalized.startsWith(`${created}/`);
    });
  }
  trimFolderCreateTimes(existing, desired) {
    const times = this.getSettings().folderCreateTimes;
    for (const recorded of Object.keys(times)) {
      const path = (0, import_obsidian2.normalizePath)(recorded);
      if (!existing.has(path) || desired.has(path)) delete times[recorded];
    }
  }
  async retireFolderFile(path, batch) {
    if (await this.currentFolderFile(path)) return "kept";
    await this.cooperate();
    this.expectLocalMutation(path, null);
    if (this.disposableMetadata(path)) {
      this.checkpoint();
      await this.adapter.remove(path);
      return "metadata";
    }
    const trashLocal = this.adapter.trashLocal;
    if (typeof trashLocal === "function") try {
      await trashLocal.call(this.adapter, path);
      return "recovered";
    } catch (e) {
      if (!await this.adapter.exists(path)) return "recovered";
    }
    const recovery = await this.localRecoveryPath(batch, path);
    await this.ensureParent(recovery);
    this.checkpoint();
    await this.adapter.rename(path, recovery);
    return "recovered";
  }
  async pruneRetiredTree(path, batch) {
    var _a;
    const stat = await this.adapter.stat(path);
    if ((stat == null ? void 0 : stat.type) !== "folder") return { folders: 0, metadata: 0, recovered: 0 };
    let folders = 0, metadata = 0, recovered = 0;
    const listing = await this.adapter.list(path);
    for (const folder of listing.folders) {
      const normalized = (0, import_obsidian2.normalizePath)(folder), lower = normalized.toLowerCase();
      if (PROTECTED_FOLDER_ROOTS.has(lower)) continue;
      await this.cooperate();
      const child = await this.pruneRetiredTree(normalized, batch);
      folders += child.folders;
      metadata += child.metadata;
      recovered += child.recovered;
    }
    for (const file of listing.files) {
      const result = await this.retireFolderFile((0, import_obsidian2.normalizePath)(file), batch);
      if (result === "metadata") metadata++;
      else if (result === "recovered") recovered++;
    }
    const first = await this.adapter.list(path);
    if (first.files.length || first.folders.length) return { folders, metadata, recovered };
    await this.cooperate(true);
    const second = await this.adapter.list(path);
    if (second.files.length || second.folders.length) return { folders, metadata, recovered };
    if (((_a = await this.adapter.stat(path)) == null ? void 0 : _a.type) !== "folder") return { folders, metadata, recovered };
    this.checkpoint();
    this.expectLocalMutation(path, null);
    await this.adapter.rmdir(path, false);
    return { folders: folders + 1, metadata, recovered };
  }
  async inspectRetiredFolder(path) {
    const listing = await this.adapter.list(path);
    let canonical = false;
    const blockers = [];
    for (const file of listing.files) {
      const normalized = (0, import_obsidian2.normalizePath)(file);
      if (await this.currentFolderFile(normalized)) canonical = true;
      else if (blockers.length < 4) blockers.push(normalized);
    }
    for (const folder of listing.folders) {
      await this.cooperate();
      const child = await this.inspectRetiredFolder(folder);
      canonical || (canonical = child.canonical);
      for (const blocker of child.blockers) if (blockers.length < 4) blockers.push(blocker);
    }
    return { canonical, blockers };
  }
  async pruneRetiredEmptyFolders() {
    var _a, _b;
    const settings = this.getSettings(), retired = Object.entries(settings.retiredPaths), newest = Math.max(0, ...retired.map(([, state]) => state.retiredAt));
    if (!newest) {
      settings.retiredFolderCount = 0;
      settings.retiredFolderNote = "";
      return { removed: 0, remaining: 0, attempted: false };
    }
    if (newest <= settings.lastFolderCleanupAt && !settings.retiredFolderCount) return { removed: 0, remaining: 0, attempted: false };
    const candidates = /* @__PURE__ */ new Map();
    for (const [path, state] of retired) {
      const parts = (0, import_obsidian2.normalizePath)(path).split("/").slice(0, -1);
      let current = "";
      for (const part of parts) {
        current = current ? `${current}/${part}` : part;
        const lower = current.toLowerCase();
        if (PROTECTED_FOLDER_ROOTS.has(lower) || !this.include(current)) continue;
        candidates.set(current, Math.max((_a = candidates.get(current)) != null ? _a : 0, state.retiredAt));
      }
    }
    const eligible = /* @__PURE__ */ new Set();
    let failures = 0, removed = 0;
    const failureDetails = [];
    for (const [path, retiredAt] of candidates) {
      try {
        const stat = await this.adapter.stat(path);
        if ((stat == null ? void 0 : stat.type) === "folder" && !this.hasLocalFolderIntent(path, retiredAt)) eligible.add(path);
      } catch (error) {
        failures++;
        failureDetails.push(`${path}: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
    const ordered = [...eligible].sort((left, right) => right.split("/").length - left.split("/").length || right.localeCompare(left));
    let metadataRemoved = 0, recovered = 0;
    const batch = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
    for (const path of ordered) {
      await this.cooperate();
      try {
        if ((await this.inspectRetiredFolder(path)).canonical) continue;
        const cleaned = await this.pruneRetiredTree(path, batch);
        removed += cleaned.folders;
        metadataRemoved += cleaned.metadata;
        recovered += cleaned.recovered;
      } catch (error) {
        failures++;
        failureDetails.push(`${path}: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
    const remainingPaths = [], remainingDetails = [];
    for (const path of eligible) try {
      if (((_b = await this.adapter.stat(path)) == null ? void 0 : _b.type) !== "folder") continue;
      const inspection = await this.inspectRetiredFolder(path);
      if (!inspection.canonical) {
        remainingPaths.push(path);
        remainingDetails.push(`${path} \u2190 ${inspection.blockers.length ? inspection.blockers.join(", ") : "contents changed during cleanup"}`);
      }
    } catch (error) {
      if (!failureDetails.some((item) => item.startsWith(`${path}:`))) {
        failures++;
        failureDetails.push(`${path}: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
    const remaining = remainingPaths.length;
    settings.retiredFolderCount = remaining;
    settings.retiredFolderNote = remaining ? `${remaining} retired folder${remaining === 1 ? " is" : "s are"} blocked: ${remainingDetails.slice(0, 4).join(" \xB7 ")}${remainingDetails.length > 4 ? ` \xB7 and ${remainingDetails.length - 4} more` : ""}`.slice(0, 2e3) : "";
    if (!failures) {
      settings.lastFolderCleanupAt = newest;
      settings.lastFolderCleanupError = "";
    } else settings.lastFolderCleanupError = failureDetails.slice(0, 8).join(" \xB7 ").slice(0, 2e3);
    if (removed) this.status({ phase: "applying", message: `Removed ${removed} empty retired folder${removed === 1 ? "" : "s"} left by accepted moves or deletions`, level: "success" });
    if (metadataRemoved) this.status({ phase: "applying", message: `Removed ${metadataRemoved} harmless platform metadata file${metadataRemoved === 1 ? "" : "s"} from retired folders`, level: "success" });
    if (recovered) this.status({ phase: "applying", message: `Applied accepted folder deletions \xB7 moved ${recovered} device-only file${recovered === 1 ? "" : "s"} to local recovery`, level: "success" });
    if (failures) this.status({ phase: "applying", message: `Empty-folder cleanup deferred for ${failures} path${failures === 1 ? "" : "s"}; ${failureDetails.slice(0, 3).join(" \xB7 ")}; file reconciliation can continue and cleanup will retry`, level: "warning" });
    else if (remaining) this.status({ phase: "applying", message: `Folder topology differs locally \xB7 ${settings.retiredFolderNote} \xB7 cleanup will retry safely`, level: "warning" });
    return { removed, remaining, attempted: true };
  }
  managedTopLevelFolder(path) {
    const top = (0, import_obsidian2.normalizePath)(path).split("/")[0], lower = top.toLowerCase();
    return Boolean(top) && !PROTECTED_FOLDER_ROOTS.has(lower) && lower !== this.getSettings().configDir.split("/")[0].toLowerCase() && !this.configAliases.some((alias) => alias.split("/")[0].toLowerCase() === lower) && this.include(top);
  }
  async localManagedFolders() {
    const folders = /* @__PURE__ */ new Set();
    const visit = async (path) => {
      let listing;
      try {
        listing = await this.adapter.list(path);
      } catch (error) {
        if (await this.disappeared(path)) {
          folders.delete((0, import_obsidian2.normalizePath)(path));
          return;
        }
        throw error;
      }
      for (const folder of listing.folders) {
        const normalized = (0, import_obsidian2.normalizePath)(folder);
        folders.add(normalized);
        await this.cooperate();
        await visit(normalized);
      }
    };
    const root2 = await this.adapter.list("");
    for (const folder of root2.folders) {
      const normalized = (0, import_obsidian2.normalizePath)(folder);
      if (!this.managedTopLevelFolder(normalized)) continue;
      folders.add(normalized);
      await this.cooperate();
      await visit(normalized);
    }
    return folders;
  }
  acceptedFolders(paths) {
    const folders = /* @__PURE__ */ new Set();
    for (const path of paths) {
      const parts = (0, import_obsidian2.normalizePath)(path).split("/").slice(0, -1);
      if (!parts.length || !this.managedTopLevelFolder(parts[0])) continue;
      let current = "";
      for (const part of parts) {
        current = current ? `${current}/${part}` : part;
        folders.add(current);
      }
    }
    return folders;
  }
  async hasProtectedFolderIntent(path, repair, fallbackIssuedAt) {
    var _a, _b;
    if (!repair) return this.hasLocalFolderIntent(path);
    const normalized = (0, import_obsidian2.normalizePath)(path), retired = repair.retiredFolders.some((raw) => {
      const candidate = (0, import_obsidian2.normalizePath)(raw);
      return candidate === normalized || candidate.startsWith(`${normalized}/`) || normalized.startsWith(`${candidate}/`);
    });
    const observedAt = retired ? Date.parse((_b = (_a = repair.issuedAt) != null ? _a : fallbackIssuedAt) != null ? _b : repair.observedAt) : 0;
    if (!Number.isFinite(observedAt) || !this.hasLocalFolderIntent(path, observedAt)) return !retired && this.hasLocalFolderIntent(path);
    for (const [createdPath, createdAt] of Object.entries(this.getSettings().folderCreateTimes)) {
      const created = (0, import_obsidian2.normalizePath)(createdPath);
      if (createdAt <= observedAt || !(created === normalized || created.startsWith(`${normalized}/`) || normalized.startsWith(`${created}/`))) continue;
      try {
        const stat = await this.adapter.stat(created);
        if ((stat == null ? void 0 : stat.type) === "folder" && Math.max(stat.ctime, stat.mtime) > observedAt) return true;
      } catch (e) {
      }
    }
    return false;
  }
  snapshotFolders(snapshot) {
    var _a;
    const folders = this.acceptedFolders(((_a = snapshot == null ? void 0 : snapshot.entries) != null ? _a : []).map((entry) => entry.path));
    for (const raw of this.manifestFolders(snapshot)) {
      const parts = (0, import_obsidian2.normalizePath)(raw).split("/").filter(Boolean);
      if (!parts.length || !this.managedTopLevelFolder(parts[0])) continue;
      let current = "";
      for (const part of parts) {
        current = current ? `${current}/${part}` : part;
        folders.add(current);
      }
    }
    return folders;
  }
  manifestFolders(snapshot) {
    var _a;
    return new Set(((_a = snapshot == null ? void 0 : snapshot.folders) != null ? _a : []).map((folder) => (0, import_obsidian2.normalizePath)(folder)).filter((folder) => this.managedTopLevelFolder(folder)));
  }
  mergeFolders(base, local, remote) {
    const merged = /* @__PURE__ */ new Set(), paths = /* @__PURE__ */ new Set([...base, ...local, ...remote]);
    for (const path of paths) {
      const b = base.has(path), l = local.has(path), r = remote.has(path), keep = l === r ? l : l === b ? r : l;
      if (keep) merged.add(path);
    }
    return merged;
  }
  minimalFolderRoots(paths) {
    return [...new Set(paths)].sort((left, right) => left.split("/").length - right.split("/").length || left.localeCompare(right)).filter((path, index, all) => !all.slice(0, index).some((parent) => path.startsWith(`${parent}/`)));
  }
  async folderHasSyncableFile(path) {
    let listing;
    try {
      listing = await this.adapter.list(path);
    } catch (error) {
      if (await this.disappeared(path)) return false;
      throw error;
    }
    for (const file of listing.files) if (this.include((0, import_obsidian2.normalizePath)(file))) return true;
    for (const folder of listing.folders) {
      await this.cooperate();
      if (await this.folderHasSyncableFile((0, import_obsidian2.normalizePath)(folder))) return true;
    }
    return false;
  }
  async reconcileFolderTopology(acceptedFolders, repair, repairSnapshotCreatedAt) {
    var _a;
    const settings = this.getSettings(), desired = new Set([...acceptedFolders].map((path) => (0, import_obsidian2.normalizePath)(path)).filter((path) => this.managedTopLevelFolder(path))), before = await this.localManagedFolders();
    let created = 0, removed = 0, recovered = 0, metadata = 0, failures = 0;
    const failureDetails = [], batch = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
    for (const path of [...desired].sort((left, right) => left.split("/").length - right.split("/").length || left.localeCompare(right))) {
      if (before.has(path)) continue;
      await this.cooperate();
      try {
        if (!await this.adapter.exists(path)) {
          this.checkpoint();
          this.expectLocalMutation(path, "folder");
          await this.adapter.mkdir(path);
        }
        created++;
        before.add(path);
      } catch (error) {
        if (!await this.adapter.exists(path)) {
          failures++;
          failureDetails.push(`${path}: ${error instanceof Error ? error.message : String(error)}`);
        }
      }
    }
    const unprotectedBefore = [];
    for (const path of before) if (!desired.has(path) && !await this.hasProtectedFolderIntent(path, repair, repairSnapshotCreatedAt)) unprotectedBefore.push(path);
    const extraRoots = this.minimalFolderRoots(unprotectedBefore);
    for (const root2 of extraRoots) {
      await this.cooperate();
      try {
        if (await this.folderHasSyncableFile(root2)) continue;
        const cleaned = await this.pruneRetiredTree(root2, batch);
        removed += cleaned.folders;
        recovered += cleaned.recovered;
        metadata += cleaned.metadata;
      } catch (error) {
        failures++;
        failureDetails.push(`${root2}: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
    const after = extraRoots.length ? await this.localManagedFolders() : before, unprotectedAfter = [];
    for (const path of after) if (!desired.has(path) && !await this.hasProtectedFolderIntent(path, repair, repairSnapshotCreatedAt)) unprotectedAfter.push(path);
    const extra = this.minimalFolderRoots(unprotectedAfter), missing2 = this.minimalFolderRoots([...desired].filter((path) => !after.has(path))), remaining = extra.length + missing2.length;
    this.trimFolderCreateTimes(after, desired);
    settings.retiredFolderCount = remaining;
    settings.retiredFolderNote = remaining ? `Folder topology differs from the accepted snapshot: ${[...extra.map((path) => `extra ${path}`), ...missing2.map((path) => `missing ${path}`)].slice(0, 8).join(" \xB7 ")}${remaining > 8 ? ` \xB7 and ${remaining - 8} more` : ""}`.slice(0, 2e3) : "";
    if (!failures) settings.lastFolderCleanupAt = Date.now();
    settings.lastFolderCleanupError = failures ? failureDetails.slice(0, 8).join(" \xB7 ").slice(0, 2e3) : "";
    if (remaining) settings.fullScanRequired = true;
    else settings.observedFolderSnapshotId = (_a = settings.pendingApplySnapshotId) != null ? _a : settings.lastSnapshotId;
    if (created) this.status({ phase: "applying", message: `Folder topology reconciled \xB7 created ${created} accepted folder${created === 1 ? "" : "s"}`, level: "success" });
    if (removed) this.status({ phase: "applying", message: `Folder topology reconciled \xB7 removed ${removed} obsolete folder${removed === 1 ? "" : "s"}`, level: "success" });
    if (recovered) this.status({ phase: "applying", message: `Folder topology reconciled \xB7 moved ${recovered} ignored file${recovered === 1 ? "" : "s"} to local recovery`, level: "success" });
    if (metadata) this.status({ phase: "applying", message: `Folder topology reconciled \xB7 removed ${metadata} harmless platform metadata file${metadata === 1 ? "" : "s"}`, level: "success" });
    if (remaining) this.status({ phase: "applying", message: settings.retiredFolderNote, level: "warning" });
    return { removed, remaining };
  }
  text(path) {
    var _a, _b;
    return TEXT_EXTENSIONS.has((_b = (_a = path.split(".").pop()) == null ? void 0 : _a.toLowerCase()) != null ? _b : "");
  }
  conflictPath(path, deviceName, mtime, occupied) {
    const index = path.lastIndexOf("."), slash = path.lastIndexOf("/");
    const device = deviceName.replace(/[\\/:*?"<>|\[\]#]/g, "-").replace(/\s+/g, " ").trim().slice(0, 40) || "Unknown device";
    const date = new Date(Number.isFinite(mtime) && mtime > 0 ? mtime : Date.now());
    const stamp = (Number.isNaN(date.getTime()) ? /* @__PURE__ */ new Date() : date).toISOString().replace("T", " ").replace(/\.\d{3}Z$/, " UTC").replace(/:/g, "-");
    const stem = index > slash ? path.slice(0, index) : path, extension = index > slash ? path.slice(index) : "";
    let candidate = `${stem} (conflict - ${device} - ${stamp})${extension}`, sequence = 2;
    while (occupied.has(candidate)) candidate = `${stem} (conflict - ${device} - ${stamp} - ${sequence++})${extension}`;
    return candidate;
  }
  wikiLink(path) {
    const target = path.toLowerCase().endsWith(".md") ? path.slice(0, -3) : path;
    return `[[${target.replace(/\|/g, " ")}|${path.slice(path.lastIndexOf("/") + 1)}]]`;
  }
  warning(text, devices, otherPath) {
    return `> [!warning] Gib Sync conflict
> Gib Sync preserved overlapping versions from **${devices.join("** and **")}**. No content was discarded.
> Review the other version: ${this.wikiLink(otherPath)}

${text}`;
  }
  deletionWarning(text, editor, deleter) {
    return `> [!warning] Gib Sync deletion conflict
> **${deleter}** deleted this note while **${editor}** modified it. Gib Sync kept the modified content here; delete this note if the deletion was intended.

${text}`;
  }
  async preserveDeletion(path, clear, editor, deleter, final, bytes2) {
    const preserved = path.toLowerCase().endsWith(".md") ? encoder7.encode(this.deletionWarning(decoder6.decode(clear), editor, deleter)) : clear;
    await this.prepareResult(path, preserved, final, bytes2);
  }
  async prepareStreamedVersion(path, entry, side, prefix, final) {
    var _a, _b;
    if (!prefix) {
      final.set(path, { ...entry, path, ...side === "local" ? { sourcePath: (_a = entry.sourcePath) != null ? _a : entry.path } : {} });
      return;
    }
    if (typeof this.adapter.appendBinary !== "function") throw new SyncSafetyError("This adapter cannot safely prepare a large conflict version. Both originals remain unchanged; update Obsidian before retrying.");
    const temporary = `.gib-sync/prepared/${crypto.randomUUID()}.tmp`, prefixBytes = encoder7.encode(prefix), digest = sha256.create();
    digest.update(prefixBytes);
    const append = async (chunk) => {
      for (let offset = 0; offset < chunk.length; offset += 64 * 1024) {
        this.checkpoint();
        const part = chunk.subarray(offset, offset + 64 * 1024);
        digest.update(part);
        await this.adapter.appendBinary(temporary, exactArrayBuffer2(part));
        this.checkpoint();
        await this.cooperate();
      }
    };
    try {
      await this.ensureParent(temporary);
      this.checkpoint();
      await this.adapter.writeBinary(temporary, exactArrayBuffer2(prefixBytes));
      if (side === "local") await streamAdapterFile(this.adapter, (_b = entry.sourcePath) != null ? _b : entry.path, entry.hash, entry.size, append, () => this.checkpoint(), () => this.cooperate());
      else if (typeof this.api.streamContent === "function") await this.api.streamContent(entry.hash, entry.size, append, () => this.checkpoint());
      else if (entry.size < LOW_MEMORY_DOWNLOAD_BYTES) await append(await this.remoteBytes(entry, this.bodyCache()));
      else throw new SyncSafetyError("This server cannot safely stream a large conflict version. Both originals were preserved; update the server before retrying.");
      const hash = bytesToHex(digest.digest()), sourcePath = `.gib-sync/prepared/${hash}.bin`;
      if (await this.savedHash(temporary) !== hash) throw new SyncSafetyError(`Prepared conflict integrity failed for ${path}; both originals were preserved.`);
      if (await this.adapter.exists(sourcePath)) {
        if (await this.savedHash(sourcePath) !== hash) throw new SyncSafetyError("A prepared recovery file failed verification; it was not overwritten.");
        await this.adapter.remove(temporary);
      } else await this.adapter.rename(temporary, sourcePath);
      this.preparedPaths.add(sourcePath);
      final.set(path, { ...entry, path, hash, size: entry.size + prefixBytes.length, mtime: Date.now(), sourcePath });
    } catch (error) {
      try {
        await this.adapter.remove(temporary);
      } catch (e) {
      }
      if (error instanceof AdapterFileChangedError) throw new FileChangedDuringReadError(error.path);
      throw error;
    } finally {
      digest.destroy();
    }
  }
  async preserveLargePair(path, local, remote, localName, remoteName, preferred, final, occupied) {
    const localWins = preferred === "local", loser = localWins ? remote : local, copyPath = this.conflictPath(path, localWins ? remoteName : localName, loser.mtime, occupied);
    occupied.add(copyPath);
    const warning = path.toLowerCase().endsWith(".md"), names = [localName, remoteName];
    await this.prepareStreamedVersion(path, localWins ? local : remote, localWins ? "local" : "remote", warning ? this.warning("", names, copyPath) : "", final);
    await this.prepareStreamedVersion(copyPath, loser, localWins ? "remote" : "local", warning ? this.warning("", names, path) : "", final);
    const copy = final.get(copyPath);
    delete copy.fileId;
    delete copy.revision;
    await this.recordConflict(path, local, remote, localName, remoteName, preferred, copyPath, final, "Large concurrent versions");
  }
  async preservePair(path, local, localBytes, remote, localName, remoteName, preferred, final, bytes2, remoteCache, occupied) {
    const remoteBytes = await this.remoteBytes(remote, remoteCache);
    const localIsNewer = preferred === "local";
    const loser = localIsNewer ? remote : local;
    const winnerBytes = localIsNewer ? localBytes : remoteBytes, loserBytes = localIsNewer ? remoteBytes : localBytes;
    const loserName = localIsNewer ? remoteName : localName;
    const copyPath = this.conflictPath(path, loserName, loser.mtime, occupied);
    occupied.add(copyPath);
    let originalClear = winnerBytes, copyClear = loserBytes;
    if (path.toLowerCase().endsWith(".md")) {
      const names = [localName, remoteName];
      originalClear = encoder7.encode(this.warning(decoder6.decode(winnerBytes), names, copyPath));
      copyClear = encoder7.encode(this.warning(decoder6.decode(loserBytes), names, path));
    }
    await this.prepareResult(path, originalClear, final, bytes2);
    await this.prepareResult(copyPath, copyClear, final, bytes2);
    await this.recordConflict(path, local, remote, localName, remoteName, preferred, copyPath, final, "Concurrent versions preserved");
  }
  async recordConflict(path, local, remote, localName, remoteName, preferred, copyPath, final, reason) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m;
    const known = (await this.conflictStore.list()).find((item) => {
      var _a2, _b2;
      return item.state === "open" && !item.originSnapshotId && item.path === path && ((_a2 = item.versions[0]) == null ? void 0 : _a2.hash) === local.hash && ((_b2 = item.versions[1]) == null ? void 0 : _b2.hash) === remote.hash;
    }), id = (_a = known == null ? void 0 : known.id) != null ? _a : crypto.randomUUID(), sourcePath = (_c = (_b = known == null ? void 0 : known.versions[0]) == null ? void 0 : _b.sourcePath) != null ? _c : `.gib-sync/conflict-originals/${crypto.randomUUID()}.bin`;
    if (!await this.adapter.exists(sourcePath)) {
      await this.ensureParent(sourcePath);
      this.checkpoint();
      await this.adapter.copy((_d = local.sourcePath) != null ? _d : local.path, sourcePath);
      this.checkpoint();
    }
    if (await this.savedHash(sourcePath) !== local.hash) throw new FileChangedDuringReadError((_e = local.sourcePath) != null ? _e : local.path);
    const localPath = preferred === "local" ? path : copyPath, remotePath = preferred === "remote" ? path : copyPath, settings = this.getSettings();
    await this.conflictStore.save({ id, originSnapshotId: null, path, createdAt: (_f = known == null ? void 0 : known.createdAt) != null ? _f : (/* @__PURE__ */ new Date()).toISOString(), reason, state: "open", versions: [{ id: (_h = (_g = known == null ? void 0 : known.versions[0]) == null ? void 0 : _g.id) != null ? _h : crypto.randomUUID(), label: localName.slice(0, 100), path, hash: local.hash, size: local.size, deviceId: settings.deviceId, deviceName: localName, revisionId: (_i = local.revision) == null ? void 0 : _i.id, sourcePath, annotatedPath: localPath, annotatedHash: final.get(localPath).hash }, { id: (_k = (_j = known == null ? void 0 : known.versions[1]) == null ? void 0 : _j.id) != null ? _k : crypto.randomUUID(), label: remoteName.slice(0, 100), path, hash: remote.hash, size: remote.size, deviceId: (_l = remote.revision) == null ? void 0 : _l.deviceId, deviceName: remoteName, revisionId: (_m = remote.revision) == null ? void 0 : _m.id, annotatedPath: remotePath, annotatedHash: final.get(remotePath).hash }] });
  }
  async recordDeletionConflict(path, survivor, localSurvived, remoteName, final) {
    var _a, _b, _c;
    const settings = this.getSettings(), annotatedHash = final.get(path).hash, sourcePath = localSurvived ? `.gib-sync/conflict-originals/${crypto.randomUUID()}.bin` : void 0;
    if (sourcePath) {
      await this.ensureParent(sourcePath);
      await this.adapter.copy((_a = survivor.sourcePath) != null ? _a : survivor.path, sourcePath);
      this.checkpoint();
      if (await this.savedHash(sourcePath) !== survivor.hash) throw new FileChangedDuringReadError(survivor.path);
    }
    const edited = { id: crypto.randomUUID(), label: (localSurvived ? settings.deviceName : remoteName).slice(0, 100), path, hash: survivor.hash, size: survivor.size, deviceId: localSurvived ? settings.deviceId : (_b = survivor.revision) == null ? void 0 : _b.deviceId, deviceName: localSurvived ? settings.deviceName : remoteName, revisionId: (_c = survivor.revision) == null ? void 0 : _c.id, ...sourcePath ? { sourcePath } : {}, annotatedPath: path, annotatedHash }, deleted = { id: crypto.randomUUID(), label: (localSurvived ? remoteName : settings.deviceName).slice(0, 100), path, hash: null, size: 0, deleted: true, deviceId: localSurvived ? void 0 : settings.deviceId, deviceName: localSurvived ? remoteName : settings.deviceName, annotatedPath: path, annotatedHash };
    await this.conflictStore.save({ id: crypto.randomUUID(), originSnapshotId: null, path, createdAt: (/* @__PURE__ */ new Date()).toISOString(), reason: "An edit and a deletion overlapped; the complete edit was preserved", state: "open", versions: localSurvived ? [edited, deleted] : [deleted, edited] });
  }
  async preserveNamespaceCollision(collision, final, bytes2, remoteCache, occupied) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o;
    const path = collision.path, current = collision.versions.filter((version) => version.side !== "base"), canonical = (_b = (_a = current.find((version) => version.side === "remote" && version.originalPath === path)) != null ? _a : current.find((version) => version.side === "remote")) != null ? _b : current[0], unique = /* @__PURE__ */ new Map();
    for (const version of current) {
      const key = `${(_c = version.entry.fileId) != null ? _c : version.originalPath}:${version.entry.hash}`, previous = unique.get(key);
      if (!previous || version.side === "local") unique.set(key, version);
    }
    const canonicalKey = `${(_d = canonical.entry.fileId) != null ? _d : canonical.originalPath}:${canonical.entry.hash}`, versions = [unique.get(canonicalKey), ...[...unique].filter(([key]) => key !== canonicalKey).sort(([a], [b]) => a.localeCompare(b)).map(([, version]) => version)], known = (await this.conflictStore.list()).find((item) => !item.originSnapshotId && item.reason === "Folders converged onto the same location; every distinct file generation was preserved" && item.path === path && item.versions.length === versions.length && item.versions.every((side, index) => side.hash === versions[index].entry.hash)), names = versions.map((version) => {
      var _a2, _b2;
      return `${(_b2 = (_a2 = version.entry.revision) == null ? void 0 : _a2.deviceName) != null ? _b2 : version.side === "local" ? this.getSettings().deviceName : "Remote device"} \xB7 ${version.originalPath}`;
    }), targets = versions.map((version, index) => {
      var _a2, _b2;
      if (index === 0) return path;
      const target = this.conflictPath(path, (_b2 = (_a2 = version.entry.revision) == null ? void 0 : _a2.deviceName) != null ? _b2 : version.side === "local" ? this.getSettings().deviceName : "Remote device", version.entry.mtime, occupied);
      occupied.add(target);
      return target;
    }), prefix = path.toLowerCase().endsWith(".md") ? `> [!warning] Gib Sync conflict
> Separate folders converged onto this location. Every complete version was preserved from **${names.join("** and **")}**.
> Preserved notes: ${targets.map((target) => this.wikiLink(target)).join(", ")}

` : "", sides = [];
    for (let index = 0; index < versions.length; index++) {
      await this.cooperate();
      const version = versions[index], entry = version.entry, target = targets[index], side = version.side === "local" ? "local" : "remote";
      if (entry.size >= LOW_MEMORY_DOWNLOAD_BYTES) await this.prepareStreamedVersion(target, entry, side, prefix, final);
      else {
        const clear = side === "local" ? await this.localBytes(entry.path, entry, bytes2) : await this.remoteBytes(entry, remoteCache);
        await this.prepareResult(target, prefix ? encoder7.encode(prefix + decoder6.decode(clear)) : clear, final, bytes2);
      }
      const accepted = final.get(target);
      if (index === 0) {
        accepted.fileId = canonical.entry.fileId;
        accepted.revision = canonical.entry.revision;
      } else {
        delete accepted.fileId;
        delete accepted.revision;
      }
      let sourcePath;
      if (side === "local") {
        sourcePath = (_f = (_e = known == null ? void 0 : known.versions[index]) == null ? void 0 : _e.sourcePath) != null ? _f : `.gib-sync/conflict-originals/${crypto.randomUUID()}.bin`;
        if (!await this.adapter.exists(sourcePath)) {
          await this.ensureParent(sourcePath);
          await this.adapter.copy((_g = entry.sourcePath) != null ? _g : version.originalPath, sourcePath);
          this.checkpoint();
        }
        if (await this.savedHash(sourcePath) !== entry.hash) throw new FileChangedDuringReadError(version.originalPath);
      }
      sides.push({ id: (_i = (_h = known == null ? void 0 : known.versions[index]) == null ? void 0 : _h.id) != null ? _i : crypto.randomUUID(), label: names[index].slice(0, 100), path: version.originalPath, hash: entry.hash, size: entry.size, deviceId: (_k = (_j = entry.revision) == null ? void 0 : _j.deviceId) != null ? _k : side === "local" ? this.getSettings().deviceId : void 0, deviceName: (_l = entry.revision) == null ? void 0 : _l.deviceName, revisionId: (_m = entry.revision) == null ? void 0 : _m.id, ...sourcePath ? { sourcePath } : {}, annotatedPath: target, annotatedHash: accepted.hash });
    }
    await this.conflictStore.save({ id: (_n = known == null ? void 0 : known.id) != null ? _n : crypto.randomUUID(), originSnapshotId: null, path, createdAt: (_o = known == null ? void 0 : known.createdAt) != null ? _o : (/* @__PURE__ */ new Date()).toISOString(), reason: "Folders converged onto the same location; every distinct file generation was preserved", state: "open", versions: sides });
  }
  async recordSystemConflict(path, local, remote, preferred, final, remoteName, reason) {
    await this.recordConflict(path, local, remote, this.getSettings().deviceName, remoteName, preferred, path, final, reason);
    const item = (await this.conflictStore.list()).find((item2) => {
      var _a, _b;
      return !item2.originSnapshotId && item2.path === path && ((_a = item2.versions[0]) == null ? void 0 : _a.hash) === local.hash && ((_b = item2.versions[1]) == null ? void 0 : _b.hash) === remote.hash;
    });
    if (item) {
      item.actionRequired = false;
      await this.conflictStore.save(item);
    }
  }
  async publishPendingConflicts(snapshot) {
    var _a;
    const accepted = new Map(snapshot.entries.map((entry) => [entry.path, entry.hash]));
    const pending = (await this.conflictStore.list()).filter((item) => item.state === "open" && !item.published && (item.originSnapshotId || item.versions.every((side) => side.annotatedPath && accepted.get(side.annotatedPath) === side.annotatedHash)));
    if (!pending.length) return;
    for (const item of pending) {
      (_a = item.originSnapshotId) != null ? _a : item.originSnapshotId = snapshot.id;
      await this.conflictStore.save(item);
    }
    if (typeof this.api.publishConflicts === "function") try {
      await this.api.publishConflicts(pending);
      for (const item of pending) {
        item.published = true;
        await this.conflictStore.save(item);
      }
    } catch (error) {
      if (!(error instanceof ApiError && error.status === 404)) throw error;
    }
  }
  async prepareResult(path, clear, final, cache) {
    const hash = await hashBytes(clear), sourcePath = `.gib-sync/prepared/${hash}.bin`;
    await this.ensureParent(sourcePath);
    this.checkpoint();
    await this.adapter.writeBinary(sourcePath, exactArrayBuffer2(clear));
    this.preparedPaths.add(sourcePath);
    cache.set(hash, clear);
    const prior = final.get(path);
    final.set(path, { ...prior, path, hash, size: clear.length, mtime: Date.now(), sourcePath });
  }
  async cleanPreparedResults() {
    for (const path of this.preparedPaths) try {
      if (await this.savedHash(path) === path.slice(path.lastIndexOf("/") + 1, -4)) await this.adapter.remove(path);
    } catch (e) {
    }
    this.preparedPaths.clear();
  }
  manifestEntry(entry) {
    const { path, hash, size, mtime, fileId, revision } = entry;
    return { path, hash, size, mtime, ...fileId ? { fileId } : {}, ...revision ? { revision } : {} };
  }
  same(a, b) {
    return (a == null ? void 0 : a.hash) === (b == null ? void 0 : b.hash) && !!a === !!b;
  }
  localChangeTime(path, entry, baseSnapshot) {
    var _a, _b;
    const normalized = (0, import_obsidian2.normalizePath)(path), times = this.getSettings().pendingPathTimes;
    let journaled = (_a = times[normalized]) != null ? _a : 0, longest = 0;
    for (const [prefix, time] of Object.entries(times)) if (prefix.endsWith("/") && normalized.startsWith(prefix) && prefix.length > longest) {
      longest = prefix.length;
      journaled = time;
    }
    if (journaled) return journaled;
    const mtime = (_b = entry == null ? void 0 : entry.mtime) != null ? _b : 0, baseline = baseSnapshot ? Date.parse(baseSnapshot.createdAt) : 0, now = Date.now();
    const plausible = Number.isFinite(mtime) && mtime > 0 && mtime < now + 5 * 6e4 ? mtime : now;
    return Math.max(plausible, Number.isFinite(baseline) ? baseline : 0);
  }
  preferredSide(path, local, baseSnapshot, remoteSnapshot, remote) {
    var _a, _b, _c, _d, _e;
    const remoteTime = (_e = (_d = (_a = remote == null ? void 0 : remote.revision) == null ? void 0 : _a.modifiedAt) != null ? _d : (_c = (_b = remoteSnapshot == null ? void 0 : remoteSnapshot.entries.find((entry) => entry.path === path)) == null ? void 0 : _b.revision) == null ? void 0 : _c.modifiedAt) != null ? _e : remoteSnapshot ? Date.parse(remoteSnapshot.createdAt) : 0;
    const localTime = this.localChangeTime(path, local, baseSnapshot), verifiedRemoteTime = Number.isFinite(remoteTime) ? remoteTime : 0;
    const observed = Object.entries(this.getSettings().pendingPathTimes).some(([candidate, time]) => time > 0 && (candidate === (0, import_obsidian2.normalizePath)(path) || candidate.endsWith("/") && (0, import_obsidian2.normalizePath)(path).startsWith(candidate)));
    return localTime > verifiedRemoteTime || localTime === verifiedRemoteTime && observed ? "local" : "remote";
  }
  canonicalizeMoves(base, local, remote, baseSnapshot, remoteSnapshot) {
    var _a;
    const localMoves = new Map(detectMoves([...base.values()], [...local.values()], "identity").map((item) => [item.previousPath, item.path]));
    const intents = [...this.getSettings().pendingMoves].sort((left, right) => left.at - right.at);
    for (const [source, entry] of base) {
      let destination = source;
      for (const move of intents) {
        const from = (0, import_obsidian2.normalizePath)(move.from), to = (0, import_obsidian2.normalizePath)(move.to);
        if (destination === from || destination.startsWith(`${from}/`)) destination = destination === from ? to : `${to}${destination.slice(from.length)}`;
      }
      const candidate = local.get(destination);
      if (destination === source || !candidate || local.has(source) || base.has(destination)) continue;
      if (entry.fileId) local.set(destination, { ...candidate, fileId: entry.fileId, revision: entry.revision });
      localMoves.set(source, destination);
    }
    const remoteMoves = new Map(detectMoves([...base.values()], [...remote.values()], "identity").map((item) => [item.previousPath, item.path]));
    const sources = [.../* @__PURE__ */ new Set([...localMoves.keys(), ...remoteMoves.keys()])].sort(), claimed = /* @__PURE__ */ new Set();
    let recognized = 0;
    for (const source of sources) {
      const b = base.get(source), localDestination = localMoves.get(source), remoteDestination = remoteMoves.get(source);
      if (!b) continue;
      const localPath = localDestination != null ? localDestination : source, remotePath = remoteDestination != null ? remoteDestination : source, l = local.get(localPath), r = remote.get(remotePath);
      if (!l && !r) continue;
      if (localDestination && !remoteDestination && remote.has(localDestination)) continue;
      if (remoteDestination && !localDestination && local.has(remoteDestination)) continue;
      if (localDestination && remoteDestination && localDestination !== remoteDestination && (remote.has(localDestination) || local.has(remoteDestination))) continue;
      let destination = localDestination != null ? localDestination : remoteDestination;
      if (localDestination && remoteDestination && localDestination !== remoteDestination) destination = this.preferredSide(localDestination, l, baseSnapshot, remoteSnapshot, r) === "local" ? localDestination : remoteDestination;
      if (!destination || claimed.has(destination) || base.has(destination)) continue;
      claimed.add(destination);
      base.delete(source);
      local.delete(source);
      remote.delete(source);
      if (localDestination) local.delete(localDestination);
      if (remoteDestination) remote.delete(remoteDestination);
      base.set(destination, { ...b, path: destination });
      if (l) local.set(destination, { ...b, ...l, path: destination, sourcePath: (_a = l.sourcePath) != null ? _a : localPath });
      if (r) remote.set(destination, { ...r, path: destination });
      recognized++;
    }
    return recognized;
  }
  acknowledgeMoves(consumed, entries) {
    const settings = this.getSettings();
    settings.pendingMoves = settings.pendingMoves.flatMap((move) => {
      if (consumed.some((item) => item.from === move.from && item.to === move.to && item.at === move.at)) return [];
      const accepted = [...consumed].reverse().find((item) => item.from === move.from && item.at < move.at && entries.some((entry) => entry.path === item.to || entry.path.startsWith(`${item.to}/`)));
      return [{ ...move, ...accepted ? { from: accepted.to } : {} }];
    });
  }
  packageSame(left, right) {
    return left.size === right.size && [...left].every(([path, entry]) => {
      var _a;
      return ((_a = right.get(path)) == null ? void 0 : _a.hash) === entry.hash;
    });
  }
  compareVersions(left, right) {
    var _a, _b;
    if (left === right) return 0;
    if (!left) return -1;
    if (!right) return 1;
    const parse = (value) => {
      const [core, pre] = value.split("-", 2);
      return { parts: core.split(".").map((part) => Number.parseInt(part, 10) || 0), pre: pre != null ? pre : "" };
    }, a = parse(left), b = parse(right);
    for (let index = 0; index < Math.max(a.parts.length, b.parts.length); index++) {
      const difference = ((_a = a.parts[index]) != null ? _a : 0) - ((_b = b.parts[index]) != null ? _b : 0);
      if (difference) return difference;
    }
    if (!a.pre && b.pre) return 1;
    if (a.pre && !b.pre) return -1;
    return a.pre.localeCompare(b.pre);
  }
  async convergeAfterConflict(attempt, reason) {
    if (attempt >= 7) throw new Error("The vault kept changing during eight convergence attempts. Gib Sync preserved every committed version; retry once editing settles.");
    const delay = Math.min(2e3, 100 * 2 ** attempt) + Math.floor(Math.random() * 250);
    this.status({ phase: "merging", message: `${reason}; converging again in ${(delay / 1e3).toFixed(1)}s` });
    await this.wait(delay);
    return this.run(attempt + 1);
  }
  async ownDescendantCount(requestedBaseId, remote, deviceId) {
    if (!requestedBaseId || !remote || remote.id === requestedBaseId || remote.deviceId !== deviceId) return 0;
    let cursor = remote, count = 0;
    while (count < 64) {
      if (cursor.deviceId !== deviceId) return 0;
      count++;
      if (cursor.parentId === requestedBaseId) return count;
      if (!cursor.parentId) return 0;
      try {
        cursor = await this.api.snapshot(cursor.parentId);
      } catch (error) {
        if (error instanceof ApiError && error.status === 404) return 0;
        throw error;
      }
    }
    return 0;
  }
  retryableMirrorError(error) {
    return error instanceof ApiError && (error.status === 409 || error.status === 422);
  }
  async optionalSnapshot(id) {
    try {
      return await this.api.snapshot(id);
    } catch (error) {
      if (error instanceof ApiError && error.status === 404) return null;
      throw error;
    }
  }
  async recoverPendingCommit() {
    var _a, _b;
    const settings = this.getSettings(), intent = settings.pendingCommit;
    if (!intent) return;
    this.status({ phase: "checking", message: "Verifying an interrupted upload before comparing newer edits" });
    let cursor = (await this.api.state()).head, accepted = null, verifiedAbsent = false;
    for (let count = 0; count < 128; count++) {
      await this.cooperate();
      if (((_a = cursor == null ? void 0 : cursor.id) != null ? _a : null) === intent.parentId) {
        verifiedAbsent = true;
        break;
      }
      if (!cursor) {
        verifiedAbsent = true;
        break;
      }
      if (cursor.parentId === intent.parentId) {
        if (cursor.deviceId === settings.deviceId && await commitFingerprint(cursor.entries, cursor.folders) === intent.fingerprint) accepted = cursor;
        else verifiedAbsent = true;
        break;
      }
      if (!cursor.parentId) {
        verifiedAbsent = true;
        break;
      }
      cursor = await this.optionalSnapshot(cursor.parentId);
      if (!cursor) throw new SyncSafetyError("The interrupted upload's history could not be verified. Local edits are safe; no files were changed.");
    }
    if (!accepted) {
      if (!verifiedAbsent) throw new SyncSafetyError("The interrupted upload's receipt needs older server history before sync can safely continue. Local edits are safe.");
      settings.pendingCommit = null;
      await this.saveSettings();
      return;
    }
    if (settings.pendingApplySnapshotId && settings.pendingApplySnapshotId !== accepted.id) throw new SyncSafetyError("The saved upload and download journals disagree. Local files were left unchanged.");
    settings.pendingApplySnapshotId = accepted.id;
    settings.pendingApplyBaseSnapshotId = settings.lastSnapshotId;
    settings.pendingApplyPriorHashes = { ...intent.priorHashes, ...settings.pendingApplyPriorHashes };
    settings.pendingApplyPriorEntries = { ...intent.priorEntries, ...settings.pendingApplyPriorEntries };
    settings.pendingApplyPaths = [.../* @__PURE__ */ new Set([...Object.keys(intent.priorHashes), ...settings.pendingApplyPaths])].filter((path) => this.include(path)).sort();
    settings.fullScanRequired = true;
    await this.intents.acknowledge((_b = intent.intentSequence) != null ? _b : 0);
    await this.saveSettings();
    this.status({ phase: "checking", message: "Verified this device's accepted upload; resuming its checkpoint without creating a self-conflict", level: "success" });
  }
  async assertLocalUnchanged(path, prior) {
    this.checkpoint();
    if (!this.canApplyLocalMutation(path)) {
      this.getSettings().fullScanRequired = true;
      throw new FileChangedDuringReadError(path);
    }
    const stat = await this.adapter.stat(path);
    let same2 = !stat && !prior;
    if ((stat == null ? void 0 : stat.type) === "file" && prior) {
      try {
        same2 = await this.savedHash(path) === prior.hash;
      } catch (error) {
        if (!await this.disappeared(path)) throw error;
      }
    }
    this.checkpoint();
    if (!same2 || !this.canApplyLocalMutation(path)) {
      this.getSettings().fullScanRequired = true;
      throw new FileChangedDuringReadError(path);
    }
  }
  async operationFor(path, targetHash, priorHash) {
    var _a;
    const settings = this.getSettings(), existing = await this.loadOperation(path, targetHash, priorHash);
    if (existing && existing.targetHash === targetHash && existing.priorHash === priorHash) return existing;
    const identity = await hashBytes(encoder7.encode(`${(_a = settings.pendingApplySnapshotId) != null ? _a : "restore"}
${path}
${targetHash != null ? targetHash : "delete"}
${priorHash != null ? priorHash : "absent"}`));
    const operation = { targetHash, priorHash, stagePath: `.gib-sync/apply/${identity}.stage`, backupPath: `.gib-sync/apply/${identity}.backup`, phase: "planned" };
    settings.pendingApplyOperations[path] = operation;
    await this.persistOperation(path, operation);
    this.checkpoint();
    return operation;
  }
  operationRecord(operation) {
    return `${operation.stagePath.slice(0, -6)}.journal`;
  }
  async persistOperation(path, operation, allowCancelled = false) {
    var _a;
    const recordPath = this.operationRecord(operation);
    if (!allowCancelled) {
      await this.ensureParent(recordPath);
      this.checkpoint();
    }
    await this.adapter.writeBinary(recordPath, exactArrayBuffer2(encoder7.encode(JSON.stringify({ path: (_a = operation.namespacePath) != null ? _a : path, snapshotId: this.getSettings().pendingApplySnapshotId, ...operation }))));
    if (!allowCancelled) this.checkpoint();
  }
  async loadOperation(path, targetHash, priorHash) {
    var _a, _b;
    const settings = this.getSettings(), legacy = settings.pendingApplyOperations[path];
    const namespacePath = (_a = legacy == null ? void 0 : legacy.namespacePath) != null ? _a : path;
    const identity = await hashBytes(encoder7.encode(`${(_b = settings.pendingApplySnapshotId) != null ? _b : "restore"}
${namespacePath}
${targetHash != null ? targetHash : "delete"}
${priorHash != null ? priorHash : "absent"}`));
    const expected = { stagePath: `.gib-sync/apply/${identity}.stage`, backupPath: `.gib-sync/apply/${identity}.backup` };
    const recordPath = this.operationRecord((legacy == null ? void 0 : legacy.targetHash) === targetHash && legacy.priorHash === priorHash ? legacy : { ...expected, targetHash, priorHash, phase: "planned" });
    const stat = await this.adapter.stat(recordPath);
    if (!stat) return (legacy == null ? void 0 : legacy.targetHash) === targetHash && legacy.priorHash === priorHash ? legacy : void 0;
    if (stat.type !== "file" || stat.size > 8192) throw new SyncSafetyError(`The recovery journal for ${path} is invalid; local bytes were left unchanged.`);
    let record;
    try {
      record = JSON.parse(decoder6.decode(new Uint8Array(await this.adapter.readBinary(recordPath))));
    } catch (e) {
      throw new SyncSafetyError(`The recovery journal for ${path} is incomplete; local bytes were left unchanged.`);
    }
    if (record.path !== namespacePath || record.snapshotId !== settings.pendingApplySnapshotId || record.targetHash !== targetHash || record.priorHash !== priorHash || record.stagePath !== expected.stagePath || record.backupPath !== expected.backupPath || !["planned", "staged", "backed-up", "promoting", "applied"].includes(record.phase)) throw new SyncSafetyError(`The recovery journal for ${path} does not match its accepted operation; local bytes were left unchanged.`);
    const operation = { targetHash, priorHash, ...expected, phase: record.phase, ...namespacePath !== path ? { namespacePath } : {} };
    settings.pendingApplyOperations[path] = operation;
    return operation;
  }
  async savedHash(path, allowCancelled = false) {
    const stat = await this.adapter.stat(path);
    if (!stat) return null;
    if (stat.type !== "file") throw new FileChangedDuringReadError(path);
    return this.hashLocalFile(path, allowCancelled);
  }
  async hashLocalFile(path, allowCancelled = false) {
    var _a;
    const streamedServer = typeof this.api.supportsStreamUpload === "function" && this.api.supportsStreamUpload(), stat = streamedServer ? await this.adapter.stat(path) : null, allowBufferedFallback = !streamedServer || ((_a = stat == null ? void 0 : stat.size) != null ? _a : 0) < LOW_MEMORY_DOWNLOAD_BYTES;
    try {
      return await hashAdapterFile(this.adapter, path, allowCancelled ? () => {
      } : () => this.checkpoint(), allowCancelled ? this.yieldControl : () => this.cooperate(), allowBufferedFallback);
    } catch (error) {
      if (error instanceof AdapterFileChangedError) throw new FileChangedDuringReadError(path);
      throw error;
    }
  }
  async inspectLocalFile(path, force = false) {
    try {
      return await this.inventory.inspect(path, force);
    } catch (error) {
      if (error instanceof AdapterFileChangedError) throw new FileChangedDuringReadError(path);
      throw error;
    }
  }
  async rollbackMissingDestination(path, operation) {
    const backupHash = await this.savedHash(operation.backupPath, true);
    if (backupHash && await this.savedHash(path, true) === null) {
      operation.phase = "promoting";
      await this.persistOperation(path, operation, true);
      this.expectLocalMutation(path, backupHash);
      try {
        await this.adapter.copy(operation.backupPath, path);
      } catch (error) {
        if (await this.savedHash(path, true) === null) throw error;
      }
    }
  }
  async replaceFile(path, clear, targetHash, prior) {
    var _a;
    await this.assertLocalUnchanged(path, prior);
    const operation = await this.operationFor(path, targetHash, (_a = prior == null ? void 0 : prior.hash) != null ? _a : null);
    try {
      await this.ensureParent(operation.stagePath);
      this.checkpoint();
      await this.adapter.writeBinary(operation.stagePath, exactArrayBuffer2(clear));
      if (await this.savedHash(operation.stagePath) !== targetHash) throw new SyncSafetyError(`Staged download integrity check failed for ${path}; its original content was preserved.`);
      await this.applyVerifiedStage(path, operation, prior);
    } catch (error) {
      await this.rollbackMissingDestination(path, operation);
      throw error;
    }
  }
  async replaceStreamedFile(path, entry, prior) {
    var _a;
    await this.assertLocalUnchanged(path, prior);
    const operation = await this.operationFor(path, entry.hash, (_a = prior == null ? void 0 : prior.hash) != null ? _a : null);
    try {
      await this.ensureParent(operation.stagePath);
      this.checkpoint();
      await this.adapter.writeBinary(operation.stagePath, new ArrayBuffer(0));
      await this.api.streamContent(entry.hash, entry.size, async (chunk) => {
        this.checkpoint();
        await this.adapter.appendBinary(operation.stagePath, exactArrayBuffer2(chunk));
        this.checkpoint();
        await this.cooperate();
      }, () => this.checkpoint());
      if (await this.savedHash(operation.stagePath) !== entry.hash) throw new SyncSafetyError(`Staged download integrity check failed for ${path}; its original content was preserved.`);
      await this.applyVerifiedStage(path, operation, prior);
    } catch (error) {
      await this.rollbackMissingDestination(path, operation);
      throw error;
    }
  }
  async applyVerifiedStage(path, operation, prior) {
    operation.phase = "staged";
    await this.persistOperation(path, operation);
    await this.assertLocalUnchanged(path, prior);
    if (prior) {
      if (await this.adapter.exists(operation.backupPath)) await this.archiveOperationBackup(path, operation);
      this.checkpoint();
      this.expectLocalMutation(path, operation.targetHash);
      await this.adapter.rename(path, operation.backupPath);
      if (await this.savedHash(operation.backupPath) !== prior.hash) throw new FileChangedDuringReadError(path);
    }
    operation.phase = "backed-up";
    await this.persistOperation(path, operation);
    await this.assertLocalUnchanged(path, void 0);
    operation.phase = "promoting";
    await this.persistOperation(path, operation);
    this.expectLocalMutation(path, operation.targetHash);
    this.checkpoint();
    await this.adapter.copy(operation.stagePath, path);
    if (await this.savedHash(path) !== operation.targetHash) throw new SyncSafetyError(`Applied download integrity check failed for ${path}; its recovery copy was retained.`);
    operation.phase = "applied";
    await this.persistOperation(path, operation);
    this.checkpoint();
  }
  async deleteFile(path, prior) {
    await this.assertLocalUnchanged(path, prior);
    const operation = await this.operationFor(path, null, prior.hash);
    try {
      await this.ensureParent(operation.backupPath);
      await this.assertLocalUnchanged(path, prior);
      if (await this.adapter.exists(operation.backupPath)) await this.archiveOperationBackup(path, operation);
      this.checkpoint();
      this.expectLocalMutation(path, null);
      await this.adapter.rename(path, operation.backupPath);
      if (await this.savedHash(operation.backupPath) !== prior.hash) throw new FileChangedDuringReadError(path);
      operation.phase = "applied";
      await this.persistOperation(path, operation);
      this.checkpoint();
    } catch (error) {
      await this.rollbackMissingDestination(path, operation);
      throw error;
    }
  }
  async recoverOperationBoundary(path, targetHash, priorHash) {
    const operation = await this.loadOperation(path, targetHash, priorHash);
    if (!operation) return;
    const current = await this.savedHash(path), backup = await this.savedHash(operation.backupPath);
    if (backup !== null && backup !== operation.priorHash) throw new SyncSafetyError(`Recovery bytes for ${path} changed unexpectedly; neither version was overwritten.`);
    if (operation.phase === "promoting" && current !== null && current !== operation.targetHash && current !== operation.priorHash) throw new SyncSafetyError(`An interrupted copy left an unverified version of ${path}. Its original and incoming copies are safe; use Repair from the accepted server snapshot before syncing. This uncertain content was not uploaded.`);
    if (current === null && backup !== null && operation.targetHash !== null) await this.rollbackMissingDestination(path, operation);
  }
  async finishOperations(explicitRepair = false) {
    const settings = this.getSettings();
    for (const [path, operation] of Object.entries(settings.pendingApplyOperations)) {
      await this.cooperate();
      if (await this.adapter.exists(operation.backupPath)) await this.archiveOperationBackup(path, operation, explicitRepair);
      if (operation.targetHash && await this.savedHash(operation.stagePath) === operation.targetHash) {
        this.checkpoint();
        await this.adapter.remove(operation.stagePath);
      }
      const recordPath = this.operationRecord(operation);
      if (await this.adapter.exists(recordPath)) {
        this.checkpoint();
        await this.adapter.remove(recordPath);
      }
    }
    settings.pendingApplyOperations = {};
  }
  async archiveOperationBackup(path, operation, explicitRepair = false) {
    var _a;
    const expected = explicitRepair ? await this.savedHash(operation.backupPath) : operation.priorHash, recovery = await this.localRecoveryPath(`accepted-${(_a = this.getSettings().pendingApplySnapshotId) != null ? _a : "restore"}`, path);
    await this.ensureParent(recovery);
    if (await this.savedHash(operation.backupPath) !== expected) throw new SyncSafetyError(`The recovery copy for ${path} changed; it was not discarded or archived as a verified original.`);
    this.checkpoint();
    await this.adapter.rename(operation.backupPath, recovery);
  }
  async mirror(snapshotId, entries, final, bytes2, remoteCache) {
    var _a;
    this.status({ phase: "checking", message: "Verifying the Seafile copy" });
    const plan = await this.api.mirrorPlan(snapshotId, entries);
    this.checkpoint();
    if (plan.alreadyCurrent || plan.serverManaged) return 0;
    if (plan.uploadPaths.length || plan.deletePaths.length) this.status({ phase: "mirroring", message: "Updating the Seafile copy", current: 0, total: plan.uploadPaths.length || void 0 });
    let mirrored = 0;
    for (const path of plan.uploadPaths) {
      await this.cooperate();
      const entry = final.get(path);
      if (!entry) throw new Error(`Mirror plan referenced missing path: ${path}`);
      const clear = (_a = bytes2.get(entry.hash)) != null ? _a : await this.remoteBytes(entry, remoteCache);
      if (entry.size < LOW_MEMORY_DOWNLOAD_BYTES) bytes2.set(entry.hash, clear);
      this.checkpoint();
      await this.api.putMirrorFile(snapshotId, path, entry.hash, clear);
      this.checkpoint();
      if (entry.size >= LOW_MEMORY_DOWNLOAD_BYTES) {
        bytes2.delete(entry.hash);
        remoteCache.delete(entry.hash);
      }
      mirrored++;
      if (this.progress(mirrored, plan.uploadPaths.length)) this.status({ phase: "mirroring", message: `Writing readable recovery files (${mirrored}/${plan.uploadPaths.length})`, current: mirrored, total: plan.uploadPaths.length });
    }
    this.checkpoint();
    await this.api.mirrorComplete(snapshotId);
    this.checkpoint();
    this.status({ phase: "checking", message: `Seafile copy verified \xB7 ${entries.length} files` });
    return mirrored;
  }
  async applyFinal(final, physicalLocal, desktopOnlyPlugins, scanned, orphanUnreadableConflicts, bytes2, remoteCache) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n;
    let downloaded = 0, deleted = 0;
    this.status({ phase: "checking", message: "Checking which files this device needs" });
    const packagePaths = /* @__PURE__ */ new Set();
    if (this.packageRuntime && this.getSettings().syncPlugins && ((_a = final.get(this.enablementPath)) == null ? void 0 : _a.hash) !== ((_b = physicalLocal.get(this.enablementPath)) == null ? void 0 : _b.hash)) {
      const readList = async (entry, local) => {
        var _a2;
        if (!entry || entry.size > 512 * 1024) return [];
        const clear = local ? await this.localBytes(entry.path, entry, bytes2) : (_a2 = bytes2.get(entry.hash)) != null ? _a2 : await this.remoteBytes(entry, remoteCache);
        const value = JSON.parse(decoder6.decode(clear));
        return Array.isArray(value) ? value.filter((id) => typeof id === "string") : [];
      };
      const before = await readList(physicalLocal.get(this.enablementPath), true), after = await readList(final.get(this.enablementPath), false), ids = new Set([...before, ...after].filter((id) => before.includes(id) !== after.includes(id)));
      for (const id of ids) {
        if (id === "gib-sync" || /[\\/]/.test(id)) continue;
        const root2 = `${this.logicalConfigDir}/plugins/${id}`;
        if (!await this.adapter.exists(`${root2}/manifest.json`) || !await this.adapter.exists(`${root2}/main.js`)) continue;
        try {
          await this.packageRuntime.quiesce(id);
          await this.queuePackageActivation(id, (_d = (_c = final.get(`${root2}/data.json`)) == null ? void 0 : _c.hash) != null ? _d : await this.savedHash(`${root2}/data.json`), [...final.values()].filter((entry) => {
            var _a2;
            return ((_a2 = this.pluginPath(entry.path)) == null ? void 0 : _a2.id) === id;
          }));
        } catch (error) {
          if (!(error instanceof PackageRuntimeHoldError)) throw error;
          this.getSettings().packageHolds[id] = { reason: error.message, at: Date.now() };
        }
      }
    }
    if (this.getSettings().syncPlugins) {
      for (const root2 of await this.packages.recover((_e = this.getSettings().pendingApplySnapshotId) != null ? _e : void 0)) {
        const id = root2.split("/").at(-1);
        await this.queuePackageActivation(id, await this.savedHash(`${root2}/data.json`), [...final.values()].filter((entry) => {
          var _a2;
          return ((_a2 = this.pluginPath(entry.path)) == null ? void 0 : _a2.id) === id;
        }));
      }
      const changedIds = new Set([...Object.keys(this.getSettings().packageHolds), ...[.../* @__PURE__ */ new Set([...final.keys(), ...physicalLocal.keys()])].filter((path) => {
        var _a2, _b2;
        return this.include(path) && ((_a2 = final.get(path)) == null ? void 0 : _a2.hash) !== ((_b2 = physicalLocal.get(path)) == null ? void 0 : _b2.hash);
      }).map((path) => {
        var _a2;
        return (_a2 = this.pluginPath(path)) == null ? void 0 : _a2.id;
      }).filter((id) => Boolean(id) && id !== "gib-sync")].filter((id) => [...final.keys(), ...physicalLocal.keys()].some((path) => {
        var _a2;
        return ((_a2 = this.pluginPath(path)) == null ? void 0 : _a2.id) === id && ["manifest.json", "main.js"].includes(this.pluginPath(path).relative);
      })));
      for (const id of changedIds) {
        const desired = [...final.values()].filter((entry) => {
          var _a2;
          return this.include(entry.path) && ((_a2 = this.pluginPath(entry.path)) == null ? void 0 : _a2.id) === id;
        }), observed = [...physicalLocal.values()].filter((entry) => {
          var _a2;
          return ((_a2 = this.pluginPath(entry.path)) == null ? void 0 : _a2.id) === id;
        }), root2 = (0, import_obsidian2.normalizePath)(`${this.logicalConfigDir}/plugins/${id}`);
        const hold = this.getSettings().packageHolds[id];
        if (hold && (hold.kind === "incomplete" || hold.fingerprint === await this.packageFingerprint(desired) && ((_f = hold.retryAt) != null ? _f : 0) > Date.now())) {
          for (const entry of [...desired, ...observed]) packagePaths.add(entry.path);
          continue;
        }
        if (desired.length && (!desired.some((entry) => entry.path === `${root2}/manifest.json`) || !desired.some((entry) => entry.path === `${root2}/main.js`))) throw new SyncSafetyError(`Plugin ${id} has an incomplete accepted package. Its existing package and settings were retained.`);
        this.status({ phase: "applying", message: `Installing verified complete plugin package \xB7 ${id}` });
        try {
          await ((_g = this.packageRuntime) == null ? void 0 : _g.quiesce(id));
          this.expectLocalMutation(root2, desired.length ? "folder" : null);
          await this.packages.install(root2, desired, observed, (_h = this.getSettings().pendingApplySnapshotId) != null ? _h : "accepted", async (entry, destination) => {
            var _a2, _b2, _c2;
            const prepared = final.get(entry.path), source = (_b2 = prepared == null ? void 0 : prepared.sourcePath) != null ? _b2 : ((_a2 = physicalLocal.get(entry.path)) == null ? void 0 : _a2.hash) === entry.hash ? entry.path : null;
            if (source) {
              this.checkpoint();
              await this.adapter.copy(source, destination);
              this.checkpoint();
              return;
            }
            if (entry.size >= LOW_MEMORY_DOWNLOAD_BYTES && typeof this.adapter.appendBinary === "function" && typeof this.api.streamContent === "function") {
              await this.adapter.writeBinary(destination, new ArrayBuffer(0));
              await this.api.streamContent(entry.hash, entry.size, async (chunk) => {
                this.checkpoint();
                await this.adapter.appendBinary(destination, exactArrayBuffer2(chunk));
                await this.cooperate();
              }, () => this.checkpoint());
            } else {
              const clear = (_c2 = bytes2.get(entry.hash)) != null ? _c2 : await this.remoteBytes(entry, remoteCache);
              await this.adapter.writeBinary(destination, exactArrayBuffer2(clear));
              this.checkpoint();
            }
          });
          delete this.getSettings().packageHolds[id];
          if (desired.length) await this.queuePackageActivation(id, (_j = (_i = desired.find((entry) => entry.path === `${root2}/data.json`)) == null ? void 0 : _i.hash) != null ? _j : null, desired);
        } catch (error) {
          if (error instanceof PackageRuntimeHoldError) {
            await this.holdPackage(id, error.message, "activation", desired, observed);
            for (const entry of [...desired, ...observed]) packagePaths.add(entry.path);
            this.status({ phase: "applying", message: error.message, level: "warning" });
            continue;
          }
          if (error instanceof AdapterFileChangedError) throw new FileChangedDuringReadError(error.path);
          throw error;
        }
        for (const entry of desired) {
          packagePaths.add(entry.path);
          if (((_k = physicalLocal.get(entry.path)) == null ? void 0 : _k.hash) !== entry.hash) downloaded++;
          this.inventory.markDirty(entry.path);
        }
        for (const entry of observed) {
          packagePaths.add(entry.path);
          if (!final.has(entry.path)) deleted++;
        }
      }
    }
    const operationTotal = [...final].filter(([path, entry]) => {
      var _a2;
      return ((_a2 = physicalLocal.get(path)) == null ? void 0 : _a2.hash) !== entry.hash;
    }).length + [...physicalLocal.keys()].filter((path) => !final.has(path) && this.include(path)).length;
    const applyOrder = [...final].sort(([left, leftEntry], [right, rightEntry]) => {
      const rank = (path, entry) => path === this.enablementPath ? 4 : entry.size >= LOW_MEMORY_DOWNLOAD_BYTES ? 3 : this.pluginPath(path) ? 0 : this.systemPath(path) ? 2 : 1;
      return rank(left, leftEntry) - rank(right, rightEntry) || left.localeCompare(right);
    });
    for (const [path, entry] of applyOrder) {
      if (!this.include(path) || this.heldPackagePath(path)) continue;
      if (packagePaths.has(path)) continue;
      await this.cooperate();
      let deviceEntry = entry, deviceClear;
      if (this.isMobileDevice && path === this.enablementPath && desktopOnlyPlugins.size) {
        const serverClear = (_l = bytes2.get(entry.hash)) != null ? _l : await this.remoteBytes(entry, remoteCache);
        try {
          const enabled = JSON.parse(decoder6.decode(serverClear));
          if (Array.isArray(enabled)) {
            deviceClear = encoder7.encode(`${JSON.stringify(enabled.filter((id) => typeof id === "string" && !desktopOnlyPlugins.has(id)), null, 2)}
`);
            const hash = await hashBytes(deviceClear);
            deviceEntry = { ...entry, hash, size: deviceClear.length };
          }
        } catch (e) {
        }
      }
      if (((_m = physicalLocal.get(path)) == null ? void 0 : _m.hash) === deviceEntry.hash) continue;
      this.status({ phase: "applying", message: "Updating files on this device", current: downloaded + deleted, total: operationTotal });
      if (entry.size >= LOW_MEMORY_DOWNLOAD_BYTES) this.status({ phase: "applying", message: `Downloading large file with mobile-safe memory use \xB7 ${path} \xB7 ${(entry.size / 1024 / 1024).toFixed(1)} MB`, current: downloaded + deleted, total: operationTotal });
      if (entry.size >= LOW_MEMORY_DOWNLOAD_BYTES && !deviceClear && typeof this.adapter.appendBinary === "function" && typeof this.api.streamContent === "function") {
        await this.ensureParent(path);
        await this.replaceStreamedFile(path, entry, physicalLocal.get(path));
        bytes2.delete(entry.hash);
        remoteCache.delete(entry.hash);
        downloaded++;
        continue;
      }
      const clear = (_n = deviceClear != null ? deviceClear : bytes2.get(entry.hash)) != null ? _n : await this.remoteBytes(entry, remoteCache);
      if (entry.size < LOW_MEMORY_DOWNLOAD_BYTES && !deviceClear) bytes2.set(entry.hash, clear);
      await this.ensureParent(path);
      await this.replaceFile(path, clear, deviceEntry.hash, physicalLocal.get(path));
      if (entry.size >= LOW_MEMORY_DOWNLOAD_BYTES) {
        bytes2.delete(entry.hash);
        remoteCache.delete(entry.hash);
      }
      downloaded++;
    }
    for (const path of physicalLocal.keys()) if (!final.has(path) && this.include(path)) {
      if (this.heldPackagePath(path)) continue;
      if (packagePaths.has(path)) continue;
      await this.cooperate();
      if (scanned.unreadableConflictPaths.has(path)) {
        this.status({ phase: "applying", message: `Left inaccessible generated conflict entry isolated on this device \xB7 ${path}`, level: "warning" });
        continue;
      }
      this.status({ phase: "applying", message: "Applying accepted file deletions", current: downloaded + deleted, total: operationTotal });
      await this.deleteFile(path, physicalLocal.get(path));
      deleted++;
    }
    for (const path of orphanUnreadableConflicts) this.status({ phase: "applying", message: `Unreadable local file retained \xB7 ${path} \xB7 its filename does not authorize deletion`, level: "warning" });
    return { downloaded, deleted };
  }
  trimRetiredPaths() {
    const settings = this.getSettings(), cutoff = Date.now() - RETIRED_PATH_MAX_AGE;
    settings.retiredPaths = Object.fromEntries(Object.entries(settings.retiredPaths).sort((left, right) => right[1].retiredAt - left[1].retiredAt));
    settings.folderCreateTimes = Object.fromEntries(Object.entries(settings.folderCreateTimes).filter(([, createdAt]) => createdAt >= cutoff).sort((left, right) => right[1] - left[1]).slice(0, RETIRED_PATH_LIMIT));
  }
  async deviceBytes(path, entry, cache, desktopOnly) {
    let clear = await this.remoteBytes(entry, cache), hash = entry.hash;
    if (this.isMobileDevice && path === this.enablementPath && desktopOnly.size) try {
      const enabled = JSON.parse(decoder6.decode(clear));
      if (Array.isArray(enabled)) {
        clear = encoder7.encode(`${JSON.stringify(enabled.filter((id) => typeof id === "string" && !desktopOnly.has(id)), null, 2)}
`);
        hash = await hashBytes(clear);
      }
    } catch (e) {
    }
    return { clear, hash };
  }
  async resumePendingApplication() {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w;
    const settings = this.getSettings(), pending = [...new Set(settings.pendingApplyPaths.map((path) => (0, import_obsidian2.normalizePath)(path)).filter(Boolean))];
    if (!pending.length && !settings.pendingApplySnapshotId) return 0;
    const targetId = (_a = settings.pendingApplySnapshotId) != null ? _a : settings.lastSnapshotId;
    if (!targetId) throw new SyncSafetyError("An accepted device update is pending, but its target snapshot was not recorded.");
    const target = this.canonicalSnapshot(await this.optionalSnapshot(targetId));
    if (!target) throw new SyncSafetyError("An accepted device update is pending, but its exact server snapshot is unavailable. No local files were uploaded or deleted.");
    const priorId = (_b = settings.pendingApplyBaseSnapshotId) != null ? _b : target.parentId, prior = this.canonicalSnapshot(priorId ? await this.optionalSnapshot(priorId) : null), targetMap = this.map(target), priorMap = this.map(prior), cache = this.bodyCache(), desktopOnly = /* @__PURE__ */ new Set();
    let completed = 0, preserved = 0;
    if (this.isMobileDevice) for (const [path, entry] of targetMap) {
      const plugin = this.pluginPath(path);
      if ((plugin == null ? void 0 : plugin.relative.toLowerCase()) !== "manifest.json") continue;
      try {
        if (JSON.parse(decoder6.decode(await this.remoteBytes(entry, cache))).isDesktopOnly === true) desktopOnly.add(plugin.id);
      } catch (e) {
      }
    }
    const packageHandled = /* @__PURE__ */ new Set();
    if (settings.syncPlugins) {
      try {
        for (const root2 of await this.packages.recover(target.id)) {
          const id = root2.split("/").at(-1);
          await this.queuePackageActivation(id, (_d = (_c = targetMap.get(`${root2}/data.json`)) == null ? void 0 : _c.hash) != null ? _d : null, [...targetMap.values()].filter((entry) => {
            var _a2;
            return ((_a2 = this.pluginPath(entry.path)) == null ? void 0 : _a2.id) === id;
          }));
        }
      } catch (error) {
        if (error instanceof AdapterFileChangedError) throw new FileChangedDuringReadError(error.path);
        throw error;
      }
      const ids = new Set(pending.map((path) => {
        var _a2;
        return (_a2 = this.pluginPath(path)) == null ? void 0 : _a2.id;
      }).filter((id) => Boolean(id) && id !== "gib-sync"));
      for (const id of ids) {
        const packageEntries = [...targetMap.values()].filter((entry) => {
          var _a2;
          return ((_a2 = this.pluginPath(entry.path)) == null ? void 0 : _a2.id) === id;
        }), oldEntries = [...priorMap.values()].filter((entry) => {
          var _a2;
          return ((_a2 = this.pluginPath(entry.path)) == null ? void 0 : _a2.id) === id;
        });
        if (![...packageEntries, ...oldEntries].some((entry) => ["manifest.json", "main.js"].includes(this.pluginPath(entry.path).relative))) continue;
        const root2 = (0, import_obsidian2.normalizePath)(`${this.logicalConfigDir}/plugins/${id}`), physical = /* @__PURE__ */ new Map();
        for (const path of await this.listFiles(root2)) {
          const stat = await this.adapter.stat(path);
          if ((stat == null ? void 0 : stat.type) !== "file") continue;
          physical.set(path, { path, hash: await this.hashLocalFile(path), size: stat.size, mtime: stat.mtime });
        }
        let changedDuringApply = false;
        for (const path of pending.filter((path2) => {
          var _a2;
          return ((_a2 = this.pluginPath(path2)) == null ? void 0 : _a2.id) === id;
        })) {
          const current = (_f = (_e = physical.get(path)) == null ? void 0 : _e.hash) != null ? _f : null, expected = (_h = (_g = targetMap.get(path)) == null ? void 0 : _g.hash) != null ? _h : null, priorHash = (_k = (_j = settings.pendingApplyPriorHashes[path]) != null ? _j : (_i = priorMap.get(path)) == null ? void 0 : _i.hash) != null ? _k : null, operation = await this.loadOperation(path, expected, priorHash);
          if ((operation == null ? void 0 : operation.phase) === "promoting" && current !== expected && current !== priorHash) throw new SyncSafetyError(`An interrupted plugin copy left an unverified version of ${path}. Both originals are retained; repair the accepted snapshot before publishing any changes.`);
          if (current !== expected && current !== priorHash) changedDuringApply = true;
          packageHandled.add(path);
        }
        if (changedDuringApply) {
          for (const path of /* @__PURE__ */ new Set([...packageEntries.map((entry) => entry.path), ...oldEntries.map((entry) => entry.path), ...physical.keys()])) {
            settings.localReconcileBases[path] = (_m = (_l = settings.pendingApplyPriorEntries[path]) != null ? _l : priorMap.get(path)) != null ? _m : null;
            if (!settings.pendingPaths.includes(path)) settings.pendingPaths.push(path);
            (_o = (_n = settings.pendingPathTimes)[path]) != null ? _o : _n[path] = Date.now();
            this.inventory.markDirty(path);
          }
          preserved++;
          this.status({ phase: "applying", message: `Preserved plugin ${id}'s settings changed during the download; its complete package will reconcile before activation`, level: "info" });
          continue;
        }
        await this.applyFinal(new Map(packageEntries.map((entry) => [entry.path, entry])), physical, desktopOnly, { files: physical, folders: /* @__PURE__ */ new Set(), unreadableConflictPaths: /* @__PURE__ */ new Set() }, [], this.bodyCache(), cache);
      }
    }
    for (const path of pending) {
      const old = priorMap.get(path);
      if (!targetMap.has(path) && old) settings.retiredPaths[path] = { hash: old.hash, snapshotId: target.id, retiredAt: Date.now() };
    }
    this.trimRetiredPaths();
    await this.saveSettings();
    this.status({ phase: "applying", message: `Resuming ${pending.length} accepted file operation${pending.length === 1 ? "" : "s"} from its exact snapshot` });
    for (const path of [...pending].sort((left, right) => Number(left === this.enablementPath) - Number(right === this.enablementPath) || left.localeCompare(right))) {
      if (packageHandled.has(path)) {
        completed++;
        continue;
      }
      await this.cooperate();
      const entry = targetMap.get(path), old = priorMap.get(path);
      this.inventory.markDirty(path);
      const priorHash = Object.prototype.hasOwnProperty.call(settings.pendingApplyPriorHashes, path) ? settings.pendingApplyPriorHashes[path] : (_p = old == null ? void 0 : old.hash) != null ? _p : null;
      const expected = entry ? this.isMobileDevice && path === this.enablementPath ? await this.deviceBytes(path, entry, cache, desktopOnly) : { hash: entry.hash, clear: void 0 } : void 0;
      await this.recoverOperationBoundary(path, (_q = expected == null ? void 0 : expected.hash) != null ? _q : null, priorHash);
      let stat = await this.adapter.stat(path), currentHash = null;
      if ((stat == null ? void 0 : stat.type) === "file") try {
        currentHash = await this.savedHash(path);
      } catch (error) {
        if (await this.disappeared(path)) stat = null;
        else throw error;
      }
      if (entry) {
        if (currentHash === expected.hash) {
          completed++;
          continue;
        }
        if (currentHash !== null && currentHash !== priorHash) {
          const replayBase = (_r = settings.pendingApplyPriorEntries[path]) != null ? _r : (old == null ? void 0 : old.hash) === priorHash ? old : void 0;
          settings.localReconcileBases[path] = replayBase != null ? replayBase : null;
          preserved++;
          settings.pendingPathTimes[path] = (_s = settings.pendingPathTimes[path]) != null ? _s : Date.now();
          if (!settings.pendingPaths.includes(path)) settings.pendingPaths.push(path);
          completed++;
          continue;
        }
        await this.ensureParent(path);
        const observed = currentHash && stat ? { path, hash: currentHash, size: stat.size, mtime: stat.mtime } : void 0;
        if (entry.size >= LOW_MEMORY_DOWNLOAD_BYTES && typeof this.adapter.appendBinary === "function" && typeof this.api.streamContent === "function") await this.replaceStreamedFile(path, entry, observed);
        else await this.replaceFile(path, (_t = expected.clear) != null ? _t : await this.remoteBytes(entry, cache), expected.hash, observed);
      } else if (stat) {
        if (priorHash !== null && currentHash === priorHash) await this.deleteFile(path, { path, hash: currentHash, size: stat.size, mtime: stat.mtime });
        else {
          settings.localReconcileBases[path] = (_v = (_u = settings.pendingApplyPriorEntries[path]) != null ? _u : old) != null ? _v : null;
          preserved++;
          settings.pendingPathTimes[path] = (_w = settings.pendingPathTimes[path]) != null ? _w : Date.now();
          if (!settings.pendingPaths.includes(path)) settings.pendingPaths.push(path);
        }
      }
      completed++;
      if (this.progress(completed, pending.length)) this.status({ phase: "applying", message: "Resuming accepted device state", current: completed, total: pending.length });
    }
    const retiredCleanup = await this.pruneRetiredEmptyFolders(), topology = await this.reconcileFolderTopology(this.snapshotFolders(target), target.folderRepair, target.createdAt);
    await this.activatePackages();
    await this.finishOperations();
    settings.lastSnapshotId = target.id;
    settings.initialized = true;
    settings.pendingApplyPaths = [];
    settings.pendingApplySnapshotId = null;
    settings.pendingApplyBaseSnapshotId = null;
    settings.pendingApplyPriorHashes = {};
    settings.pendingApplyPriorEntries = {};
    settings.pendingCommit = null;
    settings.pendingPaths = [...new Set(settings.pendingPaths)].sort();
    if (settings.syncPlugins) settings.pluginSyncBootstrapPending = false;
    await this.saveSettings();
    if (preserved) this.status({ phase: "applying", message: `Preserved ${preserved} genuine local change${preserved === 1 ? "" : "s"} made during the interrupted download; they will reconcile normally`, level: "success" });
    return retiredCleanup.removed + topology.removed;
  }
  async stageAndApply(snapshotId, final, topologyPaths, physicalLocal, desktopOnlyPlugins, scanned, orphanUnreadableConflicts, bytes2, remoteCache, folderRepair, repairSnapshotCreatedAt) {
    const changed = [...final].filter(([path, entry]) => {
      var _a;
      return this.include(path) && !this.heldPackagePath(path) && ((_a = physicalLocal.get(path)) == null ? void 0 : _a.hash) !== entry.hash;
    }).map(([path]) => path), removed = [...physicalLocal.keys()].filter((path) => !final.has(path) && !this.heldPackagePath(path));
    const settings = this.getSettings(), baseId = settings.lastSnapshotId;
    settings.pendingApplySnapshotId = snapshotId;
    settings.pendingApplyBaseSnapshotId = baseId;
    settings.pendingApplyPaths = [.../* @__PURE__ */ new Set([...changed, ...removed, ...orphanUnreadableConflicts])].sort();
    settings.pendingApplyPriorHashes = Object.fromEntries(settings.pendingApplyPaths.map((path) => {
      var _a, _b;
      return [path, (_b = (_a = physicalLocal.get(path)) == null ? void 0 : _a.hash) != null ? _b : null];
    }));
    settings.pendingApplyPriorEntries = Object.fromEntries(settings.pendingApplyPaths.flatMap((path) => {
      const entry = physicalLocal.get(path);
      return entry ? [[path, this.manifestEntry(entry)]] : [];
    }));
    for (const path of removed) {
      const previous = physicalLocal.get(path);
      if (previous) settings.retiredPaths[path] = { hash: previous.hash, snapshotId, retiredAt: Date.now() };
    }
    this.trimRetiredPaths();
    await this.saveSettings();
    const result = await this.applyFinal(final, physicalLocal, desktopOnlyPlugins, scanned, orphanUnreadableConflicts, bytes2, remoteCache), retiredCleanup = await this.pruneRetiredEmptyFolders(), topology = await this.reconcileFolderTopology(topologyPaths, folderRepair, repairSnapshotCreatedAt);
    await this.activatePackages();
    await this.finishOperations();
    settings.lastSnapshotId = snapshotId;
    if (!topology.remaining) settings.observedFolderSnapshotId = snapshotId;
    settings.initialized = true;
    settings.pendingApplyPaths = [];
    settings.pendingApplySnapshotId = null;
    settings.pendingApplyBaseSnapshotId = null;
    settings.pendingApplyPriorHashes = {};
    settings.pendingApplyPriorEntries = {};
    settings.localReconcileBases = {};
    settings.pendingCommit = null;
    if (settings.syncPlugins) settings.pluginSyncBootstrapPending = false;
    await this.saveSettings();
    return { ...result, prunedFolders: retiredCleanup.removed + topology.removed };
  }
  async recoverPendingBatch() {
    let record = await this.operations.load();
    if (!record) return;
    const wasAccepted = record.phase === "accepted";
    if (record.phase === "prepared") {
      await this.operations.clear();
      return;
    }
    if (typeof this.api.supportsOperationsV2 !== "function" || !this.api.supportsOperationsV2()) throw new SyncSafetyError("This device has a saved operation awaiting its server receipt. The server must support operation recovery before syncing can resume.");
    if (record.phase === "submitted") {
      let receipt2;
      try {
        receipt2 = await this.api.batchReceipt(record.batch.batchId);
      } catch (error) {
        if (!(error instanceof ApiError && error.status === 404)) throw error;
        try {
          receipt2 = await this.api.operationBatch(record.batch);
        } catch (retryError) {
          if (retryError instanceof ApiError && retryError.status >= 400 && retryError.status < 500 && retryError.status !== 408 && retryError.status !== 423) {
            await this.operations.clear();
            return;
          }
          throw retryError;
        }
      }
      this.assertOwnedReceipt(receipt2, record.batch);
      if (receipt2.batchId !== record.batch.batchId) throw new SyncSafetyError("The server returned a different durable operation receipt");
      record = { ...record, phase: "accepted", receipt: receipt2 };
      await this.operations.save(record);
    }
    const receipt = record.receipt;
    if (!receipt) throw new SyncSafetyError("An accepted operation journal is missing its receipt; local files were retained");
    const scope = this.getSettings();
    if (receipt.batchId !== record.batch.batchId || receipt.snapshot.vaultId !== scope.vaultId || receipt.snapshot.deviceId !== scope.deviceId) throw new SyncSafetyError("An operation receipt does not belong to this device and vault; no files were changed");
    if (wasAccepted) {
      const authenticated = await this.api.batchReceipt(record.batch.batchId);
      if (authenticated.batchId !== receipt.batchId || authenticated.sequence !== receipt.sequence || authenticated.snapshot.vaultId !== scope.vaultId || authenticated.snapshot.deviceId !== scope.deviceId || JSON.stringify(authenticated.snapshot) !== JSON.stringify(receipt.snapshot)) throw new SyncSafetyError("The saved accepted receipt does not match its authenticated immutable server proof; all local versions were retained");
      record.receipt = authenticated;
    }
    await this.publishPendingConflicts(receipt.snapshot);
    const settings = this.getSettings();
    if (settings.lastSnapshotId !== receipt.snapshot.id && !settings.pendingApplySnapshotId) {
      settings.pendingApplySnapshotId = receipt.snapshot.id;
      settings.pendingApplyBaseSnapshotId = settings.lastSnapshotId;
      settings.pendingApplyPaths = Object.keys(record.priorHashes);
      settings.pendingApplyPriorHashes = { ...record.priorHashes };
      settings.pendingApplyPriorEntries = { ...record.priorEntries };
      await this.saveSettings();
    }
    if (settings.pendingApplySnapshotId || settings.pendingApplyPaths.length) await this.resumePendingApplication();
    await this.recordDecision(record);
    await this.intents.acknowledge(record.intentSequence);
    await this.operations.clear();
    this.checkpoint();
  }
  assertOwnedReceipt(receipt, batch) {
    const settings = this.getSettings();
    if (receipt.batchId !== batch.batchId || !receipt.snapshot || receipt.snapshot.vaultId !== settings.vaultId || receipt.snapshot.deviceId !== settings.deviceId) throw new SyncSafetyError("The operation receipt does not belong to this device and vault; no files were changed");
  }
  async run(attempt) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, _L, _M, _N, _O, _P, _Q, _R, _S, _T, _U, _V, _W, _X, _Y, _Z, __, _$, _aa, _ba, _ca, _da, _ea, _fa, _ga, _ha, _ia, _ja, _ka, _la, _ma, _na, _oa, _pa, _qa, _ra, _sa, _ta;
    const settings = this.getSettings();
    if (!settings.deviceToken || !settings.vaultKey) throw new Error("Gib Sync is not configured");
    if (this.firstRun) {
      this.firstRun = false;
      for (const hold of Object.values(settings.packageHolds)) hold.retryAt = 0;
    }
    if (!settings.syncPlugins) settings.packageHolds = {};
    await this.intents.flush();
    await this.recoverPendingBatch();
    await this.recoverPendingCommit();
    const initialFolderCleanup = await this.pruneRetiredEmptyFolders();
    let prunedFolders = initialFolderCleanup.removed;
    if (initialFolderCleanup.attempted) await this.saveSettings();
    let requestedBaseId = settings.lastSnapshotId;
    let pendingPaths = [...new Set(settings.pendingPaths.map((path) => (0, import_obsidian2.normalizePath)(path)).filter(Boolean))];
    const consumedMoves = settings.pendingMoves.map((move) => ({ ...move }));
    const lastAudit = settings.lastFullScanAt ? Date.parse(settings.lastFullScanAt) : 0, auditDue = !lastAudit || Date.now() - lastAudit >= 6 * 60 * 60 * 1e3;
    const heldRetryDue = Object.values(settings.packageHolds).some((hold) => {
      var _a2;
      return ((_a2 = hold.retryAt) != null ? _a2 : 0) <= Date.now();
    });
    this.status({ phase: "reading-remote", message: "Checking for a newer server snapshot" });
    let remoteHeadId;
    try {
      remoteHeadId = (await this.api.headState()).headId;
    } catch (error) {
      if (!(error instanceof ApiError && error.status === 404)) throw error;
      remoteHeadId = (_b = (_a = (await this.api.state()).head) == null ? void 0 : _a.id) != null ? _b : null;
    }
    if (remoteHeadId !== requestedBaseId) this.status({ phase: "checking", message: "New server changes found", remoteChanged: true });
    if (settings.initialized && !settings.pendingApplySnapshotId && !settings.pendingApplyPaths.length && !Object.keys(settings.localReconcileBases).length && !settings.fullScanRequired && !settings.pluginSyncBootstrapPending && !auditDue && !heldRetryDue && !pendingPaths.length && remoteHeadId === requestedBaseId) {
      const inspectTopology = settings.observedFolderSnapshotId !== requestedBaseId || settings.retiredFolderCount > 0 || Boolean(settings.lastFolderCleanupError);
      let topology = { removed: 0, remaining: 0 };
      if (inspectTopology) {
        const accepted = requestedBaseId ? await this.api.snapshot(requestedBaseId) : null;
        topology = await this.reconcileFolderTopology(this.snapshotFolders(accepted), accepted == null ? void 0 : accepted.folderRepair, accepted == null ? void 0 : accepted.createdAt);
        prunedFolders += topology.removed;
        await this.saveSettings();
      }
      this.status({ phase: topology.remaining ? "applying" : "up-to-date", message: topology.remaining ? settings.retiredFolderNote : "Up to date \xB7 accepted file manifest and observed folders agree", level: topology.remaining ? "warning" : "success" });
      return { uploaded: 0, downloaded: 0, deleted: 0, prunedFolders, pendingRetiredFolders: settings.retiredFolderCount, conflicts: 0, resolved: 0, mirrored: 0, snapshotId: requestedBaseId, processedPaths: [], fullScan: false, pendingPackages: Object.keys(settings.packageHolds) };
    }
    const operationTree = typeof this.api.supportsOperationsV2 === "function" && this.api.supportsOperationsV2() ? await this.api.syncTree() : null;
    const rollout = operationTree && typeof this.api.rolloutStatus === "function" ? await this.api.rolloutStatus() : null, usesOperations = Boolean(operationTree && (!rollout || rollout.mode === "active" || rollout.mode === "canary" && rollout.canaryDeviceId === settings.deviceId));
    const remoteSnapshot = this.canonicalSnapshot((operationTree == null ? void 0 : operationTree.snapshotId) ? await this.api.snapshot(operationTree.snapshotId) : (await this.api.state()).head);
    if (settings.pendingApplySnapshotId || settings.pendingApplyPaths.length) {
      prunedFolders += await this.resumePendingApplication();
      requestedBaseId = settings.lastSnapshotId;
      pendingPaths = [...new Set(settings.pendingPaths.map((path) => (0, import_obsidian2.normalizePath)(path)).filter(Boolean))];
    }
    const baseSnapshot = this.canonicalSnapshot(requestedBaseId ? await this.optionalSnapshot(requestedBaseId) : null);
    const ownDescendants = baseSnapshot && pendingPaths.length ? await this.ownDescendantCount(requestedBaseId, remoteSnapshot, settings.deviceId) : 0;
    const fullScan = heldRetryDue || Boolean(Object.keys(settings.packageHolds).length && remoteHeadId !== requestedBaseId) || settings.fullScanRequired || Boolean(Object.keys(settings.localReconcileBases).length) || settings.pluginSyncBootstrapPending || !settings.initialized || !baseSnapshot || auditDue;
    this.status({ phase: "scanning", message: fullScan ? "Reconciling the full local vault" : pendingPaths.length ? `Checking ${pendingPaths.length} changed path${pendingPaths.length === 1 ? "" : "s"}` : "No local paths changed" });
    const scanBaseline = ownDescendants && remoteSnapshot ? remoteSnapshot : baseSnapshot;
    const scanned = fullScan ? await this.scan() : await this.scanIncremental(scanBaseline, pendingPaths), local = scanned.files;
    const intentPath = (path) => {
      for (const alias of this.configAliases) if (path === alias || path.startsWith(`${alias}/`)) return `.obsidian${path.slice(alias.length)}`;
      return path;
    }, observedIntents = (await this.intents.snapshot()).map((event) => ({ ...event, path: intentPath(event.path), ...event.from ? { from: intentPath(event.from) } : {} })), latestFileIntent = new Map([...indexedIntentCreates(observedIntents).values()].filter((event) => event.entity === "file").map((event) => [event.path, event]));
    for (const observed of local.values()) {
      const created = latestFileIntent.get(observed.path);
      if ((created == null ? void 0 : created.kind) === "create" && created.targetId) observed.fileId = created.targetId;
    }
    const observedLineage = new Map(((_c = scanBaseline == null ? void 0 : scanBaseline.entries) != null ? _c : []).map((entry) => [entry.path, { ...entry }]));
    for (const event of observedIntents) {
      if (event.kind === "move" && event.from) {
        const moved = [...observedLineage].filter(([path]) => path === event.from || event.entity === "folder" && path.startsWith(`${event.from}/`));
        for (const [from, entry] of moved) {
          observedLineage.delete(from);
          const path = `${event.path}${from.slice(event.from.length)}`;
          observedLineage.set(path, { ...entry, path });
        }
      } else if (event.kind === "delete" || event.kind === "create") {
        for (const path of observedLineage.keys()) if (path === event.path || event.entity === "folder" && path.startsWith(`${event.path}/`)) observedLineage.delete(path);
      }
    }
    for (const [path, entry] of observedLineage) {
      const observed = local.get(path);
      if (!observed) continue;
      const recreated = observed.fileId && entry.fileId && observed.fileId !== entry.fileId;
      local.set(path, recreated ? { ...observed } : { ...entry, ...observed });
    }
    let effectiveBaseSnapshot = baseSnapshot;
    if (ownDescendants && remoteSnapshot) {
      const remoteMap = this.map(remoteSnapshot), allPaths = /* @__PURE__ */ new Set([...local.keys(), ...remoteMap.keys()]), pending = new Set(pendingPaths);
      const differences = [...allPaths].filter((path) => {
        var _a2, _b2;
        return ((_a2 = local.get(path)) == null ? void 0 : _a2.hash) !== ((_b2 = remoteMap.get(path)) == null ? void 0 : _b2.hash) || local.has(path) !== remoteMap.has(path);
      });
      if (!fullScan || differences.every((path) => pending.has(path))) {
        effectiveBaseSnapshot = remoteSnapshot;
        this.status({ phase: "merging", message: `Recovered a stale local checkpoint across ${ownDescendants} prior sync${ownDescendants === 1 ? "" : "s"} from this device; applying only newly observed local changes`, level: "success" });
      } else {
        const recovered = new Map(this.map(baseSnapshot));
        let count = 0;
        for (const path of allPaths) if ([...pending].some((prefix) => path === prefix || path.startsWith(`${prefix.replace(/\/$/, "")}/`))) {
          const entry = remoteMap.get(path);
          if (entry) recovered.set(path, entry);
          else recovered.delete(path);
          count++;
        }
        effectiveBaseSnapshot = { ...baseSnapshot, entries: [...recovered.values()] };
        this.status({ phase: "merging", message: `Recovered ${count} observed paths across this device's prior uploads; unrecorded differences retain normal lossless reconciliation`, level: "info" });
      }
    }
    let onboardingReconcile = false;
    if (settings.initialized && requestedBaseId && !baseSnapshot && local.size) {
      throw new SyncSafetyError("Stale-device protection paused sync because this device's last verified server snapshot is unavailable. No files were uploaded or deleted. Reconnect this device to establish a safe baseline.");
    }
    if (!settings.initialized && remoteSnapshot && settings.onboardingMode === "server-first") {
      const accepted = this.map(remoteSnapshot), desktopOnly = /* @__PURE__ */ new Set(), cache = this.bodyCache();
      if (this.isMobileDevice && settings.syncPlugins) for (const [path, entry] of accepted) {
        const plugin = this.pluginPath(path);
        if ((plugin == null ? void 0 : plugin.relative.toLowerCase()) !== "manifest.json") continue;
        try {
          if (JSON.parse(decoder6.decode(await this.remoteBytes(entry, cache))).isDesktopOnly === true) desktopOnly.add(plugin.id);
        } catch (e) {
        }
      }
      this.status({ phase: "applying", message: "Downloading the accepted server vault; existing local differences are retained in local recovery" });
      const applied2 = await this.stageAndApply(remoteSnapshot.id, accepted, this.snapshotFolders(remoteSnapshot), local, desktopOnly, scanned, [], this.bodyCache(), cache, remoteSnapshot.folderRepair, remoteSnapshot.createdAt);
      this.checkpoint();
      await this.api.markDeviceReady(remoteSnapshot.id);
      this.checkpoint();
      settings.fullScanRequired = false;
      settings.lastFullScanAt = (/* @__PURE__ */ new Date()).toISOString();
      await this.saveSettings();
      return { uploaded: 0, downloaded: applied2.downloaded, deleted: applied2.deleted, prunedFolders: prunedFolders + applied2.prunedFolders, pendingRetiredFolders: settings.retiredFolderCount, conflicts: 0, resolved: 0, mirrored: 0, snapshotId: remoteSnapshot.id, processedPaths: pendingPaths, fullScan: true };
    }
    if (remoteSnapshot && !baseSnapshot && local.size) {
      const remoteHashes2 = new Map(remoteSnapshot.entries.filter((entry) => this.include(entry.path)).map((entry) => [entry.path, entry.hash]));
      const unexpected = [...local.values()].filter((entry) => remoteHashes2.get(entry.path) !== entry.hash);
      if (unexpected.length) {
        const exactMatches = [...local.values()].filter((entry) => remoteHashes2.get(entry.path) === entry.hash).length;
        const comparedSize = Math.max(local.size, remoteHashes2.size), overlap = comparedSize ? exactMatches / comparedSize : 0;
        const localUserFiles = [...local.values()].filter((entry) => !this.systemPath(entry.path)), exactUserMatches = localUserFiles.filter((entry) => remoteHashes2.get(entry.path) === entry.hash).length;
        const localAgreement = localUserFiles.length ? exactUserMatches / localUserFiles.length : 1, interruptedDownload = localUserFiles.length === 0 || exactUserMatches > 0 && localAgreement >= 0.8;
        onboardingReconcile = true;
        this.status({ phase: "merging", message: overlap >= 0.9 ? `Matching vault recognized \xB7 ${exactMatches}/${comparedSize} files agree; preserving every difference` : interruptedDownload ? `Interrupted onboarding recognized \xB7 ${exactUserMatches}/${localUserFiles.length} local user files already match; preserving local-only files` : `Connecting populated vaults \xB7 ${exactMatches}/${comparedSize} files agree; both independent versions will be preserved without inferring deletions`, level: "success" });
      }
    }
    if (Object.keys(settings.localReconcileBases).length && effectiveBaseSnapshot) {
      const replay = this.map(effectiveBaseSnapshot);
      for (const [path, entry] of Object.entries(settings.localReconcileBases)) if (this.include(path)) {
        if (entry) replay.set(path, entry);
        else replay.delete(path);
      }
      effectiveBaseSnapshot = { ...effectiveBaseSnapshot, entries: [...replay.values()] };
      this.status({ phase: "merging", message: `Replaying ${Object.keys(settings.localReconcileBases).length} edits made during a download against their actual prior content`, level: "info" });
    }
    if (effectiveBaseSnapshot && Object.values(settings.packageHolds).some((hold) => hold.priorEntries)) {
      const replay = new Map(effectiveBaseSnapshot.entries.map((entry) => [entry.path, { ...entry }]));
      for (const [id, hold] of Object.entries(settings.packageHolds)) {
        for (const path of replay.keys()) if (((_d = this.pluginPath(path)) == null ? void 0 : _d.id) === id) replay.delete(path);
        for (const [path, entry] of Object.entries((_e = hold.priorEntries) != null ? _e : {})) replay.set(path, { ...entry });
      }
      effectiveBaseSnapshot = { ...effectiveBaseSnapshot, entries: [...replay.values()] };
    }
    const base = operationTree ? new Map(((_f = effectiveBaseSnapshot == null ? void 0 : effectiveBaseSnapshot.entries) != null ? _f : []).map((entry) => [entry.path, { ...entry }])) : this.map(effectiveBaseSnapshot), remote = operationTree ? new Map(((_g = remoteSnapshot == null ? void 0 : remoteSnapshot.entries) != null ? _g : []).map((entry) => [entry.path, { ...entry }])) : this.map(remoteSnapshot);
    for (const path of scanned.unreadableConflictPaths) {
      const accepted = (_h = base.get(path)) != null ? _h : remote.get(path);
      if (accepted) local.set(path, accepted);
    }
    const physicalLocal = new Map(local), bootstrapPluginSync = settings.syncPlugins && settings.pluginSyncBootstrapPending, acceptedPluginState = Boolean(bootstrapPluginSync && remoteSnapshot && [...remote.keys()].some((path) => this.pluginSyncPath(path)));
    let folderPlan = null;
    if (operationTree) {
      const basePaths = this.snapshotFolders(effectiveBaseSnapshot), baseFolders2 = (((_i = effectiveBaseSnapshot == null ? void 0 : effectiveBaseSnapshot.folderEntries) == null ? void 0 : _i.length) ? effectiveBaseSnapshot.folderEntries : (effectiveBaseSnapshot == null ? void 0 : effectiveBaseSnapshot.id) === operationTree.snapshotId ? operationTree.folders.filter((folder) => basePaths.has(folder.path)) : []).filter((folder) => this.managedTopLevelFolder(folder.path)), remoteFolders2 = operationTree.folders.filter((folder) => this.managedTopLevelFolder(folder.path)), localFolderPaths = /* @__PURE__ */ new Set([...scanned.folders, ...this.acceptedFolders(local.keys())]), localFolders = observeLocalFolders(baseFolders2, remoteFolders2, localFolderPaths, observedIntents, settings.deviceId, settings.deviceName);
      try {
        folderPlan = reconcileAndAlignFolders(baseFolders2, localFolders, remoteFolders2, base, local, remote);
      } catch (error) {
        throw new SyncSafetyError(error instanceof Error ? error.message : "Folder identities could not be reconciled safely");
      }
      if (folderPlan.conflicts.length) this.status({ phase: "merging", message: `Resolved ${folderPlan.conflicts.length} overlapping folder changes by stable identity; edits follow the chosen location`, level: "info" });
    }
    const remoteAlignedAll = operationTree ? new Map(remote) : new Map(((_j = remoteSnapshot == null ? void 0 : remoteSnapshot.entries) != null ? _j : []).map((entry) => [entry.path, { ...entry }]));
    for (const map of [base, remote]) for (const path of map.keys()) if (!this.include(path)) map.delete(path);
    if (operationTree && (rollout == null ? void 0 : rollout.mode) === "shadow" && typeof this.api.observeReconciliation === "function") {
      const shadowBase = baseSnapshot ? await this.api.snapshot(baseSnapshot.id) : null, shadowRemote = remoteSnapshot ? await this.api.snapshot(remoteSnapshot.id) : null, preserved = ((_k = shadowRemote == null ? void 0 : shadowRemote.entries) != null ? _k : []).filter((entry) => !this.include(entry.path));
      const baseIds = new Map(((_l = shadowBase == null ? void 0 : shadowBase.entries) != null ? _l : []).map((entry) => [entry.path, entry.fileId]));
      try {
        await this.api.observeReconciliation({ base: (_m = shadowBase == null ? void 0 : shadowBase.entries) != null ? _m : [], local: [...physicalLocal.values(), ...preserved].map((entry) => this.manifestEntry(entry)), remote: (_n = shadowRemote == null ? void 0 : shadowRemote.entries) != null ? _n : [], localCreationIntents: [...latestFileIntent.values()].filter((event) => event.kind === "create" && event.targetId).map((event) => {
          var _a2;
          return { operationId: event.id, targetId: event.targetId, path: event.path, baseTargetId: (_a2 = baseIds.get(event.path)) != null ? _a2 : null };
        }) }, (_o = shadowBase == null ? void 0 : shadowBase.id) != null ? _o : null);
      } catch (error) {
        if (error instanceof ApiError && error.status === 409) return this.convergeAfterConflict(attempt, "The accepted tree advanced during reconciliation validation");
        if (!(error instanceof ApiError && error.status === 404)) throw error;
      }
    }
    if (acceptedPluginState) {
      for (const path of new Set([...local.keys(), ...remote.keys()].filter((candidate) => this.pluginSyncPath(candidate)))) {
        const accepted = remote.get(path);
        if (accepted) local.set(path, accepted);
        else local.delete(path);
      }
      this.status({ phase: "merging", message: "Plugin sync first activation \xB7 adopting the accepted server plugin inventory and settings before publishing device changes", level: "success" });
    } else if (bootstrapPluginSync) this.status({ phase: "merging", message: "Plugin sync first activation \xB7 no accepted plugin inventory exists, so this device will establish it", level: "info" });
    const orphanUnreadableConflicts = [...scanned.unreadableConflictPaths].filter((path) => !base.has(path) && !remote.has(path));
    let suppressedRetired = 0, retiredStateChanged = false;
    if (operationTree) {
      const newest = /* @__PURE__ */ new Map();
      for (const tombstone of operationTree.tombstones) {
        const old = newest.get(tombstone.path);
        if (!old || tombstone.deletedSequence > old.deletedSequence || tombstone.deletedSequence === old.deletedSequence && ((_p = tombstone.deletedOrdinal) != null ? _p : 0) > ((_q = old.deletedOrdinal) != null ? _q : 0)) newest.set(tombstone.path, tombstone);
      }
      for (const [path, tombstone] of newest) {
        const current = local.get(path);
        if (!current || remote.has(path) || tombstone.entityKind !== "file" || !tombstone.content) continue;
        const created = ((_r = latestFileIntent.get(path)) == null ? void 0 : _r.kind) === "create";
        if (current.hash === tombstone.content.hash && !created) {
          settings.retiredPaths[path] = { hash: current.hash, snapshotId: (_s = remoteSnapshot == null ? void 0 : remoteSnapshot.id) != null ? _s : "accepted", retiredAt: tombstone.revision.modifiedAt };
          local.delete(path);
          suppressedRetired++;
          retiredStateChanged = true;
        }
      }
    }
    for (const [path, retired] of Object.entries(settings.retiredPaths)) {
      const current = local.get(path);
      if (remote.has(path)) {
        delete settings.retiredPaths[path];
        retiredStateChanged = true;
        continue;
      }
      if ((current == null ? void 0 : current.hash) === retired.hash) {
        if (((_t = latestFileIntent.get(path)) == null ? void 0 : _t.kind) === "create") {
          delete settings.retiredPaths[path];
          retiredStateChanged = true;
          continue;
        }
        const observed = (_u = settings.fileCreationTimes[path]) != null ? _u : 0;
        let recreated = false;
        if (observed > retired.retiredAt) {
          const stat = await this.adapter.stat((_v = current.sourcePath) != null ? _v : path);
          recreated = Boolean((stat == null ? void 0 : stat.type) === "file" && Math.max(stat.ctime, stat.mtime) > retired.retiredAt);
        }
        if (recreated) {
          delete settings.retiredPaths[path];
          retiredStateChanged = true;
          continue;
        }
        local.delete(path);
        suppressedRetired++;
        continue;
      }
      if (current) {
        delete settings.retiredPaths[path];
        retiredStateChanged = true;
      }
    }
    this.trimRetiredPaths();
    if (retiredStateChanged) await this.saveSettings();
    if (suppressedRetired) this.status({ phase: "merging", message: `Removed ${suppressedRetired} stale retired path${suppressedRetired === 1 ? "" : "s"} that reappeared after an earlier accepted move or deletion`, level: "success" });
    const recognizedMoves = this.canonicalizeMoves(base, local, remote, effectiveBaseSnapshot, remoteSnapshot), final = /* @__PURE__ */ new Map();
    const bytes2 = this.bodyCache();
    const remoteCache = this.bodyCache();
    const paths = /* @__PURE__ */ new Set([...base.keys(), ...local.keys(), ...remote.keys()]);
    const occupied = new Set(paths);
    let conflicts = 0, resolved = 0;
    this.status({ phase: "merging", message: `Comparing ${paths.size} paths \xB7 ${local.size} local \xB7 ${remote.size} remote \xB7 ${base.size} baseline` });
    const namespaceCollisionPaths = /* @__PURE__ */ new Set();
    for (const collision of (_w = folderPlan == null ? void 0 : folderPlan.fileCollisions) != null ? _w : []) {
      await this.preserveNamespaceCollision(collision, final, bytes2, remoteCache, occupied);
      namespaceCollisionPaths.add(collision.path);
      conflicts++;
    }
    if (recognizedMoves) this.status({ phase: "merging", message: `Recognized ${recognizedMoves} file move${recognizedMoves === 1 ? "" : "s"} by content identity; edits will follow the destination`, level: "success" });
    const handledPluginPaths = /* @__PURE__ */ new Set(), desktopOnlyPlugins = /* @__PURE__ */ new Set();
    if (settings.syncPlugins) {
      const pluginIds = new Set([...paths].map((path) => {
        var _a2;
        return (_a2 = this.pluginPath(path)) == null ? void 0 : _a2.id;
      }).filter((id) => Boolean(id)));
      const packageFor = (source, id) => new Map([...source].filter(([path]) => {
        const plugin = this.pluginPath(path);
        return (plugin == null ? void 0 : plugin.id) === id && !this.pluginDataPath(path);
      }));
      const versionFor = async (source, entries2, id) => {
        const entry = entries2.get(this.pluginFile(id, "manifest.json"));
        if (!entry || entry.size > 64 * 1024) return null;
        try {
          const clear = source === "local" && !acceptedPluginState ? await this.localBytes(entry.path, entry, bytes2) : await this.remoteBytes(entry, remoteCache), manifest = JSON.parse(decoder6.decode(clear));
          return manifest.id === id && typeof manifest.version === "string" && (manifest.isDesktopOnly === void 0 || typeof manifest.isDesktopOnly === "boolean") ? manifest.version : null;
        } catch (e) {
          return null;
        }
      };
      for (const id of [...pluginIds].sort()) {
        await this.cooperate();
        const baseline = packageFor(base, id), localPackage = packageFor(local, id), remotePackage = packageFor(remote, id);
        for (const path of /* @__PURE__ */ new Set([...baseline.keys(), ...localPackage.keys(), ...remotePackage.keys()])) handledPluginPaths.add(path);
        const localChanged = !this.packageSame(localPackage, baseline), remoteChanged = !this.packageSame(remotePackage, baseline);
        const localVersion = await versionFor("local", localPackage, id), remoteVersion = await versionFor("remote", remotePackage, id);
        const baseVersion = await versionFor("remote", baseline, id), complete = (entries2, version) => Boolean(version) && entries2.has(this.pluginFile(id, "manifest.json")) && entries2.has(this.pluginFile(id, "main.js")), choice = selectPluginPackage({ entries: [...baseline.values()], version: baseVersion, complete: complete(baseline, baseVersion) }, { entries: [...localPackage.values()].map((entry) => {
          var _a2;
          return { ...entry, mtime: this.localChangeTime(entry.path, entry, effectiveBaseSnapshot), ...((_a2 = baseline.get(entry.path)) == null ? void 0 : _a2.hash) !== entry.hash ? { revision: void 0 } : {} };
        }), version: localVersion, complete: complete(localPackage, localVersion) }, { entries: [...remotePackage.values()], version: remoteVersion, complete: complete(remotePackage, remoteVersion) }), chosen = new Map(choice.entries.map((entry) => [entry.path, { ...entry }])), side = choice.side, reason = choice.reason;
        if (choice.side === "held" && [...baseline.keys(), ...localPackage.keys(), ...remotePackage.keys()].some((path) => ["manifest.json", "main.js"].includes(this.pluginPath(path).relative))) {
          await this.holdPackage(id, reason, "incomplete", [...remote.values()].filter((entry) => {
            var _a2;
            return ((_a2 = this.pluginPath(entry.path)) == null ? void 0 : _a2.id) === id;
          }), [...physicalLocal.values()].filter((entry) => {
            var _a2;
            return ((_a2 = this.pluginPath(entry.path)) == null ? void 0 : _a2.id) === id;
          }));
          chosen.clear();
          for (const [path, entry] of remote) if (((_x = this.pluginPath(path)) == null ? void 0 : _x.id) === id) chosen.set(path, entry);
          for (const path of paths) if (((_y = this.pluginPath(path)) == null ? void 0 : _y.id) === id) handledPluginPaths.add(path);
          this.status({ phase: "merging", message: `Plugin ${id} needs a complete valid package; its files and settings were held while other vault files continue syncing`, level: "warning" });
        }
        if (choice.side !== "held" && ((_z = settings.packageHolds[id]) == null ? void 0 : _z.kind) === "incomplete") delete settings.packageHolds[id];
        if (choice.resolved) resolved++;
        for (const [path, entry] of chosen) final.set(path, entry);
        if (localChanged || remoteChanged) this.status({ phase: "merging", message: `Plugin package \xB7 ${id} \xB7 chose ${side}${(side === "local" ? localVersion : remoteVersion) ? ` v${side === "local" ? localVersion : remoteVersion}` : ""} \xB7 ${reason}`, level: "info" });
      }
      for (const id of pluginIds) {
        const path = this.pluginFile(id, "manifest.json"), entry = final.get(path);
        if (!entry) continue;
        try {
          const localEntry = local.get(path), clear = (_A = bytes2.get(entry.hash)) != null ? _A : (localEntry == null ? void 0 : localEntry.hash) === entry.hash ? await this.localBytes(path, localEntry, bytes2) : await this.remoteBytes(entry, remoteCache);
          if (JSON.parse(decoder6.decode(clear)).isDesktopOnly === true) desktopOnlyPlugins.add(id);
        } catch (e) {
        }
      }
    }
    const reconciliation = await planReconciliationCooperative({ base: [...base.values()], local: [...local.values()], remote: [...remote.values()] }, () => this.cooperate(true));
    for (const decision of reconciliation.decisions) {
      const path = decision.path;
      await this.cooperate();
      if (namespaceCollisionPaths.has(path)) continue;
      if (handledPluginPaths.has(path)) continue;
      const b = base.get(path), l = local.get(path), r = remote.get(path);
      if (decision.kind === "equal" || decision.kind === "unchanged") {
        if (r) final.set(path, { ...l, ...r });
        continue;
      }
      if (settings.syncPlugins && path === this.enablementPath && b && l && r) {
        const baseText = decoder6.decode(await this.remoteBytes(b, remoteCache)), localText = decoder6.decode(await this.localBytes(path, l, bytes2)), remoteText = decoder6.decode(await this.remoteBytes(r, remoteCache)), preferred = this.preferredSide(path, l, effectiveBaseSnapshot, remoteSnapshot, r);
        const merged = mergeCommunityPluginEnablement(baseText, localText, remoteText, preferred, desktopOnlyPlugins, this.isMobileDevice), clear = encoder7.encode(merged.text);
        await this.prepareResult(path, clear, final, bytes2);
        resolved++;
        this.status({ phase: "merging", message: `Plugin enablement \xB7 ${merged.reason}`, level: "success" });
        continue;
      }
      if (decision.kind === "remote-only") {
        if (r) final.set(path, r);
        continue;
      }
      if (decision.kind === "local-only") {
        if (l) final.set(path, l);
        continue;
      }
      if (!l && !r) continue;
      if (decision.strategy !== "text" || this.systemPath(path)) {
        if (b && (!l || !r)) {
          const kept = l != null ? l : r;
          if (kept) final.set(path, kept);
          resolved++;
          this.status({ phase: "merging", message: `Obsidian system file \xB7 ${path} \xB7 kept the modified version instead of an overlapping deletion`, level: "warning" });
          continue;
        }
        if (l && r) {
          const preferred = this.preferredSide(path, l, effectiveBaseSnapshot, remoteSnapshot, r);
          if (Math.max((_B = b == null ? void 0 : b.size) != null ? _B : 0, l.size, r.size) > MAX_SETTINGS_JSON_BYTES) {
            final.set(path, preferred === "local" ? l : r);
            resolved++;
            this.status({ phase: "merging", message: `Large Obsidian settings file \xB7 ${path} \xB7 used the newer complete ${preferred} version without parsing it; prior copies remain recoverable`, level: "warning" });
            await this.recordSystemConflict(path, l, r, preferred, final, (_C = remoteSnapshot == null ? void 0 : remoteSnapshot.deviceName) != null ? _C : "Remote device", "Large settings overlap was resolved with one complete version");
            continue;
          }
          if (decision.strategy === "json-settings" || path.toLowerCase().endsWith(".json")) {
            const baseText = b ? decoder6.decode(await this.remoteBytes(b, remoteCache)) : "{}", localText = decoder6.decode(await this.localBytes(path, l, bytes2)), remoteText = decoder6.decode(await this.remoteBytes(r, remoteCache));
            const merged = path === this.enablementPath ? mergeCommunityPluginEnablement(baseText, localText, remoteText, preferred, desktopOnlyPlugins, this.isMobileDevice) : mergeSystemJson(baseText, localText, remoteText, preferred, this.configPath(path) === ".obsidian/bookmarks.json" ? "bookmarks" : void 0), clear = encoder7.encode(merged.text);
            await this.prepareResult(path, clear, final, bytes2);
            if (merged.overlaps) await this.recordSystemConflict(path, l, r, preferred, final, (_D = remoteSnapshot == null ? void 0 : remoteSnapshot.deviceName) != null ? _D : "Remote device", "Overlapping settings were merged; both originals are recoverable");
            this.status({ phase: "merging", message: `Obsidian settings \xB7 ${path} \xB7 ${merged.reason}`, level: merged.overlaps ? "warning" : "success" });
          } else {
            const chosen = preferred === "local" ? l : r;
            final.set(path, chosen);
            this.status({ phase: "merging", message: `Obsidian system file \xB7 ${path} \xB7 used newer ${preferred} whole file`, level: "info" });
            await this.recordSystemConflict(path, l, r, preferred, final, (_E = remoteSnapshot == null ? void 0 : remoteSnapshot.deviceName) != null ? _E : "Remote device", "Whole settings overlap was resolved; both originals are recoverable");
          }
          resolved++;
          continue;
        }
      }
      if (b && (!l || !r)) {
        conflicts++;
        const survivor = l != null ? l : r;
        if (survivor && survivor.size >= LOW_MEMORY_DOWNLOAD_BYTES) {
          const editor = l ? settings.deviceName : (_H = (_G = (_F = r.revision) == null ? void 0 : _F.deviceName) != null ? _G : remoteSnapshot == null ? void 0 : remoteSnapshot.deviceName) != null ? _H : "Remote device", deleter = l ? (_I = remoteSnapshot == null ? void 0 : remoteSnapshot.deviceName) != null ? _I : "Remote device" : settings.deviceName;
          await this.prepareStreamedVersion(path, survivor, l ? "local" : "remote", path.toLowerCase().endsWith(".md") ? this.deletionWarning("", editor, deleter) : "", final);
        } else if (l) await this.preserveDeletion(path, await this.localBytes(path, l, bytes2), settings.deviceName, (_J = remoteSnapshot == null ? void 0 : remoteSnapshot.deviceName) != null ? _J : "Remote device", final, bytes2);
        else if (r) await this.preserveDeletion(path, await this.remoteBytes(r, remoteCache), (_M = (_L = (_K = r.revision) == null ? void 0 : _K.deviceName) != null ? _L : remoteSnapshot == null ? void 0 : remoteSnapshot.deviceName) != null ? _M : "Remote device", settings.deviceName, final, bytes2);
        if (survivor) await this.recordDeletionConflict(path, survivor, Boolean(l), (_P = (_O = (_N = r == null ? void 0 : r.revision) == null ? void 0 : _N.deviceName) != null ? _O : remoteSnapshot == null ? void 0 : remoteSnapshot.deviceName) != null ? _P : "Remote device", final);
        continue;
      }
      if (decision.strategy === "text" && b && l && r && r.fileId && (!b.fileId || !l.fileId)) {
        conflicts++;
        const preferred = this.preferredSide(path, l, effectiveBaseSnapshot, remoteSnapshot, r);
        if (Math.max(l.size, r.size) >= LOW_MEMORY_DOWNLOAD_BYTES) await this.preserveLargePair(path, l, r, settings.deviceName, (_S = (_R = (_Q = r.revision) == null ? void 0 : _Q.deviceName) != null ? _R : remoteSnapshot == null ? void 0 : remoteSnapshot.deviceName) != null ? _S : "Remote device", preferred, final, occupied);
        else await this.preservePair(path, l, await this.localBytes(path, l, bytes2), r, settings.deviceName, (_V = (_U = (_T = r.revision) == null ? void 0 : _T.deviceName) != null ? _U : remoteSnapshot == null ? void 0 : remoteSnapshot.deviceName) != null ? _V : "Remote device", preferred, final, bytes2, remoteCache, occupied);
        this.status({ phase: "merging", message: `Preserved both \xB7 ${path} \xB7 this older baseline cannot prove both versions belong to the same file generation`, level: "info" });
        continue;
      }
      if (l && r && Math.max((_W = b == null ? void 0 : b.size) != null ? _W : 0, l.size, r.size) >= LOW_MEMORY_DOWNLOAD_BYTES) {
        conflicts++;
        await this.preserveLargePair(path, l, r, settings.deviceName, (_Z = (_Y = (_X = r.revision) == null ? void 0 : _X.deviceName) != null ? _Y : remoteSnapshot == null ? void 0 : remoteSnapshot.deviceName) != null ? _Z : "Remote device", this.preferredSide(path, l, effectiveBaseSnapshot, remoteSnapshot, r), final, occupied);
        this.status({ phase: "merging", message: `Large concurrent versions \xB7 ${path} \xB7 both complete files preserved without loading them into memory`, level: "warning" });
        continue;
      }
      if (l && r && this.text(path)) {
        if (!b || decision.kind === "independent-create") {
          const preferred2 = this.preferredSide(path, l, effectiveBaseSnapshot, remoteSnapshot, r);
          conflicts++;
          await this.preservePair(path, l, await this.localBytes(path, l, bytes2), r, settings.deviceName, (_aa = (_$ = (__ = r.revision) == null ? void 0 : __.deviceName) != null ? _$ : remoteSnapshot == null ? void 0 : remoteSnapshot.deviceName) != null ? _aa : "Remote device", preferred2, final, bytes2, remoteCache, occupied);
          continue;
        }
        const baseText = b ? decoder6.decode(await this.remoteBytes(b, remoteCache)) : "";
        const localText = decoder6.decode(await this.localBytes(path, l, bytes2));
        const remoteText = decoder6.decode(await this.remoteBytes(r, remoteCache));
        const preferred = this.preferredSide(path, l, effectiveBaseSnapshot, remoteSnapshot, r);
        this.status({ phase: "merging", message: `Three-way merge \xB7 ${path} \xB7 base ${(_ba = b == null ? void 0 : b.size) != null ? _ba : 0} B \xB7 local ${l.size} B \xB7 remote ${r.size} B` });
        await this.cooperate(true);
        const merged = mergeText(baseText, localText, remoteText, preferred);
        await this.cooperate(true);
        if (merged.kind === "large-conflict" || merged.kind === "merge-fallback") {
          const reason = merged.kind === "merge-fallback" ? (_ca = merged.reason) != null ? _ca : "merge engine fallback" : `${merged.overlapWords} overlapping words across ${merged.overlapLines} lines`;
          console.warn("Gib Sync preserved both versions after merge fallback", { path, reason, baseBytes: (_da = b == null ? void 0 : b.size) != null ? _da : 0, localBytes: l.size, remoteBytes: r.size });
          this.status({ phase: "merging", message: `Preserving both \xB7 ${path} \xB7 ${reason}`, level: "warning" });
          conflicts++;
          await this.preservePair(path, l, await this.localBytes(path, l, bytes2), r, settings.deviceName, (_ga = (_fa = (_ea = r.revision) == null ? void 0 : _ea.deviceName) != null ? _fa : remoteSnapshot == null ? void 0 : remoteSnapshot.deviceName) != null ? _ga : "Remote device", preferred, final, bytes2, remoteCache, occupied);
          continue;
        }
        this.status({ phase: "merging", message: merged.kind === "small-overlap" ? `Resolved small overlap \xB7 ${path} \xB7 preferred ${preferred} version` : `Merged non-overlapping edits \xB7 ${path}`, level: "success" });
        const mergedBytes = encoder7.encode(merged.text);
        await this.prepareResult(path, mergedBytes, final, bytes2);
        continue;
      }
      conflicts++;
      if (l && r) await this.preservePair(path, l, await this.localBytes(path, l, bytes2), r, settings.deviceName, (_ja = (_ia = (_ha = r.revision) == null ? void 0 : _ha.deviceName) != null ? _ia : remoteSnapshot == null ? void 0 : remoteSnapshot.deviceName) != null ? _ja : "Remote device", this.preferredSide(path, l, effectiveBaseSnapshot, remoteSnapshot, r), final, bytes2, remoteCache, occupied);
    }
    if (settings.syncPlugins) {
      const enablementPath = this.enablementPath, entry = final.get(enablementPath);
      if (entry) {
        try {
          const localEntry = local.get(enablementPath), clear = (_ka = bytes2.get(entry.hash)) != null ? _ka : (localEntry == null ? void 0 : localEntry.hash) === entry.hash ? await this.localBytes(enablementPath, localEntry, bytes2) : await this.remoteBytes(entry, remoteCache);
          const enabled = JSON.parse(decoder6.decode(clear));
          if (Array.isArray(enabled)) {
            const valid = enabled.filter((id) => typeof id === "string" && (id === "gib-sync" || final.has(this.pluginFile(id, "manifest.json")) && final.has(this.pluginFile(id, "main.js"))));
            const missing2 = enabled.filter((id) => typeof id === "string" && !valid.includes(id));
            if (missing2.length) {
              const sanitized = encoder7.encode(`${JSON.stringify(valid, null, 2)}
`);
              await this.prepareResult(enablementPath, sanitized, final, bytes2);
              resolved++;
              this.status({ phase: "merging", message: `Plugin enablement repaired \xB7 skipped ${missing2.length} incomplete package${missing2.length === 1 ? "" : "s"}: ${missing2.slice(0, 5).join(", ")}${missing2.length > 5 ? "\u2026" : ""}`, level: "warning" });
            }
          }
        } catch (e) {
          this.status({ phase: "merging", message: "Plugin enablement list is non-standard JSON \xB7 kept the newer complete file", level: "warning" });
        }
      }
    }
    const preservedIgnored = [...remoteAlignedAll.values()].filter((entry) => !this.include(entry.path) && !isDeviceLocalObsidianPath(entry.path, this.logicalConfigDir));
    const entries = [...final.values(), ...preservedIgnored].map((entry) => this.manifestEntry(entry)).sort((a, b) => a.path.localeCompare(b.path));
    const remoteEntries = [...(_la = remoteSnapshot == null ? void 0 : remoteSnapshot.entries) != null ? _la : []].map(({ path, hash, size, mtime }) => ({ path, hash, size, mtime })).sort((a, b) => a.path.localeCompare(b.path));
    const baseFolders = this.manifestFolders(effectiveBaseSnapshot), remoteFolders = this.manifestFolders(remoteSnapshot), implicitFolders = this.acceptedFolders(entries.map((entry) => entry.path)), mergedFolders = folderPlan ? new Set(folderPlan.folders.map((folder) => folder.path).filter((path) => !implicitFolders.has(path))) : this.mergeFolders(baseFolders, scanned.folders, remoteFolders);
    if (remoteSnapshot == null ? void 0 : remoteSnapshot.folderRepair) {
      for (const raw of remoteSnapshot.folderRepair.retiredFolders) {
        const path = (0, import_obsidian2.normalizePath)(raw);
        if (!await this.hasProtectedFolderIntent(path, remoteSnapshot.folderRepair, remoteSnapshot.createdAt)) mergedFolders.delete(path);
      }
    }
    for (const folder of (_ma = remoteSnapshot == null ? void 0 : remoteSnapshot.folders) != null ? _ma : []) if (!this.include(folder) && !isDeviceLocalObsidianPath(folder, settings.configDir)) mergedFolders.add((0, import_obsidian2.normalizePath)(folder));
    const folders = [...mergedFolders].sort(), acceptedRemoteFolders = this.manifestFolders(remoteSnapshot);
    for (const folder of (_na = remoteSnapshot == null ? void 0 : remoteSnapshot.folders) != null ? _na : []) if (!this.include(folder) && !isDeviceLocalObsidianPath(folder, settings.configDir)) acceptedRemoteFolders.add((0, import_obsidian2.normalizePath)(folder));
    const remoteFolderList = [...acceptedRemoteFolders].sort();
    const clientCanMirrorAll = !preservedIgnored.length;
    const remoteHashes = new Set(remoteEntries.map((entry) => entry.hash)), remotePathHashes = new Map(remoteEntries.map((entry) => [entry.path, entry.hash])), entryPaths = new Set(entries.map((entry) => entry.path));
    const remoteIds = new Map(((_oa = remoteSnapshot == null ? void 0 : remoteSnapshot.entries) != null ? _oa : []).map((entry) => [entry.path, entry.fileId])), remoteFolderIds = new Map(((_pa = operationTree == null ? void 0 : operationTree.folders) != null ? _pa : []).map((entry) => [entry.path, entry.folderId])), identityIntent = entries.some((entry) => entry.fileId && remoteIds.get(entry.path) && entry.fileId !== remoteIds.get(entry.path)) || observedIntents.some((event) => event.entity === "folder" && event.kind === "create" && remoteFolderIds.has(event.path) && remoteFolderIds.get(event.path) !== event.targetId);
    const unchanged = !identityIntent && entries.length === remoteEntries.length && entries.every((entry, i) => entry.path === remoteEntries[i].path && entry.hash === remoteEntries[i].hash) && folders.length === remoteFolderList.length && folders.every((folder, index) => folder === remoteFolderList[index]);
    if (unchanged) {
      const topologyFolders2 = /* @__PURE__ */ new Set([...folders, ...this.acceptedFolders(entries.map((entry) => entry.path))]);
      let downloaded2 = 0, deleted2 = 0;
      if (remoteSnapshot) {
        const applied2 = await this.stageAndApply(remoteSnapshot.id, final, topologyFolders2, physicalLocal, desktopOnlyPlugins, scanned, orphanUnreadableConflicts, bytes2, remoteCache, remoteSnapshot.folderRepair, remoteSnapshot.createdAt);
        downloaded2 = applied2.downloaded;
        deleted2 = applied2.deleted;
        prunedFolders += applied2.prunedFolders;
      } else {
        const topology = await this.reconcileFolderTopology(topologyFolders2);
        prunedFolders += topology.removed;
        settings.lastSnapshotId = null;
        settings.initialized = true;
        if (settings.syncPlugins) settings.pluginSyncBootstrapPending = false;
        await this.saveSettings();
      }
      let mirrored2 = 0;
      try {
        mirrored2 = remoteSnapshot && clientCanMirrorAll ? await this.mirror(remoteSnapshot.id, entries, final, bytes2, remoteCache) : 0;
      } catch (error) {
        if (this.retryableMirrorError(error)) return this.convergeAfterConflict(attempt, "Another device advanced the vault during mirror verification");
        throw error;
      }
      this.status({ phase: "up-to-date", message: "Up to date \xB7 this device matches the accepted snapshot" });
      if (fullScan && !settings.retiredFolderCount) {
        settings.fullScanRequired = false;
        settings.lastFullScanAt = (/* @__PURE__ */ new Date()).toISOString();
        await this.saveSettings();
      }
      this.acknowledgeMoves(consumedMoves, entries);
      await this.saveSettings();
      await this.intents.acknowledge(observedIntents.reduce((maximum, event) => Math.max(maximum, event.sequence), 0));
      return { uploaded: 0, downloaded: downloaded2, deleted: deleted2, prunedFolders, pendingRetiredFolders: settings.retiredFolderCount, conflicts, resolved, mirrored: mirrored2, snapshotId: settings.lastSnapshotId, processedPaths: pendingPaths, fullScan, pendingPackages: Object.keys(settings.packageHolds) };
    }
    if (!settings.initialized && remoteSnapshot) {
      this.status({ phase: "committing", message: onboardingReconcile ? "Verifying the matched server baseline before publishing the union" : "Verifying the first download before cleaning device-local workspace state" });
      try {
        this.checkpoint();
        await this.api.markDeviceReady(remoteSnapshot.id);
        this.checkpoint();
      } catch (error) {
        if (error instanceof ApiError && error.status === 409) return this.convergeAfterConflict(attempt, "The server vault changed during onboarding verification");
        throw error;
      }
    }
    const applyPaths = /* @__PURE__ */ new Set([...entries.filter((entry) => {
      var _a2;
      return ((_a2 = physicalLocal.get(entry.path)) == null ? void 0 : _a2.hash) !== entry.hash;
    }).map((entry) => entry.path), ...[...physicalLocal.keys()].filter((path) => !entryPaths.has(path))]);
    const priorEntries = Object.fromEntries([...applyPaths].flatMap((path) => {
      const entry = physicalLocal.get(path);
      return entry ? [[path, this.manifestEntry(entry)]] : [];
    }));
    const proposalHashes = new Set(entries.map((entry) => entry.hash)), conflictOriginals = [];
    for (const item of await this.conflictStore.list()) if (!item.originSnapshotId) {
      for (const side of item.versions) if (side.hash !== null && side.sourcePath) conflictOriginals.push({ path: side.path, hash: side.hash, size: side.size, mtime: Date.now(), sourcePath: side.sourcePath });
    }
    const replayUploads = [...new Map([...Object.values(priorEntries), ...conflictOriginals].filter((entry) => !remoteHashes.has(entry.hash) && !proposalHashes.has(entry.hash)).map((entry) => [entry.hash, entry])).values()];
    const uploadTotal = entries.filter((entry) => !remoteHashes.has(entry.hash)).length + replayUploads.length;
    let preparedBatch = null;
    if (operationTree) {
      const batch = await buildOperationBatch(operationTree, entries, folders, observedIntents, conflicts ? `Sync with ${conflicts} preserved conflicts` : "Sync", () => crypto.randomUUID(), new Map((_qa = folderPlan == null ? void 0 : folderPlan.folders.map((folder) => [folder.path, folder.folderId])) != null ? _qa : []), new Set(operationTree.folders.filter((folder) => !this.managedTopLevelFolder(folder.path) || !this.include(folder.path)).map((folder) => folder.path)), () => this.cooperate(true));
      for (const entry of entries) {
        const existing = final.get(entry.path);
        if (existing) existing.fileId = entry.fileId;
      }
      const prepared = { batch, phase: "prepared", intentSequence: observedIntents.reduce((maximum, event) => Math.max(maximum, event.sequence), 0), priorHashes: Object.fromEntries([...applyPaths].map((path) => {
        var _a2, _b2;
        return [path, (_b2 = (_a2 = physicalLocal.get(path)) == null ? void 0 : _a2.hash) != null ? _b2 : null];
      })), priorEntries };
      if (usesOperations) preparedBatch = prepared;
      await this.operations.save(prepared);
      this.checkpoint();
    }
    this.status({ phase: uploadTotal ? "uploading" : "checking", message: uploadTotal ? "Uploading changed files" : "Verifying the planned snapshot", current: uploadTotal ? 0 : void 0, total: uploadTotal || void 0 });
    let uploaded = 0;
    for (const entry of entries) {
      await this.cooperate();
      if (remoteHashes.has(entry.hash)) continue;
      const localEntry = local.get(entry.path), prepared = final.get(entry.path), source = (prepared == null ? void 0 : prepared.sourcePath) ? prepared : (localEntry == null ? void 0 : localEntry.hash) === entry.hash ? localEntry : void 0;
      if (!source) throw new Error(`Unable to prepare changed file ${entry.path}`);
      await this.uploadLocalFile(source, bytes2);
      uploaded++;
      if (this.progress(uploaded, uploadTotal)) this.status({ phase: "uploading", message: `Uploaded ${uploaded} encrypted file${uploaded === 1 ? "" : "s"}`, current: uploaded, total: uploadTotal });
    }
    for (const entry of replayUploads) {
      await this.cooperate();
      await this.uploadLocalFile(entry, bytes2);
      uploaded++;
    }
    this.status({ phase: "committing", message: "Committing an atomic snapshot" });
    let snapshot;
    const highEntropyPaths = [];
    for (const entry of entries) {
      if (!this.text(entry.path) || remotePathHashes.get(entry.path) === entry.hash) continue;
      const clear = bytes2.get(entry.hash);
      if (clear && await this.entropy(clear) > 7.2) highEntropyPaths.push(entry.path);
    }
    const deviceLocalCleanupPaths = remoteEntries.filter((entry) => isDeviceLocalObsidianPath(entry.path, settings.configDir) && !entryPaths.has(entry.path)).slice(0, 5e3).map((entry) => entry.path);
    if (!preparedBatch) settings.pendingCommit = { parentId: (_ra = remoteSnapshot == null ? void 0 : remoteSnapshot.id) != null ? _ra : null, fingerprint: await commitFingerprint(entries, folders), priorHashes: Object.fromEntries([...applyPaths].map((path) => {
      var _a2, _b2;
      return [path, (_b2 = (_a2 = physicalLocal.get(path)) == null ? void 0 : _a2.hash) != null ? _b2 : null];
    })), priorEntries, intentSequence: observedIntents.reduce((maximum, event) => Math.max(maximum, event.sequence), 0) };
    await this.saveSettings();
    this.checkpoint();
    try {
      if (preparedBatch) {
        preparedBatch.phase = "submitted";
        await this.operations.save(preparedBatch);
        this.checkpoint();
        const receipt = await this.api.operationBatch(preparedBatch.batch);
        this.assertOwnedReceipt(receipt, preparedBatch.batch);
        if (receipt.batchId !== preparedBatch.batch.batchId) throw new SyncSafetyError("The accepted operation receipt has the wrong batch identity");
        preparedBatch = { ...preparedBatch, phase: "accepted", receipt };
        await this.operations.save(preparedBatch);
        snapshot = receipt.snapshot;
      } else snapshot = await this.api.commit({
        parentId: (_sa = remoteSnapshot == null ? void 0 : remoteSnapshot.id) != null ? _sa : null,
        message: conflicts ? `Sync with ${conflicts} preserved conflict${conflicts === 1 ? "" : "s"}` : "Sync",
        entries,
        folders,
        ...folderPlan ? { folderEntries: folderPlan.folders } : {},
        clientTime: (/* @__PURE__ */ new Date()).toISOString(),
        signals: { highEntropyPaths, deviceLocalCleanupPaths, vaultIdentity: settings.vaultIdentity, staleBaseline: Boolean(baseSnapshot && remoteSnapshot && baseSnapshot.id !== remoteSnapshot.id) }
      });
    } catch (error) {
      if (error instanceof ApiError && error.status >= 400 && error.status < 500 && error.status !== 408 && error.status !== 423) {
        if (preparedBatch) await this.operations.clear();
        settings.pendingCommit = null;
        await this.saveSettings();
      }
      if (error instanceof ApiError && error.status === 409) return this.convergeAfterConflict(attempt, "Another device committed at the same time");
      throw error;
    }
    this.checkpoint();
    await this.publishPendingConflicts(snapshot);
    this.checkpoint();
    const topologyFolders = /* @__PURE__ */ new Set([...folders, ...this.acceptedFolders(entries.map((entry) => entry.path))]), applied = await this.stageAndApply(snapshot.id, final, topologyFolders, physicalLocal, desktopOnlyPlugins, scanned, orphanUnreadableConflicts, bytes2, remoteCache, snapshot.folderRepair, snapshot.createdAt), downloaded = applied.downloaded, deleted = applied.deleted;
    prunedFolders += applied.prunedFolders;
    let mirrored;
    try {
      mirrored = clientCanMirrorAll ? await this.mirror(snapshot.id, entries, final, bytes2, remoteCache) : 0;
    } catch (error) {
      if (this.retryableMirrorError(error)) return this.convergeAfterConflict(attempt, "The commit succeeded and another device advanced the vault during mirroring");
      throw error;
    }
    this.status({ phase: "complete", message: conflicts ? `Synced \xB7 ${conflicts} conflict${conflicts === 1 ? "" : "s"} preserved` : "Sync complete \xB7 this device matches the accepted snapshot" });
    if (fullScan && !settings.retiredFolderCount) {
      settings.fullScanRequired = false;
      settings.lastFullScanAt = (/* @__PURE__ */ new Date()).toISOString();
      await this.saveSettings();
    }
    this.acknowledgeMoves(consumedMoves, entries);
    await this.saveSettings();
    await this.intents.acknowledge((_ta = preparedBatch == null ? void 0 : preparedBatch.intentSequence) != null ? _ta : observedIntents.reduce((maximum, event) => Math.max(maximum, event.sequence), 0));
    if (operationTree) await this.operations.clear();
    return { uploaded, downloaded, deleted, prunedFolders, pendingRetiredFolders: settings.retiredFolderCount, conflicts, resolved, mirrored, snapshotId: settings.lastSnapshotId, processedPaths: pendingPaths, fullScan, pendingPackages: Object.keys(settings.packageHolds) };
  }
};

// src/notifications.ts
var NotificationGate = class {
  constructor() {
    __publicField(this, "groups", /* @__PURE__ */ new Map());
  }
  next(key, message, cooldownMs, now = Date.now()) {
    const previous = this.groups.get(key);
    if (previous && now - previous.lastShownAt < cooldownMs) {
      previous.suppressed++;
      return null;
    }
    const suffix = (previous == null ? void 0 : previous.suppressed) ? ` \xB7 ${previous.suppressed} repeated notification${previous.suppressed === 1 ? "" : "s"} suppressed` : "";
    this.groups.set(key, { lastShownAt: now, suppressed: 0 });
    return `${message}${suffix}`;
  }
};

// src/config-watcher.ts
var INDEX_PATH = ".gib-sync/config-index-v1.json";
var MAX_FILES2 = 2e4;
var MAX_DIRECTORIES = 2e3;
var ConfigWatcher = class {
  constructor(adapter, settings, changed, yieldControl = () => new Promise((resolve) => window.setTimeout(resolve, 0))) {
    this.adapter = adapter;
    this.settings = settings;
    this.changed = changed;
    this.yieldControl = yieldControl;
    __publicField(this, "prior", null);
    __publicField(this, "loaded", false);
    __publicField(this, "stopped", false);
    __publicField(this, "running", null);
  }
  stop() {
    this.stopped = true;
  }
  poll() {
    if (this.stopped) return Promise.resolve();
    if (this.running) return this.running;
    this.running = this.inspect().finally(() => {
      this.running = null;
    });
    return this.running;
  }
  async inspect() {
    var _a;
    const currentSettings = this.settings(), settings = { ...currentSettings, exclusions: [...currentSettings.exclusions] }, root2 = settings.configDir.replace(/\\/g, "/").replace(/\/+$/, "");
    if (!settings.deviceToken || !root2 || root2.startsWith("/") || root2.split("/").some((part) => !part || part === ".." || part === ".")) return;
    const scope = JSON.stringify([root2, settings.syncBookmarks, settings.syncObsidianConfig, settings.syncPlugins, [...settings.exclusions].sort()]);
    if (!this.loaded) {
      this.loaded = true;
      try {
        if (await this.adapter.exists(INDEX_PATH)) {
          const parsed = JSON.parse(await this.adapter.read(INDEX_PATH));
          if (parsed.version === 1 && parsed.scope === scope && parsed.files && typeof parsed.files === "object" && !Array.isArray(parsed.files) && Object.keys(parsed.files).length <= MAX_FILES2) this.prior = { ...parsed, files: Object.fromEntries(Object.entries(parsed.files).filter(([path, stamp]) => path.startsWith(`${root2}/`) && !path.split("/").some((part) => part === ".." || part === ".") && shouldSyncChangedPath(path, settings) && stamp && [stamp.size, stamp.mtime, stamp.ctime].every((value) => typeof value === "number" && Number.isFinite(value) && value >= 0))) };
        }
      } catch (e) {
      }
    }
    const current = { version: 1, scope, files: {} }, pending = [root2];
    let visited = 0, count = 0, directories = 0;
    while (pending.length && !this.stopped) {
      const directory = pending.shift();
      if (!shouldSyncChangedPath(directory, settings)) continue;
      if (++directories > MAX_DIRECTORIES) throw new Error("The enabled configuration scope has too many folders for lightweight tracking; full sync checks remain active.");
      let listing;
      try {
        listing = await this.adapter.list(directory);
      } catch (error) {
        if (!await this.adapter.exists(directory)) continue;
        throw error;
      }
      for (const folder of listing.folders) {
        if (folder.startsWith(`${root2}/`) && !folder.split("/").some((part) => part === ".." || part === ".") && shouldSyncChangedPath(folder, settings)) {
          if (pending.length + directories >= MAX_DIRECTORIES) throw new Error("The enabled configuration scope has too many folders for lightweight tracking; full sync checks remain active.");
          pending.push(folder);
        }
      }
      for (const path of listing.files) {
        if (this.stopped) return;
        if (!path.startsWith(`${root2}/`) || path.split("/").some((part) => part === ".." || part === ".") || !shouldSyncChangedPath(path, settings)) continue;
        if (++count > MAX_FILES2) throw new Error("The enabled configuration scope is too large for lightweight tracking; full sync checks remain active.");
        const stat = await this.adapter.stat(path);
        if ((stat == null ? void 0 : stat.type) === "file") current.files[path] = { size: stat.size, mtime: stat.mtime, ctime: stat.ctime };
        if (++visited % 16 === 0) await this.yieldControl();
      }
      if (++visited % 16 === 0) await this.yieldControl();
    }
    if (this.stopped) return;
    const changed = [], created = [];
    if (((_a = this.prior) == null ? void 0 : _a.scope) === scope) {
      for (const path of /* @__PURE__ */ new Set([...Object.keys(this.prior.files), ...Object.keys(current.files)])) {
        const before = this.prior.files[path], after = current.files[path];
        if (!before || !after || before.size !== after.size || before.mtime !== after.mtime || before.ctime !== after.ctime) changed.push(path);
        if (after && !before) created.push(path);
      }
    }
    const differs = !this.prior || this.prior.scope !== scope || changed.length;
    this.prior = current;
    if (changed.length) this.changed(changed.sort(), created.sort());
    if (differs && !this.stopped) {
      if (!await this.adapter.exists(".gib-sync")) {
        if (this.stopped) return;
        await this.adapter.mkdir(".gib-sync");
      }
      if (!this.stopped) await this.adapter.write(INDEX_PATH, JSON.stringify(current));
    }
  }
};

// src/snapshot-cache.ts
var root = ".gib-sync/snapshot-cache";
var encoder8 = new TextEncoder();
var MAX_CACHE_BYTES = 4 * 1024 * 1024;
var SnapshotCache = class {
  constructor(adapter) {
    this.adapter = adapter;
    __publicField(this, "memory", /* @__PURE__ */ new Map());
  }
  path(id) {
    return /^[a-zA-Z0-9-]{1,100}$/.test(id) ? `${root}/${id}.json` : null;
  }
  async get(id, vaultId) {
    var _a, _b;
    const saved = this.memory.get(id);
    if ((saved == null ? void 0 : saved.vaultId) === vaultId) return saved;
    const path = this.path(id);
    if (!path) return null;
    try {
      if (((_b = (_a = await this.adapter.stat(path)) == null ? void 0 : _a.size) != null ? _b : 0) > MAX_CACHE_BYTES) return null;
      const raw = await this.adapter.read(path);
      if (raw.length > MAX_CACHE_BYTES) return null;
      const packed = JSON.parse(raw);
      if (typeof packed.payload !== "string" || await hashBytes(encoder8.encode(packed.payload)) !== packed.hash) return null;
      const value = JSON.parse(packed.payload);
      if (value.id !== id || value.vaultId !== vaultId || !Array.isArray(value.entries)) return null;
      this.remember(value);
      return value;
    } catch (e) {
      return null;
    }
  }
  remember(snapshot) {
    this.memory.delete(snapshot.id);
    this.memory.set(snapshot.id, snapshot);
    while (this.memory.size > 3) this.memory.delete(this.memory.keys().next().value);
  }
  async put(snapshot) {
    const payload = JSON.stringify(snapshot);
    if (payload.length > MAX_CACHE_BYTES / 2) return;
    this.remember(snapshot);
    const path = this.path(snapshot.id);
    if (!path) return;
    try {
      for (const directory of [".gib-sync", root]) if (!await this.adapter.exists(directory)) await this.adapter.mkdir(directory);
      const hash = await hashBytes(encoder8.encode(payload));
      await this.adapter.write(path, JSON.stringify({ payload, hash }));
      const files = (await this.adapter.list(root)).files.filter((file) => file.startsWith(`${root}/`) && /^[a-zA-Z0-9-]{1,100}\.json$/.test(file.slice(root.length + 1)));
      if (files.length > 3) {
        const ordered = await Promise.all(files.map(async (file) => {
          var _a, _b;
          return { path: file, time: (_b = (_a = await this.adapter.stat(file)) == null ? void 0 : _a.mtime) != null ? _b : 0 };
        }));
        for (const file of ordered.sort((a, b) => b.time - a.time).slice(3)) await this.adapter.remove(file.path);
      }
    } catch (e) {
    }
  }
};

// src/canonical-adapter.ts
function canonicalAdapter(adapter, root2, aliases = () => []) {
  const physical = (path) => {
    const configured = normalizedConfigDir(root2());
    return path === ".obsidian" ? configured : path.startsWith(".obsidian/") ? `${configured}${path.slice(9)}` : path;
  };
  const logical = (path) => canonicalConfigPath(path, root2());
  const mapped = /* @__PURE__ */ new Set(["read", "readBinary", "write", "writeBinary", "append", "appendBinary", "stat", "exists", "mkdir", "rmdir", "remove", "trashSystem", "trashLocal", "getResourcePath"]);
  return new Proxy(adapter, { get(target, key) {
    const value = Reflect.get(target, key, target);
    if (typeof value !== "function") return value;
    if (key === "list") return async (path) => {
      const listing = await target.list(physical(path)), configured = normalizedConfigDir(root2()), retired = new Set(aliases().filter((alias) => alias !== configured && alias !== ".obsidian"));
      const convert = (paths) => [...new Set(paths.filter((candidate) => !retired.has(candidate) && !(configured !== ".obsidian" && candidate === ".obsidian")).map(logical))];
      return { files: convert(listing.files), folders: convert(listing.folders) };
    };
    if (key === "rename" || key === "copy") return (from, to, ...rest) => value.call(target, physical(from), physical(to), ...rest);
    if (mapped.has(String(key))) return (path, ...rest) => value.call(target, physical(path), ...rest);
    return value.bind(target);
  } });
}

// src/status.ts
var transferPhases = /* @__PURE__ */ new Set(["applying", "uploading", "committing", "mirroring"]);
function deriveIndicatorState(live, configured, blocked, attentionCount = 0, health = { errors: 0, warnings: 0 }) {
  var _a, _b, _c;
  if (!configured) return { key: "setup", label: "Setup", icon: "circle-dashed", tone: "neutral", animated: false, attentionCount: 0, description: "Gib Sync is not configured" };
  if (blocked) return { key: "blocked", label: "Paused", icon: "pause-circle", tone: "neutral", animated: false, attentionCount: 0, description: "Synchronization is paused" };
  if (attentionCount > 0) return { key: "attention", label: "Attention", icon: "triangle-alert", tone: "warning", animated: false, attentionCount, description: `${attentionCount} held change${attentionCount === 1 ? "" : "s"} need review` };
  if (health.errors > 0) return { key: "error", label: "Needs repair", icon: "cloud-off", tone: "error", animated: false, attentionCount: 0, description: (_a = health.description) != null ? _a : `${health.errors} server health error${health.errors === 1 ? "" : "s"}` };
  if (live.phase === "blocked") return { key: "blocked", label: "Needs attention", icon: "shield-alert", tone: "warning", animated: false, attentionCount: 0, description: live.message };
  if (live.phase === "retrying") return { key: "retrying", label: "Retrying", icon: "clock-3", tone: "active", animated: false, attentionCount: 0, description: live.running ? "Sync was interrupted. Retrying automatically\u2026" : "Reconnecting to incoming updates. Automatic checks remain active." };
  if (live.phase === "offline") return { key: "offline", label: "Offline", icon: "cloud-off", tone: "neutral", animated: false, attentionCount: 0, description: "Could not reach the server. Your changes remain on this device." };
  if (live.phase === "error") return { key: "error", label: "Sync couldn\u2019t finish", icon: "triangle-alert", tone: "error", animated: false, attentionCount: 0, description: live.lastError || live.message };
  if (health.warnings > 0) return { key: "attention", label: "Needs attention", icon: "triangle-alert", tone: "warning", animated: false, attentionCount: 0, description: (_b = health.description) != null ? _b : `${health.warnings} health warning${health.warnings === 1 ? "" : "s"}` };
  if (live.running && transferPhases.has(live.phase)) {
    const action = live.phase === "uploading" ? "Sending" : live.phase === "applying" ? "Receiving" : live.phase === "mirroring" ? "Updating Seafile" : "Saving";
    return { key: "syncing", label: action, icon: "refresh-cw", tone: "active", animated: true, attentionCount: 0, description: live.total ? `${action} ${Math.min((_c = live.current) != null ? _c : 0, live.total)} of ${live.total} files` : live.phase === "committing" ? "Saving this version in server history\u2026" : `${action} changes\u2026` };
  }
  const verified = Boolean(live.verified && live.lastSuccessAt && !live.pendingChanges);
  if (live.running) return { key: "checking", label: "Checking", icon: "check", tone: verified ? "success" : "neutral", animated: true, attentionCount: 0, description: verified ? "Checking for changes. Last check confirmed this device was up to date." : "Checking this device against the server." };
  if (live.pendingChanges) return { key: "queued", label: "Changes waiting", icon: "clock-3", tone: "active", animated: false, attentionCount: 0, description: `${live.pendingChanges} change${live.pendingChanges === 1 ? "" : "s"} waiting to sync` };
  if (live.phase === "scheduled" && !verified) return { key: "checking", label: "Check scheduled", icon: "clock-3", tone: "neutral", animated: false, attentionCount: 0, description: "Waiting to check this device against the server." };
  if (!verified) return { key: "checking", label: "Not verified yet", icon: "circle-dashed", tone: "neutral", animated: false, attentionCount: 0, description: "This device has not verified the current server state yet." };
  return { key: "synced", label: "Up to date", icon: "check", tone: "success", animated: false, attentionCount: 0, description: "This device has verified the latest server snapshot." };
}

// src/server-compatibility.ts
function parseVersion(value) {
  const match = /^v?(\d+)\.(\d+)\.(\d+)(?:-[0-9A-Za-z.-]+)?$/.exec(value.trim());
  return match ? { parts: [Number(match[1]), Number(match[2]), Number(match[3])], prerelease: value.includes("-") } : null;
}
function olderThan(left, right) {
  const a = parseVersion(left), b = parseVersion(right);
  if (!a || !b) return true;
  for (let index = 0; index < 3; index++) {
    if (a.parts[index] !== b.parts[index]) return a.parts[index] < b.parts[index];
  }
  return a.prerelease && !b.prerelease;
}
function staleServerReason(metadata) {
  var _a, _b;
  if (metadata.protocolVersion !== PROTOCOL_VERSION) return `This server uses protocol ${(_a = metadata.protocolVersion) != null ? _a : "unknown"}; Gib Sync requires protocol ${PROTOCOL_VERSION}.`;
  if (!metadata.serverVersion || olderThan(metadata.serverVersion, MINIMUM_SAFE_SERVER_VERSION)) return `Gib Sync server ${MINIMUM_SAFE_SERVER_VERSION} or later is required; this server reports ${(_b = metadata.serverVersion) != null ? _b : "no version"}.`;
  const capabilities = new Set(Array.isArray(metadata.serverCapabilities) ? metadata.serverCapabilities : []), missing2 = REQUIRED_SERVER_CAPABILITIES.filter((item) => !capabilities.has(item));
  return missing2.length ? `This Gib Sync server is missing required safety capabilities: ${missing2.join(", ")}.` : null;
}
function enforceServerCompatibility(result) {
  var _a;
  const reason = (_a = result.reason) != null ? _a : staleServerReason({ protocolVersion: result.serverProtocol, serverVersion: result.serverVersion, serverCapabilities: result.serverCapabilities });
  return { ...result, compatible: result.compatible && reason === null, reason };
}
function assertSetupServerCompatible(setup) {
  const reason = staleServerReason(setup);
  if (reason) throw new Error(`${reason} Update the self-hosted Gib Sync server before connecting this device.`);
}
function unavailableServerCompatibility(reason = "This server does not expose a compatible version check.") {
  return { clientVersion: null, clientProtocol: null, minimumVersion: "unknown", recommendedVersion: "unknown", serverProtocol: -1, serverVersion: null, serverCapabilities: [], compatible: false, updateAvailable: false, reason };
}

// src/ui.ts
var import_obsidian3 = require("obsidian");

// src/diagnostics.ts
function privacySafeDiagnostics(live, server, connection) {
  return {
    generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    live: {
      phase: live.phase,
      running: live.running,
      current: live.current,
      total: live.total,
      startedAt: live.startedAt,
      completedAt: live.completedAt,
      lastSuccessAt: live.lastSuccessAt,
      lastErrorAt: live.lastErrorAt,
      nextSyncAt: live.nextSyncAt,
      activities: live.activities.map(({ at, phase, level, current, total, repeats }) => ({ at, phase, level, current, total, repeats }))
    },
    server: server ? {
      protocolVersion: server.protocolVersion,
      deviceCount: server.deviceCount,
      snapshotCount: server.snapshotCount,
      blobCount: server.blobCount,
      blobBytes: server.blobBytes,
      mirrorFileCount: server.mirrorFileCount,
      mirrorCurrent: server.mirrorCurrent,
      externalScanAt: server.externalScanAt,
      externalImportAt: server.externalImportAt,
      externalError: Boolean(server.externalError),
      compatibility: server.compatibility ? { clientVersion: server.compatibility.clientVersion, clientProtocol: server.compatibility.clientProtocol, minimumVersion: server.compatibility.minimumVersion, recommendedVersion: server.compatibility.recommendedVersion, serverProtocol: server.compatibility.serverProtocol, compatible: server.compatibility.compatible, updateAvailable: server.compatibility.updateAvailable } : null,
      containment: server.containment ? { active: server.containment.active, thisVaultAllowed: server.containment.thisVaultAllowed, enabledAt: server.containment.enabledAt } : null,
      safeguards: { mode: server.safeguards.policy.mode, writeLocked: server.safeguards.writeLocked, pendingQuarantines: server.safeguards.pendingQuarantines },
      healthAlerts: server.healthAlerts.map(({ code, level, at }) => ({ code: code.includes(":") ? code.slice(0, code.indexOf(":")) : code, level, at })),
      devices: server.devices.map(({ ready, revokedAt, clockSkewMs, current, clientVersion, clientProtocol, compatibility }) => ({ ready, revoked: Boolean(revokedAt), clockSkewMs, current, clientVersion, clientProtocol, compatibility }))
    } : null,
    connection
  };
}
function detailedDiagnostics(live, server, connection) {
  const safe = privacySafeDiagnostics(live, server, connection);
  const redact = (value) => value.replace(/\bhttps?:\/\/[^\s)]+/gi, "<server-url>").replace(/\bBearer\s+[^\s]+/gi, "Bearer <redacted>");
  return {
    ...safe,
    warning: "Detailed diagnostics may contain vault-relative file names. Saved credentials, keys, tokens, and connection settings are excluded; URLs in error and activity text are redacted.",
    live: { ...safe.live, message: redact(live.message), lastError: redact(live.lastError), lastResult: redact(live.lastResult), activities: live.activities.map(({ at, phase, level, message, current, total, repeats }) => ({ at, phase, level, message: redact(message), current, total, repeats })) }
  };
}

// src/status-overview.ts
function buildSyncFacts(live, server, localSnapshotId) {
  var _a, _b, _c, _d, _e, _f;
  const pending = (_a = live.pendingChanges) != null ? _a : 0, headId = (_c = (_b = server == null ? void 0 : server.head) == null ? void 0 : _b.id) != null ? _c : null, current = Boolean(headId && headId === localSnapshotId && live.verified && !pending);
  const other = (_d = server == null ? void 0 : server.devices.filter((device) => !device.current && !device.revokedAt)) != null ? _d : [];
  const caughtUp = headId ? other.filter((device) => device.acknowledgedSnapshotId === headId).length : 0;
  return [
    { label: "This device", value: pending ? `${pending} change${pending === 1 ? "" : "s"} waiting` : current ? "Up to date" : live.verified ? "Last check passed" : "Checking", detail: pending ? "Local changes have not finished syncing yet." : current ? "This device confirmed the latest accepted server version." : "A successful sync verifies what this device has received.", tone: pending ? "active" : current ? "success" : "neutral" },
    { label: "Accepted server copy", value: pending ? "Waiting for this device" : headId ? headId === localSnapshotId ? "Received" : "Updates available" : "Not verified", detail: "Accepted versions are stored in server history before other devices download them.", tone: pending || headId && headId !== localSnapshotId ? "active" : headId ? "success" : "neutral" },
    { label: "Other devices", value: !server ? "Checking" : !other.length ? "No other active devices" : !headId ? "Not verified" : caughtUp === other.length ? `${caughtUp} caught up` : `${caughtUp} of ${other.length} confirmed`, detail: !other.length ? "Add another device with manual setup or a temporary code." : "A device is confirmed only after it acknowledges this accepted version; offline devices catch up when opened.", tone: caughtUp === other.length && other.length > 0 ? "success" : "neutral" },
    { label: "Readable Seafile copy", value: !server ? "Checking" : server.externalError || ((_e = server.projection) == null ? void 0 : _e.lastError) ? "Retrying safely" : server.mirrorCurrent ? "Current" : "Catching up", detail: "This readable copy is separate from accepted sync history. Other devices can sync while Seafile catches up.", tone: (server == null ? void 0 : server.externalError) || ((_f = server == null ? void 0 : server.projection) == null ? void 0 : _f.lastError) ? "warning" : (server == null ? void 0 : server.mirrorCurrent) ? "success" : server ? "active" : "neutral" }
  ];
}
function relativeTime(value, now) {
  if (!value) return "never";
  const timestamp = Date.parse(value);
  if (!Number.isFinite(timestamp)) return "never";
  const seconds = Math.max(0, Math.floor((now - timestamp) / 1e3));
  if (seconds < 10) return "just now";
  if (seconds < 60) return `${seconds} sec ago`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} hr ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days} day${days === 1 ? "" : "s"} ago`;
  return new Date(timestamp).toLocaleDateString();
}
function buildQuickStatusModel(input) {
  var _a, _b;
  const { state, live, configured, nativeSyncBlocked, paused } = input;
  const now = (_a = input.now) != null ? _a : Date.now();
  let description;
  if (!configured) description = "Connect this vault to start syncing.";
  else if (nativeSyncBlocked) description = "Turn off Obsidian Sync to continue safely.";
  else if (paused) description = "Automatic syncing is paused.";
  else if (state.key === "blocked") description = state.description || "Synchronization is safely paused.";
  else if (state.key === "attention" && state.attentionCount > 0) description = `${state.attentionCount} held change${state.attentionCount === 1 ? "" : "s"} need review.`;
  else if (state.key === "syncing" || state.key === "checking" || state.key === "retrying" || state.key === "offline") description = state.description;
  else if (state.key === "queued") description = state.description;
  else if (state.key === "error") description = live.lastError || state.description || "Sync could not finish.";
  else if (state.key === "attention") description = state.description || "Gib Sync needs your attention.";
  else description = "Your vault is up to date.";
  let meta;
  if (!configured) meta = "Not connected";
  else if (state.key === "syncing" && live.total) meta = `${Math.min((_b = live.current) != null ? _b : 0, live.total)} of ${live.total} files`;
  else if (state.key === "syncing") meta = "Working now";
  else if (state.key === "retrying") meta = live.nextSyncAt ? `Retrying in ${Math.max(1, Math.ceil((Date.parse(live.nextSyncAt) - now) / 1e3))} sec` : "Retrying automatically";
  else if (state.key === "queued") meta = live.pendingChanges ? `${live.pendingChanges} pending change${live.pendingChanges === 1 ? "" : "s"}` : "Waiting to check";
  else meta = live.lastSuccessAt ? `Last verified ${relativeTime(live.lastSuccessAt, now)}` : "Not verified yet";
  if (!configured) return { description, meta, primaryAction: "setup", primaryLabel: "Set up", primaryDisabled: false };
  if (nativeSyncBlocked) return { description, meta, primaryAction: "resolve", primaryLabel: "Resolve", primaryDisabled: false };
  if (state.attentionCount > 0) return { description, meta, primaryAction: "review", primaryLabel: "Review", primaryDisabled: false };
  if (paused) return { description, meta, primaryAction: "resume", primaryLabel: "Resume", primaryDisabled: false };
  if (state.key === "blocked") return state.label === "Server paused" || /emergency containment/i.test(state.description) ? { description, meta, primaryAction: "sync", primaryLabel: "Server paused", primaryDisabled: true } : { description, meta, primaryAction: "settings", primaryLabel: "Open settings", primaryDisabled: false };
  return { description, meta, primaryAction: "sync", primaryLabel: live.running ? state.key === "checking" ? "Checking\u2026" : state.key === "retrying" ? "Retrying\u2026" : "Syncing\u2026" : state.key === "error" || state.key === "offline" ? "Try again" : "Sync now", primaryDisabled: live.running };
}

// src/conflict-inbox.ts
function conflictLineComparison(left, right, maximumLines = 400) {
  var _a, _b;
  const a = left.split("\n", maximumLines), b = right.split("\n", maximumLines), rows = [];
  const changes = diffLines(a.join("\n"), b.join("\n"), { timeout: 20, maxEditLength: 1e3 });
  if (!changes) {
    for (let index = 0; index < Math.min(maximumLines, Math.max(a.length, b.length)); index++) rows.push({ left: (_a = a[index]) != null ? _a : "", right: (_b = b[index]) != null ? _b : "", changed: a[index] !== b[index] });
    return rows;
  }
  let removed = [], added = [];
  const flush = () => {
    var _a2, _b2;
    for (let index = 0; index < Math.max(removed.length, added.length) && rows.length < maximumLines; index++) rows.push({ left: (_a2 = removed[index]) != null ? _a2 : "", right: (_b2 = added[index]) != null ? _b2 : "", changed: true });
    removed = [];
    added = [];
  };
  for (const change of changes) {
    const lines = change.value.split("\n");
    if (change.value.endsWith("\n")) lines.pop();
    if (change.removed) removed.push(...lines);
    else if (change.added) added.push(...lines);
    else {
      flush();
      for (const line of lines) {
        if (rows.length >= maximumLines) break;
        rows.push({ left: line, right: line, changed: false });
      }
    }
  }
  flush();
  return rows;
}

// src/device-diagnostics.ts
var FrameMetrics = class {
  constructor() {
    __publicField(this, "gaps", []);
    __publicField(this, "samples", 0);
    __publicField(this, "maximum", 0);
    __publicField(this, "over50", 0);
    __publicField(this, "over100", 0);
    __publicField(this, "background", 0);
  }
  add(ms, hidden = false) {
    if (hidden) {
      this.background++;
      return;
    }
    this.samples++;
    this.maximum = Math.max(this.maximum, ms);
    if (ms > 50) this.over50++;
    if (ms > 100) this.over100++;
    if (this.gaps.length >= 1024) this.gaps.shift();
    this.gaps.push(ms);
  }
  snapshot() {
    var _a;
    const sorted = [...this.gaps].sort((a, b) => a - b), round = (n) => Math.round(n * 100) / 100;
    return { samples: this.samples, p95WindowSamples: sorted.length, p95Ms: round((_a = sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * 0.95))]) != null ? _a : 0), maxGapMs: round(this.maximum), over50Ms: this.over50, over100Ms: this.over100, backgroundGaps: this.background };
  }
};
var FrameSampler = class {
  constructor() {
    __publicField(this, "active", false);
    __publicField(this, "request", null);
    __publicField(this, "previous", 0);
    __publicField(this, "wasHidden", false);
    __publicField(this, "metrics", new FrameMetrics());
  }
  start(hidden, include = () => true, backgroundEpoch = () => 0) {
    if (this.active) return;
    this.active = true;
    this.previous = performance.now();
    this.wasHidden = hidden();
    let previousEpoch = backgroundEpoch();
    const tick = () => {
      if (!this.active) return;
      const now = performance.now(), isHidden = hidden(), epoch = backgroundEpoch();
      if (include()) this.metrics.add(now - this.previous, this.wasHidden || isHidden || epoch !== previousEpoch);
      this.previous = now;
      this.wasHidden = isHidden;
      previousEpoch = epoch;
      this.request = requestAnimationFrame(tick);
    };
    this.request = requestAnimationFrame(tick);
  }
  stop() {
    this.active = false;
    if (this.request !== null && typeof cancelAnimationFrame === "function") cancelAnimationFrame(this.request);
    this.request = null;
  }
};
var DeviceLifecycleProbe = class {
  constructor() {
    __publicField(this, "counts", { hidden: 0, shown: 0, pagehide: 0, pageshow: 0 });
    __publicField(this, "hidden", false);
    __publicField(this, "removers", []);
  }
  start(doc = document, win = window) {
    this.stop();
    this.hidden = doc.hidden;
    const visibility = () => {
      this.hidden = doc.hidden;
      this.counts[doc.hidden ? "hidden" : "shown"]++;
    };
    const hide = () => {
      this.hidden = true;
      this.counts.pagehide++;
    }, show = () => {
      this.hidden = doc.hidden;
      this.counts.pageshow++;
    };
    doc.addEventListener("visibilitychange", visibility);
    win.addEventListener("pagehide", hide);
    win.addEventListener("pageshow", show);
    this.removers = [() => doc.removeEventListener("visibilitychange", visibility), () => win.removeEventListener("pagehide", hide), () => win.removeEventListener("pageshow", show)];
  }
  stop() {
    for (const remove of this.removers) remove();
    this.removers = [];
  }
};
var DeviceSyncActivityProbe = class {
  constructor() {
    __publicField(this, "sampler", new FrameSampler());
    __publicField(this, "startAt", null);
    __publicField(this, "stopAt", null);
    __publicField(this, "lastAt", 0);
    __publicField(this, "running", false);
    __publicField(this, "phase", "other");
    __publicField(this, "runningMs", 0);
    __publicField(this, "starts", 0);
    __publicField(this, "completed", 0);
    __publicField(this, "interrupted", 0);
    __publicField(this, "stages", {});
  }
  start(lifecycle) {
    if (this.startAt !== null) return;
    this.startAt = performance.now();
    this.lastAt = this.startAt;
    this.sampler.start(() => lifecycle.hidden, () => this.running, () => lifecycle.counts.hidden + lifecycle.counts.pagehide);
  }
  account(now) {
    var _a;
    if (this.running) {
      const elapsed = Math.max(0, now - this.lastAt);
      this.runningMs += elapsed;
      this.stages[this.phase] = ((_a = this.stages[this.phase]) != null ? _a : 0) + elapsed;
    }
    this.lastAt = now;
  }
  observe(status) {
    if (this.startAt === null || this.stopAt !== null) return;
    this.account(performance.now());
    if (status.running && !this.running) this.starts++;
    if (!status.running && this.running) {
      if (status.phase === "complete" || status.phase === "up-to-date") this.completed++;
      else this.interrupted++;
    }
    this.running = status.running;
    this.phase = (/* @__PURE__ */ new Set(["checking", "scanning", "reading-remote", "merging", "applying", "uploading", "committing", "mirroring", "retrying"])).has(status.phase) ? status.phase : "other";
  }
  snapshot() {
    var _a;
    const now = (_a = this.stopAt) != null ? _a : performance.now();
    if (this.startAt !== null && this.stopAt === null) this.account(now);
    return { observedMs: Math.round(this.startAt === null ? 0 : now - this.startAt), runningMs: Math.round(this.runningMs), startedRuns: this.starts, completedRuns: this.completed, interruptedRuns: this.interrupted, stageMs: Object.fromEntries(Object.entries(this.stages).map(([key, value]) => [key, Math.round(value)])), frames: this.sampler.metrics.snapshot() };
  }
  stop() {
    if (this.startAt !== null && this.stopAt === null) {
      this.stopAt = performance.now();
      this.account(this.stopAt);
    }
    this.sampler.stop();
  }
};
function nextFrame(signal) {
  return new Promise((resolve, reject) => {
    let id;
    const cancel = () => {
      if (id !== void 0 && typeof cancelAnimationFrame === "function") cancelAnimationFrame(id);
      reject(new Error("Device test cancelled"));
    };
    if (signal.aborted) {
      cancel();
      return;
    }
    signal.addEventListener("abort", cancel, { once: true });
    id = requestAnimationFrame(() => {
      signal.removeEventListener("abort", cancel);
      resolve();
    });
  });
}
async function runDeviceProbe(adapter, pluginVersion, platform, lifecycle, signal, activity) {
  var _a;
  const checkpoint = () => {
    if (signal.aborted) throw new Error("Device test cancelled");
  }, yieldNow = () => new Promise((resolve) => setTimeout(resolve, 0)), idle = new FrameMetrics(), io = new FrameSampler(), epoch = () => lifecycle.counts.hidden + lifecycle.counts.pagehide;
  let previous = performance.now(), wasHidden = lifecycle.hidden, previousEpoch = epoch();
  for (let index = 0; index < 24; index++) {
    checkpoint();
    await nextFrame(signal);
    const now = performance.now();
    idle.add(now - previous, wasHidden || lifecycle.hidden || previousEpoch !== epoch());
    previous = now;
    wasHidden = lifecycle.hidden;
    previousEpoch = epoch();
  }
  const fileIo = { appendSupported: typeof adapter.appendBinary === "function", resourceSupported: typeof adapter.getResourcePath === "function", testedBytes: 0, verified: false };
  if (fileIo.appendSupported && fileIo.resourceSupported) {
    io.start(() => lifecycle.hidden, () => true, epoch);
    try {
      const root2 = ".gib-sync/diagnostics", path = `${root2}/${crypto.randomUUID()}.tmp`, bytes2 = new Uint8Array(1024 * 1024);
      for (let index = 0; index < bytes2.length; index++) bytes2[index] = index % 251;
      const expected = await hashBytes(bytes2);
      checkpoint();
      if (!await adapter.exists(".gib-sync")) await adapter.mkdir(".gib-sync");
      if (!await adapter.exists(root2)) await adapter.mkdir(root2);
      await adapter.writeBinary(path, new ArrayBuffer(0));
      try {
        for (let offset = 0; offset < bytes2.length; offset += 64 * 1024) {
          checkpoint();
          await adapter.appendBinary(path, bytes2.slice(offset, offset + 64 * 1024).buffer);
          await yieldNow();
        }
        fileIo.testedBytes = bytes2.length;
        fileIo.verified = await hashAdapterFile(adapter, path, checkpoint, yieldNow, false) === expected;
        if (!fileIo.verified) throw new Error("Generated test bytes failed native stream verification");
      } finally {
        try {
          const stat = await adapter.stat(path);
          if ((stat == null ? void 0 : stat.type) === "file" && stat.size <= bytes2.length) {
            const prefixHash = stat.size === bytes2.length ? expected : await hashBytes(bytes2.subarray(0, stat.size));
            if (await hashAdapterFile(adapter, path, () => {
            }, yieldNow, false) === prefixHash) await adapter.remove(path);
          }
        } catch (e) {
        }
      }
    } finally {
      io.stop();
    }
  }
  const actualSync = (_a = activity == null ? void 0 : activity.snapshot()) != null ? _a : { observedMs: 0, runningMs: 0, startedRuns: 0, completedRuns: 0, interruptedRuns: 0, stageMs: {}, frames: new FrameMetrics().snapshot() };
  return { schemaVersion: 2, pluginVersion, platform, sampledAt: (/* @__PURE__ */ new Date()).toISOString(), frames: idle.snapshot(), responsiveness: { idle: idle.snapshot(), generatedIo: io.metrics.snapshot(), actualSync }, lifecycle: { ...lifecycle.counts }, fileIo, evidence: { syntheticOnly: actualSync.startedRuns === 0, realRunObserved: actualSync.startedRuns > 0, fullScaleNotCertified: true } };
}

// src/ui.ts
function defaultDeviceName() {
  if (import_obsidian3.Platform.isIosApp) return "iPhone / iPad";
  if (import_obsidian3.Platform.isAndroidApp) return "Android";
  return navigator.platform || "Desktop";
}
function when(value) {
  return value ? new Date(value).toLocaleString() : "Never";
}
function bytes(value) {
  if (value < 1024) return `${value} B`;
  if (value < 1024 ** 2) return `${(value / 1024).toFixed(1)} KB`;
  if (value < 1024 ** 3) return `${(value / 1024 ** 2).toFixed(1)} MB`;
  return `${(value / 1024 ** 3).toFixed(2)} GB`;
}
function assessmentText(value) {
  return `${value.created} created \xB7 ${value.modified} modified \xB7 ${value.deleted} deleted \xB7 ${value.moved} moved \xB7 ${value.affectedPercent}% affected`;
}
function mobileContent(element) {
  element.addClass("gib-sync-modal-content");
}
function onboardingChoice(element, selected) {
  new import_obsidian3.Setting(element).setName("First download").setDesc("Compare and preserve is safest if this device already has notes. Use the server copy when this device should adopt the existing vault; replaced or device-only files remain in local recovery.").addDropdown((dropdown) => dropdown.addOption("preserve-local", "Compare and preserve local files").addOption("server-first", "Use server copy; keep local backups").setValue("preserve-local").onChange((value) => selected(value)));
}
var ConfirmActionModal = class extends import_obsidian3.Modal {
  constructor(app, heading, message, confirmText, resolve, warning = false) {
    super(app);
    this.heading = heading;
    this.message = message;
    this.confirmText = confirmText;
    this.resolve = resolve;
    this.warning = warning;
    __publicField(this, "settled", false);
  }
  onOpen() {
    mobileContent(this.contentEl);
    this.setTitle(this.heading);
    this.contentEl.createEl("p", { text: this.message });
    new import_obsidian3.Setting(this.contentEl).addButton((button) => button.setButtonText("Cancel").onClick(() => this.finish(false))).addButton((button) => {
      button.setButtonText(this.confirmText);
      if (this.warning) button.setWarning();
      else button.setCta();
      button.onClick(() => this.finish(true));
    });
  }
  finish(value) {
    if (this.settled) return;
    this.settled = true;
    this.resolve(value);
    this.close();
  }
  onClose() {
    this.contentEl.empty();
    if (!this.settled) {
      this.settled = true;
      this.resolve(false);
    }
  }
};
function confirmAction(app, heading, message, confirmText = "Continue", warning = false) {
  return new Promise((resolve) => new ConfirmActionModal(app, heading, message, confirmText, resolve, warning).open());
}
var TextPromptModal = class extends import_obsidian3.Modal {
  constructor(app, heading, label, initial, resolve) {
    super(app);
    this.heading = heading;
    this.label = label;
    this.resolve = resolve;
    __publicField(this, "settled", false);
    __publicField(this, "value", "");
    this.value = initial;
  }
  onOpen() {
    mobileContent(this.contentEl);
    this.setTitle(this.heading);
    let input;
    new import_obsidian3.Setting(this.contentEl).setName(this.label).addText((text) => {
      input = text.inputEl;
      text.setValue(this.value).onChange((value) => this.value = value);
      input.onkeydown = (event) => {
        if (event.key === "Enter") {
          event.preventDefault();
          this.finish(this.value.trim());
        }
      };
    });
    new import_obsidian3.Setting(this.contentEl).addButton((button) => button.setButtonText("Cancel").onClick(() => this.finish(null))).addButton((button) => button.setCta().setButtonText("Save").onClick(() => this.finish(this.value.trim())));
    window.setTimeout(() => {
      input.focus();
      input.select();
    }, 0);
  }
  finish(value) {
    if (this.settled) return;
    this.settled = true;
    this.resolve(value);
    this.close();
  }
  onClose() {
    this.contentEl.empty();
    if (!this.settled) {
      this.settled = true;
      this.resolve(null);
    }
  }
};
function promptText(app, heading, label, initial) {
  return new Promise((resolve) => new TextPromptModal(app, heading, label, initial, resolve).open());
}
async function copyText(value) {
  var _a;
  try {
    if ((_a = navigator.clipboard) == null ? void 0 : _a.writeText) {
      await navigator.clipboard.writeText(value);
      return true;
    }
  } catch (e) {
  }
  const area = document.body.createEl("textarea");
  area.value = value;
  area.setAttr("readonly", "");
  area.style.position = "fixed";
  area.style.opacity = "0";
  area.select();
  try {
    return document.execCommand("copy");
  } catch (e) {
    return false;
  } finally {
    area.remove();
  }
}
var SetupModal = class extends import_obsidian3.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
  }
  onOpen() {
    var _a, _b, _c;
    mobileContent(this.contentEl);
    this.setTitle("Connect Gib Sync");
    this.contentEl.createEl("p", { text: "Choose the Seafile account, library, and folder for this vault. Using the same location on another device reconnects it manually. Your password is exchanged for a Seafile API token and is never saved in Obsidian." });
    let server = this.plugin.settings.serverUrl || "";
    let seafileUrl = ((_a = this.plugin.settings.storage) == null ? void 0 : _a.seafileUrl) || "";
    let username = ((_b = this.plugin.settings.storage) == null ? void 0 : _b.username) || "";
    let password = "";
    let vaultName = this.app.vault.getName();
    let deviceName = defaultDeviceName();
    let onboardingMode = "preserve-local";
    let libraryId = "";
    let libraryName = "";
    let basePath = ((_c = this.plugin.settings.storage) == null ? void 0 : _c.basePath) || `/Obsidian/${vaultName}`;
    let existingVaultId;
    let libraries = [];
    let existingVaults = [];
    let pathInput;
    let vaultInput;
    new import_obsidian3.Setting(this.contentEl).setName("Gib Sync server").addText((text) => text.setPlaceholder("https://sync.example.com").setValue(server).onChange((value) => server = value.trim()));
    new import_obsidian3.Setting(this.contentEl).setName("Seafile server").addText((text) => text.setPlaceholder("https://seafile.example.com").setValue(seafileUrl).onChange((value) => seafileUrl = value.trim()));
    new import_obsidian3.Setting(this.contentEl).setName("Seafile account").addText((text) => text.setPlaceholder("you@example.com").setValue(username).onChange((value) => username = value.trim()));
    new import_obsidian3.Setting(this.contentEl).setName("Seafile password").setDesc("Used only during this connection request.").addText((text) => {
      text.inputEl.type = "password";
      text.onChange((value) => password = value);
    });
    const librarySetting = new import_obsidian3.Setting(this.contentEl).setName("Seafile library").setDesc("Load the libraries available to this account.");
    const select = librarySetting.controlEl.createEl("select");
    select.disabled = true;
    select.createEl("option", { text: "Load libraries first", value: "" });
    select.onchange = () => {
      var _a2;
      libraryId = select.value;
      libraryName = ((_a2 = libraries.find((item) => item.id === libraryId)) == null ? void 0 : _a2.name) || "";
      existingVaultId = void 0;
      existingSelect.value = "-1";
    };
    const existingSetting = new import_obsidian3.Setting(this.contentEl).setName("Existing Gib Sync vault").setDesc("A discovered vault can fill the library and folder automatically.");
    const existingSelect = existingSetting.controlEl.createEl("select");
    existingSelect.disabled = true;
    existingSelect.createEl("option", { text: "Load libraries first", value: "" });
    const useExisting = (index) => {
      const existing = existingVaults[index];
      if (!existing) return;
      existingVaultId = existing.vaultId;
      libraryId = existing.libraryId;
      libraryName = existing.libraryName;
      select.value = libraryId;
      basePath = existing.basePath;
      pathInput.value = basePath;
      vaultName = existing.vaultName;
      vaultInput.value = vaultName;
    };
    existingSelect.onchange = () => {
      const index = Number(existingSelect.value);
      if (Number.isInteger(index) && index >= 0) useExisting(index);
      else existingVaultId = void 0;
    };
    librarySetting.addButton((button) => button.setButtonText("Load libraries").onClick(async () => {
      var _a2, _b2, _c2, _d;
      button.setDisabled(true).setButtonText("Loading\u2026");
      try {
        await this.plugin.verifyServerBeforeSetup(server);
        const result = await this.plugin.api.discover(server, seafileUrl, username, password);
        libraries = result.libraries;
        existingVaults = result.existingVaults;
        select.empty();
        for (const library of libraries) select.createEl("option", { text: library.name, value: library.id });
        select.disabled = false;
        const preferred = (_a2 = this.plugin.settings.storage) == null ? void 0 : _a2.libraryId;
        libraryId = ((_b2 = libraries.find((item) => item.id === preferred)) == null ? void 0 : _b2.id) || ((_c2 = libraries[0]) == null ? void 0 : _c2.id) || "";
        select.value = libraryId;
        libraryName = ((_d = libraries.find((item) => item.id === libraryId)) == null ? void 0 : _d.name) || "";
        button.setButtonText("Reload");
        existingSelect.empty();
        existingSelect.createEl("option", { text: existingVaults.length ? "Create or use the location below" : "No existing vaults found", value: "-1" });
        for (const [index, vault] of existingVaults.entries()) existingSelect.createEl("option", { text: `${vault.vaultName} \u2014 ${vault.libraryName}:${vault.basePath}`, value: String(index) });
        existingSelect.disabled = !existingVaults.length;
        if (existingVaults.length === 1) {
          existingSelect.value = "0";
          useExisting(0);
        }
        if (!libraries.length) new import_obsidian3.Notice("This Seafile account has no accessible libraries.");
      } catch (error) {
        new import_obsidian3.Notice(`Unable to load libraries: ${error instanceof Error ? error.message : String(error)}`, 1e4);
        button.setButtonText("Try again");
      } finally {
        button.setDisabled(false);
      }
    }));
    new import_obsidian3.Setting(this.contentEl).setName("Folder in library").setDesc("Your readable 1:1 Obsidian vault is stored here. Gib Sync keeps synchronization metadata in a hidden .gib-sync subfolder.").addText((text) => {
      pathInput = text.inputEl;
      text.setValue(basePath).onChange((value) => {
        basePath = value.trim();
        existingVaultId = void 0;
        existingSelect.value = "-1";
      });
    });
    new import_obsidian3.Setting(this.contentEl).setName("Vault name").addText((text) => {
      vaultInput = text.inputEl;
      text.setValue(vaultName).onChange((value) => vaultName = value.trim());
    });
    new import_obsidian3.Setting(this.contentEl).setName("Device name").addText((text) => text.setValue(deviceName).onChange((value) => deviceName = value.trim()));
    onboardingChoice(this.contentEl, (mode) => onboardingMode = mode);
    new import_obsidian3.Setting(this.contentEl).addButton((button) => button.setCta().setButtonText("Connect").onClick(async () => {
      if (!libraryId) {
        new import_obsidian3.Notice("Load and select a Seafile library first.");
        return;
      }
      button.setDisabled(true).setButtonText("Connecting\u2026");
      try {
        await this.plugin.verifyServerBeforeSetup(server);
        const setup = await this.plugin.api.setup(server, { vaultName, deviceName, seafileUrl, seafileUsername: username, seafilePassword: password, libraryId, libraryName, basePath, existingVaultId });
        await this.plugin.acceptSetup(setup, deviceName, onboardingMode);
        this.close();
        new import_obsidian3.Notice(this.plugin.settings.paused ? "Gib Sync connected. Resume this device when ready." : "Gib Sync connected. Starting first sync\u2026");
        if (!this.plugin.settings.paused) void this.plugin.runSync();
      } catch (error) {
        new import_obsidian3.Notice(`Setup failed: ${error instanceof Error ? error.message : String(error)}`, 1e4);
        button.setDisabled(false).setButtonText("Connect");
      }
    }));
  }
  onClose() {
    this.contentEl.empty();
  }
};
var QuickCodeDisplayModal = class extends import_obsidian3.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
    __publicField(this, "timer", null);
    __publicField(this, "expiresAt", 0);
    __publicField(this, "refreshing", false);
    __publicField(this, "closed", false);
    __publicField(this, "generation", 0);
    __publicField(this, "retryAt", 0);
    __publicField(this, "refreshError", "");
    __publicField(this, "codeEl");
    __publicField(this, "statusEl");
    __publicField(this, "approvals");
    __publicField(this, "approvalsLoading", false);
    __publicField(this, "nextApprovalCheck", 0);
    __publicField(this, "approvalRows", /* @__PURE__ */ new Map());
  }
  async onOpen() {
    mobileContent(this.contentEl);
    this.closed = false;
    const generation = ++this.generation;
    this.refreshing = false;
    this.expiresAt = 0;
    this.retryAt = 0;
    this.refreshError = "";
    this.setTitle("Connect another device");
    this.contentEl.createEl("p", { text: "Enter this five-digit code in Gib Sync on the other device." });
    this.codeEl = this.contentEl.createDiv({ cls: "gib-sync-quick-code", text: "-----" });
    this.statusEl = this.contentEl.createEl("p", { cls: "gib-sync-muted", attr: { role: "status", "aria-live": "polite" } });
    const retry = this.contentEl.createEl("button", { text: "New code", attr: { type: "button" } });
    retry.onclick = () => void this.refresh();
    this.approvals = this.contentEl.createDiv({ cls: "gib-sync-device-requests" });
    await this.refresh();
    if (!this.closed && generation === this.generation) this.timer = window.setInterval(() => this.tick(), 1e3);
  }
  async refresh() {
    if (this.refreshing || this.closed) return;
    const generation = this.generation;
    this.refreshing = true;
    this.statusEl.setText("Getting a fresh code\u2026");
    try {
      const pairing = await this.plugin.api.createPairing();
      if (this.closed || generation !== this.generation) return;
      if (pairing.requiresConfirmation !== true) throw new Error("Update the server before connecting devices securely. Existing sync is unaffected.");
      const expiresAt = Date.parse(pairing.expiresAt);
      if (!Number.isFinite(expiresAt) || expiresAt <= Date.now()) throw new Error("The server returned an expired code. Try again.");
      this.codeEl.setText(pairing.code);
      this.codeEl.setAttr("aria-label", `Quick code ${pairing.code}`);
      this.expiresAt = expiresAt;
      this.refreshError = "";
      this.retryAt = 0;
    } catch (error) {
      if (!this.closed && generation === this.generation) {
        this.refreshError = `Code unavailable: ${error instanceof Error ? error.message : String(error)}. Retrying automatically.`;
        this.retryAt = Date.now() + 15e3;
        this.statusEl.setText(this.refreshError);
      }
    } finally {
      if (generation === this.generation) {
        this.refreshing = false;
        this.tick();
      }
    }
  }
  tick() {
    if (this.closed || this.refreshing) return;
    if (Date.now() >= this.nextApprovalCheck) void this.loadApprovals();
    const seconds = Math.max(0, Math.ceil((this.expiresAt - Date.now()) / 1e3));
    if (!seconds) {
      this.codeEl.setText("-----");
      this.codeEl.setAttr("aria-label", "No valid quick code");
      if (this.refreshError) this.statusEl.setText(this.refreshError);
      else this.statusEl.setText("Code expired; getting a new one\u2026");
      if (Date.now() >= this.retryAt) void this.refresh();
      return;
    }
    if (this.refreshError) this.statusEl.setText(this.refreshError);
    else this.statusEl.setText(`Changes in ${seconds} second${seconds === 1 ? "" : "s"} \xB7 approve the matching device below.`);
  }
  async loadApprovals() {
    if (this.approvalsLoading || this.closed || typeof this.plugin.api.pendingDeviceClaims !== "function") return;
    const generation = this.generation;
    this.approvalsLoading = true;
    this.nextApprovalCheck = Date.now() + 2e3;
    try {
      const requests = await this.plugin.api.pendingDeviceClaims();
      if (this.closed || generation !== this.generation) return;
      const active = new Set(requests.map((request) => request.id));
      for (const [id, row] of this.approvalRows) if (!active.has(id)) {
        row.remove();
        this.approvalRows.delete(id);
      }
      for (const request of requests) if (!this.approvalRows.has(request.id)) {
        const row = this.approvals.createDiv({ cls: "gib-sync-device-request" });
        this.approvalRows.set(request.id, row);
        renderDeviceRequest(row, request, this.plugin, () => this.closed);
      }
    } catch (e) {
    } finally {
      this.approvalsLoading = false;
    }
  }
  onClose() {
    this.closed = true;
    this.generation++;
    if (this.timer !== null) window.clearInterval(this.timer);
    this.timer = null;
    this.contentEl.empty();
  }
};
function renderDeviceRequest(row, request, plugin, closed) {
  row.createEl("strong", { text: request.deviceName });
  row.createEl("p", { text: `Confirm ${request.confirmationCode} matches the new device.` });
  const state = row.createEl("p", { cls: "gib-sync-muted", attr: { role: "status" } }), actions = row.createDiv({ cls: "gib-sync-row-actions" });
  const decide = async (approved) => {
    for (const control of Array.from(actions.querySelectorAll("button"))) control.disabled = true;
    try {
      await plugin.api.decideDeviceClaim(request.id, approved);
      if (!closed()) {
        state.setText(approved ? "Approved. The new device can now connect." : "Request declined.");
        actions.hidden = true;
      }
    } catch (error) {
      if (!closed()) {
        state.setText(error instanceof Error ? error.message : String(error));
        for (const control of Array.from(actions.querySelectorAll("button"))) control.disabled = false;
      }
    }
  };
  actions.createEl("button", { text: "Decline", attr: { type: "button" } }).onclick = () => void decide(false);
  actions.createEl("button", { text: "Approve device", cls: "mod-cta", attr: { type: "button" } }).onclick = () => void decide(true);
}
var DeviceRequestsModal = class extends import_obsidian3.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
    __publicField(this, "closed", false);
    __publicField(this, "timer", null);
    __publicField(this, "loading", false);
    __publicField(this, "list");
    __publicField(this, "status");
    __publicField(this, "rows", /* @__PURE__ */ new Map());
  }
  onOpen() {
    mobileContent(this.contentEl);
    this.setTitle("Approve a new device");
    this.status = this.contentEl.createEl("p", { text: "Checking device requests\u2026", attr: { role: "status" } });
    this.list = this.contentEl.createDiv();
    void this.refresh();
    this.timer = window.setInterval(() => void this.refresh(), 2e3);
  }
  async refresh() {
    if (this.closed || this.loading) return;
    this.loading = true;
    try {
      const requests = await this.plugin.api.pendingDeviceClaims();
      if (this.closed) return;
      this.status.setText(requests.length ? "Only approve a device whose confirmation number you can verify." : "No device is waiting for approval.");
      const ids = new Set(requests.map((item) => item.id));
      for (const [id, row] of this.rows) if (!ids.has(id)) {
        row.remove();
        this.rows.delete(id);
      }
      for (const item of requests) if (!this.rows.has(item.id)) {
        const row = this.list.createDiv({ cls: "gib-sync-device-request" });
        this.rows.set(item.id, row);
        renderDeviceRequest(row, item, this.plugin, () => this.closed);
      }
    } catch (error) {
      if (!this.closed) this.status.setText(error instanceof Error ? error.message : String(error));
    } finally {
      this.loading = false;
    }
  }
  onClose() {
    this.closed = true;
    if (this.timer !== null) window.clearInterval(this.timer);
    this.contentEl.empty();
  }
};
var DeviceApprovalWaitModal = class extends import_obsidian3.Modal {
  constructor(app, plugin, server, claim, done) {
    super(app);
    this.plugin = plugin;
    this.server = server;
    this.claim = claim;
    this.done = done;
    __publicField(this, "closed", false);
    __publicField(this, "settled", false);
    __publicField(this, "timer", null);
    __publicField(this, "status");
  }
  onOpen() {
    mobileContent(this.contentEl);
    this.setTitle("Approve on your connected device");
    this.contentEl.createEl("p", { text: `Compare this number with the request on the connected device:` });
    this.contentEl.createDiv({ cls: "gib-sync-quick-code", text: this.claim.confirmationCode });
    this.status = this.contentEl.createEl("p", { text: "Waiting for approval\u2026", attr: { role: "status", "aria-live": "polite" } });
    this.contentEl.createEl("button", { text: "Cancel", attr: { type: "button" } }).onclick = () => this.close();
    void this.poll();
  }
  async poll() {
    if (this.closed) return;
    if (Date.parse(this.claim.expiresAt) <= Date.now()) {
      this.finish(new Error("Device approval expired. Request a new quick code."));
      return;
    }
    try {
      const response = await this.plugin.api.pollDeviceClaim(this.server, this.claim.ticket);
      if (this.closed) {
        if (response.status === "approved") void this.plugin.api.cancelDeviceClaim(this.server, this.claim.ticket).catch(() => {
        });
        return;
      }
      if (response.status === "approved") {
        this.finish(response);
        return;
      }
    } catch (error) {
      if (this.closed) return;
      if (error.status === 410) {
        this.finish(error);
        return;
      }
      this.status.setText("Connection interrupted. Still waiting safely for approval\u2026");
    }
    if (!this.closed) this.timer = window.setTimeout(() => void this.poll(), 1500);
  }
  finish(result) {
    if (this.settled) return;
    this.settled = true;
    this.done(result);
    this.close();
  }
  onClose() {
    this.closed = true;
    if (this.timer !== null) window.clearTimeout(this.timer);
    if (!this.settled) {
      this.settled = true;
      void this.plugin.api.cancelDeviceClaim(this.server, this.claim.ticket).catch(() => {
      });
      this.done(new Error("Device connection cancelled."));
    }
    this.contentEl.empty();
  }
};
var QuickCodeEntryModal = class extends import_obsidian3.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
  }
  onOpen() {
    mobileContent(this.contentEl);
    this.setTitle("Enter quick code");
    let server = this.plugin.settings.serverUrl || "";
    let code = "";
    let deviceName = defaultDeviceName();
    let onboardingMode = "preserve-local";
    this.contentEl.createEl("p", { text: "On an already connected device, choose \u201CShow quick code,\u201D then type that temporary code here." });
    new import_obsidian3.Setting(this.contentEl).setName("Gib Sync server").addText((text) => text.setPlaceholder("https://sync.example.com").setValue(server).onChange((value) => server = value.trim()));
    new import_obsidian3.Setting(this.contentEl).setName("Quick code").setDesc("Five numbers. The code changes every 60 seconds.").addText((text) => {
      text.setPlaceholder("12345").onChange((value) => code = value);
      text.inputEl.inputMode = "numeric";
      text.inputEl.pattern = "[0-9]*";
      text.inputEl.autocomplete = "one-time-code";
      text.inputEl.maxLength = 5;
    });
    new import_obsidian3.Setting(this.contentEl).setName("Device name").addText((text) => text.setValue(deviceName).onChange((value) => deviceName = value.trim()));
    onboardingChoice(this.contentEl, (mode) => onboardingMode = mode);
    new import_obsidian3.Setting(this.contentEl).addButton((button) => button.setCta().setButtonText("Connect").onClick(async () => {
      button.setDisabled(true).setButtonText("Connecting\u2026");
      try {
        await this.plugin.claimQuickCode(server, code, deviceName, onboardingMode);
        this.close();
        new import_obsidian3.Notice(this.plugin.settings.paused ? "Device connected. Resume this device when ready." : "Device connected. Starting first sync\u2026");
        if (!this.plugin.settings.paused) void this.plugin.runSync();
      } catch (error) {
        new import_obsidian3.Notice(`Quick-code setup failed: ${error instanceof Error ? error.message : String(error)}`, 1e4);
        button.setDisabled(false).setButtonText("Connect");
      }
    }));
  }
  onClose() {
    this.contentEl.empty();
  }
};
var SelectiveRestoreModal = class extends import_obsidian3.Modal {
  constructor(app, plugin, snapshot, restored) {
    super(app);
    this.plugin = plugin;
    this.snapshot = snapshot;
    this.restored = restored;
  }
  async onOpen() {
    mobileContent(this.contentEl);
    this.setTitle("Restore selected files");
    this.contentEl.empty();
    const status = this.contentEl.createEl("p", { text: "Loading changed files\u2026" });
    try {
      const plan = await this.plugin.api.selectiveRestorePlan(this.snapshot.id);
      status.remove();
      if (!plan.changes.length) {
        this.contentEl.createEl("p", { text: "This snapshot already matches the current vault." });
        return;
      }
      const selected = /* @__PURE__ */ new Set(), controls = this.contentEl.createDiv({ cls: "gib-sync-row-actions" }), search = this.contentEl.createEl("input", { cls: "gib-sync-selective-restore-search" }), list = this.contentEl.createDiv({ cls: "gib-sync-selective-restore-list" });
      search.type = "search";
      search.placeholder = "Filter changed paths";
      const rows = /* @__PURE__ */ new Map(), render = () => {
        const query = search.value.trim().toLowerCase(), matches = plan.changes.filter((change) => {
          var _a;
          return !query || change.path.toLowerCase().includes(query) || ((_a = change.previousPath) != null ? _a : "").toLowerCase().includes(query);
        });
        list.empty();
        rows.clear();
        for (const change of matches.slice(0, 400)) this.changeRow(list, change, selected, rows);
        if (matches.length > 400) list.createDiv({ cls: "gib-sync-muted", text: `Showing 400 of ${matches.length} matches. Refine the filter to see a specific path.` });
      };
      const setAll = (value) => {
        selected.clear();
        if (value) for (const change of plan.changes.slice(0, 5e3)) selected.add(change.id);
        render();
      };
      controls.createEl("button", { text: plan.changes.length > 5e3 ? "Select first 5,000" : "Select all" }).onclick = () => setAll(true);
      controls.createEl("button", { text: "Clear" }).onclick = () => setAll(false);
      search.oninput = render;
      render();
      const review = controls.createEl("button", { text: "Review restore", cls: "mod-cta" });
      review.onclick = async () => {
        if (!selected.size) {
          new import_obsidian3.Notice("Select at least one file change to restore.");
          return;
        }
        review.disabled = true;
        try {
          const ids = [...selected], preview = await this.plugin.api.selectiveRestorePreview(this.snapshot.id, ids), reasons = preview.assessment.reasons.length ? `

Warnings:
- ${preview.assessment.reasons.join("\n- ")}` : "";
          if (!await confirmAction(this.app, "Restore selected files", `${assessmentText(preview.assessment)}${reasons}

Only the ${preview.selectedChanges} selected historical change${preview.selectedChanges === 1 ? "" : "s"} will be applied. Current history remains available.`, "Restore selected", preview.assessment.deleted > 0)) {
            review.disabled = false;
            return;
          }
          await this.plugin.api.selectiveRestore(this.snapshot.id, ids, preview.confirmToken);
          this.close();
          this.restored();
          await this.plugin.runSync();
          new import_obsidian3.Notice(`${ids.length} selected historical change${ids.length === 1 ? "" : "s"} restored`);
        } catch (error) {
          new import_obsidian3.Notice(`Selective restore failed: ${error instanceof Error ? error.message : String(error)}`, 1e4);
          review.disabled = false;
        }
      };
    } catch (error) {
      status.setText(error instanceof Error ? error.message : String(error));
    }
  }
  changeRow(container, change, selected, rows) {
    const label = container.createEl("label", { cls: "gib-sync-selective-restore-row" }), input = label.createEl("input");
    input.type = "checkbox";
    input.checked = selected.has(change.id);
    rows.set(change.id, input);
    input.onchange = () => {
      if (input.checked) selected.add(change.id);
      else selected.delete(change.id);
    };
    label.createSpan({ text: `${change.kind}: ${change.previousPath ? `${change.previousPath} \u2192 ` : ""}${change.path}` });
  }
  onClose() {
    this.contentEl.empty();
  }
};
var HistoryModal = class extends import_obsidian3.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
  }
  async onOpen() {
    mobileContent(this.contentEl);
    this.setTitle("Gib Sync history");
    this.contentEl.empty();
    const container = this.contentEl.createDiv({ cls: "gib-sync-history" });
    container.setText("Loading\u2026");
    try {
      const history = await this.plugin.api.history();
      container.empty();
      for (const item of history) this.row(container, item);
      if (!history.length) container.setText("No snapshots yet.");
    } catch (error) {
      container.setText(error instanceof Error ? error.message : String(error));
    }
  }
  row(container, item) {
    const row = container.createDiv({ cls: "gib-sync-history-row" });
    const details = row.createDiv();
    details.createEl("strong", { text: `${item.bookmarked ? "\u2605 " : ""}${item.message}` });
    details.createEl("div", { cls: "gib-sync-muted", text: `${new Date(item.createdAt).toLocaleString()} \xB7 ${item.deviceName} \xB7 ${item.fileCount} files` });
    const actions = row.createDiv({ cls: "gib-sync-row-actions" }), bookmark = actions.createEl("button", { text: item.bookmarked ? "Unbookmark" : "Bookmark" });
    bookmark.onclick = async () => {
      bookmark.disabled = true;
      try {
        if (item.bookmarked) await this.plugin.api.unbookmark(item.id);
        else {
          const label = await promptText(this.app, "Bookmark snapshot", "Bookmark label", "Known good");
          if (label === null) {
            bookmark.disabled = false;
            return;
          }
          await this.plugin.api.bookmark(item.id, label || "Known good");
        }
        this.onOpen();
      } catch (error) {
        new import_obsidian3.Notice(error instanceof Error ? error.message : String(error));
        bookmark.disabled = false;
      }
    };
    const selected = actions.createEl("button", { text: "Restore files" });
    selected.onclick = () => new SelectiveRestoreModal(this.app, this.plugin, item, () => this.close()).open();
    const button = actions.createEl("button", { text: "Restore all" });
    button.onclick = async () => {
      button.disabled = true;
      try {
        const preview = await this.plugin.api.restorePreview(item.id);
        const reasons = preview.assessment.reasons.length ? `

Warnings:
- ${preview.assessment.reasons.join("\n- ")}` : "";
        if (!await confirmAction(this.app, "Restore snapshot", `${assessmentText(preview.assessment)}${reasons}

This creates a new snapshot and preserves current history.`, "Restore", true)) {
          button.disabled = false;
          return;
        }
        await this.plugin.api.restore(item.id, preview.confirmToken);
        this.close();
        await this.plugin.runSync();
        new import_obsidian3.Notice("Snapshot restored");
      } catch (error) {
        new import_obsidian3.Notice(`Restore failed: ${error instanceof Error ? error.message : String(error)}`, 1e4);
        button.disabled = false;
      }
    };
  }
  onClose() {
    this.contentEl.empty();
  }
};
var SafeguardReviewModal = class extends import_obsidian3.Modal {
  constructor(app, plugin, closed = () => {
  }) {
    super(app);
    this.plugin = plugin;
    this.closed = closed;
  }
  async onOpen() {
    mobileContent(this.contentEl);
    this.setTitle("Gib Sync quarantined changes");
    this.contentEl.empty();
    this.contentEl.setText("Loading\u2026");
    try {
      const items = await this.plugin.api.quarantines();
      this.contentEl.empty();
      if (!items.length) {
        this.contentEl.createEl("p", { text: "No changes are waiting for approval." });
        return;
      }
      for (const item of items) this.item(item);
    } catch (error) {
      this.contentEl.setText(error instanceof Error ? error.message : String(error));
    }
  }
  item(item) {
    const card = this.contentEl.createDiv({ cls: "gib-sync-safeguard-card" });
    card.createEl("h3", { text: `${item.deviceName} \xB7 ${item.source === "seafile" ? "Seafile/WebDAV" : "Obsidian device"}` });
    card.createEl("p", { text: assessmentText(item.assessment) });
    const reasons = card.createEl("ul");
    for (const reason of item.assessment.reasons) reasons.createEl("li", { text: reason });
    const deleted = item.changes.filter((change) => change.kind === "deleted");
    if (item.source === "seafile" && deleted.length) {
      const folders = [...new Set(deleted.map((change) => change.path.split("/")[0] || "Vault root"))], warning = card.createDiv({ cls: "gib-sync-attention-card is-warning" });
      warning.createEl("strong", { text: "External deletion requires one-time approval" });
      warning.createEl("p", { text: `Seafile reports ${deleted.length} missing file${deleted.length === 1 ? "" : "s"} (${bytes(item.assessment.bytesRemoved)}) across ${folders.slice(0, 4).join(", ")}${folders.length > 4 ? ` and ${folders.length - 4} more` : ""}. Maintenance and prior trust never approve this batch automatically.` });
    }
    const disclosure = card.createEl("details");
    disclosure.createEl("summary", { text: `Review ${item.changes.length} changed paths` });
    const list = disclosure.createEl("ul", { cls: "gib-sync-change-list" });
    for (const change of item.changes) list.createEl("li", { text: `${change.kind}: ${change.previousPath ? `${change.previousPath} \u2192 ` : ""}${change.path}` });
    const actions = card.createDiv({ cls: "gib-sync-row-actions" });
    const trustEligible = item.source === "device" && !item.assessment.deleted && !item.assessment.reasons.some((reason) => /out-of-date device|completely empty|protected path|grew unexpectedly|mostly emptied|high-entropy/i.test(reason));
    const approve = actions.createEl("button", { text: "Approve once" }), trustMinutes = 15, trust = trustEligible ? actions.createEl("button", { text: "Approve + trust 15 min" }) : null, reject = actions.createEl("button", { text: "Reject and restore" });
    const disable = () => {
      approve.disabled = true;
      if (trust) trust.disabled = true;
      reject.disabled = true;
    };
    approve.onclick = async () => {
      disable();
      try {
        await this.plugin.api.approveQuarantine(item.id);
        this.close();
        await this.plugin.runSync();
        new import_obsidian3.Notice("Quarantined changes approved");
      } catch (error) {
        new import_obsidian3.Notice(error instanceof Error ? error.message : String(error), 1e4);
        void this.onOpen();
      }
    };
    if (trust) trust.onclick = async () => {
      disable();
      try {
        await this.plugin.api.approveQuarantine(item.id, trustMinutes);
        this.close();
        await this.plugin.runSync();
        new import_obsidian3.Notice(`Changes approved; this device is in maintenance for ${trustMinutes} minutes`);
      } catch (error) {
        new import_obsidian3.Notice(error instanceof Error ? error.message : String(error), 1e4);
        void this.onOpen();
      }
    };
    reject.onclick = async () => {
      if (!await confirmAction(this.app, "Reject quarantined changes", "Reject this entire change batch and restore this device to the last accepted snapshot?", "Reject and restore", true)) return;
      disable();
      try {
        const restored = await this.plugin.rejectAndRestore(item.id);
        this.close();
        new import_obsidian3.Notice(`Changes rejected \xB7 restored ${restored.downloaded}, removed ${restored.deleted} local files, and cleaned ${restored.prunedFolders} empty folders`, 1e4);
        void this.plugin.refreshServerStatus();
      } catch (error) {
        new import_obsidian3.Notice(error instanceof Error ? error.message : String(error), 1e4);
        void this.onOpen();
      }
    };
  }
  onClose() {
    this.contentEl.empty();
    this.closed();
  }
};
var DeviceManagementModal = class extends import_obsidian3.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
  }
  async onOpen() {
    var _a, _b;
    mobileContent(this.contentEl);
    this.setTitle("Gib Sync devices");
    this.contentEl.setText("Loading\u2026");
    await this.plugin.refreshServerStatus();
    this.contentEl.empty();
    const devices = (_b = (_a = this.plugin.serverStatus) == null ? void 0 : _a.devices) != null ? _b : [];
    for (const device of devices) this.row(device);
    if (!devices.length) this.contentEl.setText("No device information available.");
  }
  row(device) {
    var _a, _b;
    const row = this.contentEl.createDiv({ cls: "gib-sync-history-row" }), details = row.createDiv();
    details.createEl("strong", { text: `${device.name}${device.current ? " (this device)" : ""}` });
    const version = device.clientVersion ? `v${device.clientVersion}` : "version unknown", compatibility = device.compatibility === "incompatible" ? "update required" : device.compatibility === "update-available" ? "update available" : device.compatibility === "compatible" ? "compatible" : "compatibility unknown";
    const head = (_b = (_a = this.plugin.serverStatus) == null ? void 0 : _a.head) == null ? void 0 : _b.id, confirmed = Boolean(head && device.acknowledgedSnapshotId === head);
    details.createEl("div", { text: confirmed ? "Latest accepted version confirmed" : device.acknowledgedSnapshotId ? "Waiting for the latest version" : "Latest version not confirmed yet" });
    details.createEl("div", { cls: "gib-sync-muted", text: `Last seen ${when(device.lastSeenAt)} \xB7 ${version} \xB7 ${compatibility} \xB7 ${device.ready ? "Connected" : "Restricted until first download"}${device.clockSkewMs ? ` \xB7 clock skew ${Math.round(device.clockSkewMs / 6e4)} min` : ""}${device.revokedAt ? " \xB7 revoked" : ""}` });
    if (!device.revokedAt) {
      const button = row.createEl("button", { text: "Revoke" });
      button.onclick = async () => {
        if (!await confirmAction(this.app, "Revoke device", `Revoke ${device.name}? It will immediately lose access to this vault.`, "Revoke", true)) return;
        button.disabled = true;
        try {
          await this.plugin.api.revokeDevice(device.id);
          new import_obsidian3.Notice(`${device.name} revoked`);
          if (device.current) this.close();
          else void this.onOpen();
        } catch (error) {
          new import_obsidian3.Notice(error instanceof Error ? error.message : String(error), 1e4);
          button.disabled = false;
        }
      };
    }
  }
  onClose() {
    this.contentEl.empty();
  }
};
var LocalRecoveryModal = class extends import_obsidian3.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
    __publicField(this, "closed", false);
  }
  async onOpen() {
    var _a;
    this.closed = false;
    mobileContent(this.contentEl);
    this.setTitle("Recovery copies on this device");
    this.contentEl.createEl("p", { text: "Originals replaced or deleted during sync are kept here. These copies stay on this device, outside normal synchronization. Preview a copy before restoring anything; accepted server versions are available separately in Version history." });
    const list = this.contentEl.createDiv({ cls: "gib-sync-history" }), status = list.createEl("p", { text: "Looking for recovery copies\u2026" });
    try {
      const adapter = this.app.vault.adapter, root2 = ".gib-sync/local-recovery", configDir = (_a = this.app.vault.configDir) != null ? _a : ".obsidian", physical = (path) => path.startsWith(".obsidian/") ? `${configDir}${path.slice(".obsidian".length)}` : path, packages = typeof this.plugin.listPackageRecoveryOriginals === "function" ? await this.plugin.listPackageRecoveryOriginals() : [], roots = [root2, ...packages.map((item) => item.path).filter(isSafeVaultPath)], pending = [], files = [];
      let visited = 0;
      for (const directory of roots) if (await adapter.exists(physical(directory))) pending.push({ logical: directory, root: directory });
      while (pending.length && files.length < 500 && visited < 1e3 && !this.closed) {
        const directory = pending.shift(), native = physical(directory.logical), listing = await adapter.list(native), logical = (path) => `${directory.logical}${path.slice(native.length)}`;
        visited++;
        for (const folder of listing.folders) {
          if (pending.length + visited >= 1e3) break;
          if (folder.startsWith(`${native}/`) && isSafeVaultPath(folder)) pending.push({ logical: logical(folder), root: directory.root });
        }
        for (const file of listing.files) {
          if (files.length >= 500) break;
          if (file.startsWith(`${native}/`) && isSafeVaultPath(file)) files.push(logical(file));
        }
        if (visited % 20 === 0) await new Promise((resolve) => window.setTimeout(resolve, 0));
      }
      if (this.closed) return;
      status.setText(files.length ? `${files.length >= 500 ? "Showing the first 500" : `${files.length}${pending.length ? "+" : ""}`} recovery copies. Originals are kept until you choose to remove them.` : "No local recovery copies yet.");
      for (const path of [...new Set(files)].sort().slice(0, 500)) {
        const packageOriginal = packages.find((item) => path.startsWith(`${item.path}/`)), label = packageOriginal ? `Plugin original \xB7 ${packageOriginal.packageRoot.split("/").pop()}/${path.slice(packageOriginal.path.length + 1)}` : path.slice(root2.length + 1), row = list.createEl("details", { cls: "gib-sync-recovery-row" });
        row.createEl("summary", { text: label });
        const preview = row.createDiv({ cls: "gib-sync-recovery-preview" });
        let loaded = false;
        row.addEventListener("toggle", () => {
          if (!row.open || loaded || this.closed) return;
          loaded = true;
          void (async () => {
            try {
              const stat = await adapter.stat(physical(path));
              if (this.closed) return;
              if (!stat || stat.type !== "file") {
                preview.setText("This recovery copy is no longer available.");
                return;
              }
              if (stat.size <= 128 * 1024 && /\.(?:md|txt|json|canvas|ya?ml|css)$/i.test(path)) {
                const content2 = await adapter.read(physical(path));
                if (!this.closed) preview.createEl("pre", { text: content2 });
              } else preview.createEl("p", { text: `${bytes(stat.size)} \xB7 preview is limited to small text files.` });
              if (this.closed) return;
              const restore = preview.createEl("button", { text: "Restore a protected copy", attr: { type: "button" } });
              restore.onclick = async () => {
                if (!await confirmAction(this.app, "Restore recovery copy", "Restore this original through the sync engine? Current contents will also be retained, and the recovery original will not be deleted.", "Restore copy")) return;
                restore.disabled = true;
                try {
                  await this.plugin.restoreLocalRecovery(path);
                  if (!this.closed) preview.createEl("p", { text: "Restored. The recovery original is still kept." });
                } catch (error) {
                  if (!this.closed) preview.createEl("p", { text: error instanceof Error ? error.message : String(error) });
                } finally {
                  restore.disabled = false;
                }
              };
            } catch (error) {
              if (!this.closed) preview.setText(error instanceof Error ? error.message : String(error));
            }
          })();
        });
      }
    } catch (error) {
      if (!this.closed) status.setText(error instanceof Error ? error.message : String(error));
    }
  }
  onClose() {
    this.closed = true;
    this.contentEl.empty();
  }
};
var ConflictInboxModal = class extends import_obsidian3.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
    __publicField(this, "closed", false);
    __publicField(this, "generation", 0);
    __publicField(this, "list");
    __publicField(this, "detail");
    __publicField(this, "status");
    __publicField(this, "records", []);
  }
  async onOpen() {
    mobileContent(this.contentEl);
    this.modalEl.addClass("gib-sync-conflict-modal");
    this.setTitle("Conflicts & recovery");
    this.contentEl.createEl("p", { text: "Both originals are safe. Compare the actual versions, choose the result, or keep both. Decisions can be undone while those files have no newer edits." });
    this.status = this.contentEl.createEl("p", { text: "Loading preserved versions\u2026", attr: { role: "status", "aria-live": "polite" } });
    const search = this.contentEl.createEl("input", { attr: { type: "search", placeholder: "Find a file", "aria-label": "Find conflict" } });
    this.list = this.contentEl.createDiv({ cls: "gib-sync-conflict-list" });
    this.detail = this.contentEl.createDiv({ cls: "gib-sync-conflict-detail" });
    search.oninput = () => this.renderList(search.value);
    await this.refresh();
  }
  async refresh() {
    const generation = ++this.generation;
    try {
      const records2 = await this.plugin.listConflictInbox();
      if (this.closed || generation !== this.generation) return;
      this.records = records2;
      this.status.setText(records2.length ? `${records2.filter((item) => item.state === "open" && item.actionRequired !== false).length} need a decision \xB7 originals preserved` : "No recorded conflicts. Local recovery copies and version history are available in settings.");
      this.renderList("");
    } catch (error) {
      if (!this.closed) this.status.setText(error instanceof Error ? error.message : String(error));
    }
  }
  renderList(query) {
    this.list.empty();
    const matches = this.records.filter((item) => !query || item.path.toLowerCase().includes(query.toLowerCase()));
    for (const item of matches.slice(0, 100)) {
      const button = this.list.createEl("button", { text: `${item.path} \xB7 ${item.state === "resolved" ? "Resolved" : item.actionRequired === false ? "Auto-merged \xB7 originals kept" : "Review"}`, attr: { type: "button" } });
      button.onclick = () => void this.preview(item);
    }
    if (matches.length > 100) this.list.createEl("p", { text: `Showing 100 of ${matches.length}. Refine the search to find another record.` });
  }
  async preview(item) {
    var _a, _b, _c, _d;
    const generation = ++this.generation;
    this.detail.empty();
    this.detail.createEl("h3", { text: item.path });
    const state = this.detail.createEl("p", { text: "Verifying preserved versions\u2026", attr: { role: "status" } });
    try {
      const preview = await this.plugin.previewConflict(item.id);
      if (this.closed || generation !== this.generation) return;
      state.setText(`${preview.item.reason} \xB7 ${when(preview.item.createdAt)}`);
      const versions = preview.item.versions;
      const panes = this.detail.createDiv({ cls: "gib-sync-conflict-panes" });
      for (const side of versions) {
        const pane = panes.createDiv();
        pane.createEl("strong", { text: side.label });
        pane.createEl("p", { cls: "gib-sync-muted", text: `${(_a = side.deviceName) != null ? _a : "Unknown device"} \xB7 ${side.deleted ? "Deleted" : bytes(side.size)}${side.revisionId ? ` \xB7 revision ${side.revisionId.slice(0, 8)}` : ""}` });
        const text = preview.texts.find((value) => value.id === side.id);
        pane.createEl("pre", { text: side.deleted ? "This version deleted the file. It is not an empty note." : (_b = text == null ? void 0 : text.text) != null ? _b : "Binary or large file. The complete original is preserved." });
        if (text == null ? void 0 : text.truncated) pane.createEl("small", { text: "Preview shortened; the complete file is still safe." });
      }
      const texts = versions.slice(0, 2).map((side) => preview.texts.find((value) => value.id === side.id)), canCombine = texts.length === 2 && texts.every((value) => value && typeof value.text === "string" && !value.truncated);
      if (canCombine) {
        const rows = conflictLineComparison(texts[0].text, texts[1].text), comparison = this.detail.createDiv({ cls: "gib-sync-conflict-diff", attr: { "aria-label": "Side by side differences" } });
        for (const row of rows) {
          const line = comparison.createDiv({ cls: row.changed ? "is-changed" : "" });
          line.createEl("pre", { text: row.left });
          line.createEl("pre", { text: row.right });
        }
        this.detail.createEl("p", { cls: "gib-sync-muted", text: `${rows.filter((row) => row.changed).length} changed displayed lines \xB7 diff is limited to 400 lines.` });
      }
      if (item.state === "resolved") {
        const undo = this.detail.createEl("button", { text: "Undo this decision", attr: { type: "button" } });
        undo.disabled = !((_c = item.resolution) == null ? void 0 : _c.undoable);
        undo.onclick = async () => {
          undo.disabled = true;
          try {
            await this.plugin.undoConflict(item.id);
            await this.refresh();
            this.detail.empty();
          } catch (error) {
            state.setText(error instanceof Error ? error.message : String(error));
            undo.disabled = false;
          }
        };
        if (!((_d = item.resolution) == null ? void 0 : _d.undoable)) this.detail.createEl("p", { text: "A newer edit prevents automatic undo. Older originals remain in version history." });
        return;
      }
      const actions = this.detail.createDiv({ cls: "gib-sync-row-actions" });
      let combined = null;
      const resolve = async (choice) => {
        if (choice === "combine" && !combined) {
          combined = this.detail.createEl("textarea", { cls: "gib-sync-conflict-combine", attr: { "aria-label": "Combined result" } });
          combined.value = texts[0].text;
          this.detail.createEl("p", { text: "Edit the combined result above, then choose Save combined. Both originals remain in recovery." });
          const save = actions.createEl("button", { text: "Save combined", cls: "mod-cta" });
          save.onclick = () => void apply("combine");
          return;
        }
        await apply(choice);
      };
      const apply = async (choice) => {
        for (const button of Array.from(actions.querySelectorAll("button"))) button.disabled = true;
        try {
          await this.plugin.resolveConflict(item.id, choice, combined == null ? void 0 : combined.value);
          if (!this.closed) {
            state.setText("Decision saved. Both originals remain recoverable.");
            await this.refresh();
            this.detail.empty();
          }
        } catch (error) {
          if (!this.closed) {
            state.setText(error instanceof Error ? error.message : String(error));
            for (const button of Array.from(actions.querySelectorAll("button"))) button.disabled = false;
          }
        }
      };
      for (const [choice, label] of [["this", "Keep this version"], ["other", "Keep the other version"], ["combine", "Combine\u2026"], ["both", "Keep both"]]) {
        const button = actions.createEl("button", { text: label, attr: { type: "button" } });
        button.disabled = choice === "combine" && !canCombine;
        button.onclick = () => void resolve(choice);
      }
    } catch (error) {
      if (!this.closed && generation === this.generation) state.setText(error instanceof Error ? error.message : String(error));
    }
  }
  onClose() {
    this.closed = true;
    this.generation++;
    this.contentEl.empty();
  }
};
var DeviceDiagnosticsModal = class extends import_obsidian3.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
    __publicField(this, "probe", new DeviceLifecycleProbe());
    __publicField(this, "activity", new DeviceSyncActivityProbe());
    __publicField(this, "controller", new AbortController());
    __publicField(this, "report", null);
    __publicField(this, "unsubscribe", null);
    __publicField(this, "testing", false);
  }
  onOpen() {
    mobileContent(this.contentEl);
    this.setTitle("Device readiness test");
    this.probe.start();
    this.activity.start(this.probe);
    this.activity.observe(this.plugin.liveStatus);
    this.unsubscribe = this.plugin.subscribeStatus(() => this.activity.observe(this.plugin.liveStatus));
    this.contentEl.createEl("p", { text: "This separately measures idle frames, frames during generated 1 MB native file work, and frames during a real sync while this window stays open. Background and return during an observed sync to check resume. A small synthetic test does not certify a large vault. Reports contain timing and phase counts only, never content, paths, identity, or credentials." });
    const status = this.contentEl.createEl("p", { text: "Ready", attr: { role: "status" } }), run = this.contentEl.createEl("button", { text: "Run generated device test", attr: { type: "button" } }), sync = this.contentEl.createEl("button", { text: "Run observed sync", attr: { type: "button" } }), copy = this.contentEl.createEl("button", { text: "Copy safe test report", attr: { type: "button" } });
    copy.disabled = true;
    run.onclick = async () => {
      if (this.plugin.liveStatus.running || this.testing) {
        status.setText("Wait for this sync to finish before generated testing.");
        return;
      }
      this.testing = true;
      run.disabled = true;
      sync.disabled = true;
      status.setText("Testing native streaming and interface responsiveness\u2026");
      try {
        this.report = await runDeviceProbe(this.app.vault.adapter, this.plugin.manifest.version, import_obsidian3.Platform.isIosApp ? "ios" : import_obsidian3.Platform.isAndroidApp ? "android" : "desktop", this.probe, this.controller.signal, this.activity);
        if (!this.controller.signal.aborted) {
          status.setText("Generated test complete. Observe a real sync for representative measurements, then copy the report.");
          copy.disabled = false;
        }
      } catch (error) {
        if (!this.controller.signal.aborted) status.setText(error instanceof Error ? error.message : String(error));
      } finally {
        this.testing = false;
        run.disabled = false;
        sync.disabled = false;
      }
    };
    sync.onclick = async () => {
      if (this.testing || this.plugin.liveStatus.running) {
        status.setText("Already observing the current work.");
        return;
      }
      sync.disabled = true;
      status.setText("Observing real sync. You can background Obsidian and return.");
      try {
        const complete = await this.plugin.runSync();
        if (!this.controller.signal.aborted) status.setText(complete ? "Observed sync completed. Its responsiveness and lifecycle counts are included in the report." : "Sync did not finish; observed timing is still retained. Check the normal sync status.");
      } finally {
        sync.disabled = false;
      }
    };
    copy.onclick = async () => {
      if (!this.report) return;
      const actualSync = this.activity.snapshot(), report = { ...this.report, lifecycle: { ...this.probe.counts }, responsiveness: { ...this.report.responsiveness, actualSync }, evidence: { ...this.report.evidence, syntheticOnly: actualSync.startedRuns === 0, realRunObserved: actualSync.startedRuns > 0 } }, copied = await copyText(JSON.stringify(report, null, 2));
      if (!this.controller.signal.aborted) status.setText(copied ? "Safe device test report copied." : "Clipboard unavailable.");
    };
  }
  onClose() {
    var _a;
    this.controller.abort();
    (_a = this.unsubscribe) == null ? void 0 : _a.call(this);
    this.unsubscribe = null;
    this.activity.stop();
    this.probe.stop();
    this.contentEl.empty();
  }
};
var SafeguardSettingsModal = class extends import_obsidian3.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
  }
  async onOpen() {
    mobileContent(this.contentEl);
    this.setTitle("Mass-change safeguards");
    this.contentEl.setText("Loading\u2026");
    try {
      const state = await this.plugin.api.safeguards(), policy = { ...state.policy, protectedPaths: [...state.policy.protectedPaths] };
      this.contentEl.empty();
      this.contentEl.createEl("p", { text: "Balanced and strict modes use server-maintained thresholds. Custom mode uses every value below. Protected paths are enforced in every mode." });
      const maintenance = new import_obsidian3.Setting(this.contentEl).setName("Vault maintenance session").setDesc(state.trustedUntil ? `Mass changes from this device are allowed until ${when(state.trustedUntil)}. Snapshot history and conflict handling remain active.` : "Temporarily allow intentional bulk edits, conflict-copy cleanup, and reorganizing from this device. Protection resumes automatically after 60 minutes.");
      maintenance.addButton((button) => button.setButtonText(state.trustedUntil ? "End maintenance" : "Start 60-minute maintenance").setWarning().onClick(async () => {
        const starting = !state.trustedUntil;
        if (starting && !await confirmAction(this.app, "Start vault maintenance", "Allow mass changes from this device for 60 minutes? Use this only while intentionally cleaning up or reorganizing the vault. Other devices remain protected and version history continues.", "Start maintenance", true)) return;
        button.setDisabled(true);
        try {
          await this.plugin.api.setMaintenance(starting ? 60 : 0);
          this.close();
          await this.plugin.refreshServerStatus();
          new import_obsidian3.Notice(starting ? "Vault maintenance started for 60 minutes" : "Vault maintenance ended");
        } catch (error) {
          new import_obsidian3.Notice(error instanceof Error ? error.message : String(error), 1e4);
          button.setDisabled(false);
        }
      }));
      new import_obsidian3.Setting(this.contentEl).setName("Protection mode").addDropdown((dropdown) => dropdown.addOption("balanced", "Balanced").addOption("strict", "Strict").addOption("custom", "Custom").setValue(policy.mode).onChange((value) => policy.mode = value));
      const number = (name, key, description) => new import_obsidian3.Setting(this.contentEl).setName(name).setDesc(description).addText((text) => text.setValue(String(policy[key])).onChange((value) => {
        const parsed = Number(value);
        if (Number.isFinite(parsed)) policy[key] = parsed;
      }));
      number("Deletion count", "deletionCount", "Quarantine at this many deletions.");
      number("Small-vault deletion count", "smallVaultDeletionCount", "Minimum deletions before the percentage rule applies.");
      number("Small-vault deletion percent", "smallVaultDeletionPercent", "Percentage of existing files deleted.");
      number("Total changed files", "changedCount", "Quarantine at this many creates, edits, deletes, or moves.");
      number("Vault changed percent", "changedPercent", "Percentage of the vault affected.");
      number("Folder impact count", "folderImpactCount", "Files removed or moved from one top-level folder.");
      number("Single-file growth bytes", "fileGrowthBytes", "Unexpected absolute growth for one file.");
      number("Single-file growth percent", "fileGrowthPercent", "Unexpected relative growth for one file.");
      number("Clock-skew warning minutes", "clockSkewMinutes", "Warn when a device clock differs from the server.");
      new import_obsidian3.Setting(this.contentEl).setName("Protected paths").setDesc("One vault-relative file or folder per line. Deletion always requires approval.").addTextArea((area) => area.setValue(policy.protectedPaths.join("\n")).onChange((value) => policy.protectedPaths = value.split("\n").map((line) => line.trim()).filter(Boolean)));
      new import_obsidian3.Setting(this.contentEl).addButton((button) => button.setCta().setButtonText("Save safeguards").onClick(async () => {
        button.setDisabled(true);
        try {
          await this.plugin.api.updateSafeguardPolicy(policy);
          this.close();
          await this.plugin.refreshServerStatus();
          new import_obsidian3.Notice("Safeguards updated");
        } catch (error) {
          new import_obsidian3.Notice(error instanceof Error ? error.message : String(error), 1e4);
          button.setDisabled(false);
        }
      }));
    } catch (error) {
      this.contentEl.setText(error instanceof Error ? error.message : String(error));
    }
  }
  onClose() {
    this.contentEl.empty();
  }
};
var NativeSyncConflictModal = class extends import_obsidian3.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
  }
  onOpen() {
    mobileContent(this.contentEl);
    this.modalEl.addClass("gib-sync-native-sync-modal");
    this.setTitle("Obsidian Sync must be disabled");
    this.contentEl.createEl("p", { text: "Gib Sync has paused all scheduled and incoming synchronization because the Obsidian Sync core plugin is enabled. Running two sync engines against the same vault can create duplicate, conflicting, or deleted files." });
    this.contentEl.createEl("p", { text: "Disable Sync under Core plugins, then return here and check again. Gib Sync will also detect the change automatically." });
    new import_obsidian3.Setting(this.contentEl).addButton((button) => button.setCta().setButtonText("Open Core plugins").onClick(() => this.plugin.openCorePluginSettings())).addButton((button) => button.setButtonText("Check again").onClick(async () => {
      button.setDisabled(true);
      if (!await this.plugin.checkObsidianSyncProtection()) {
        this.close();
        new import_obsidian3.Notice("Obsidian Sync is disabled; Gib Sync resumed.");
      } else button.setDisabled(false);
    }));
  }
  onClose() {
    this.contentEl.empty();
  }
};
var StatusOverviewModal = class extends import_obsidian3.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
    __publicField(this, "unsubscribe", null);
    __publicField(this, "hero");
    __publicField(this, "icon");
    __publicField(this, "overviewTitleEl");
    __publicField(this, "descriptionEl");
    __publicField(this, "metaEl");
    __publicField(this, "progress");
    __publicField(this, "progressValue");
    __publicField(this, "primary");
    __publicField(this, "pause");
  }
  onOpen() {
    mobileContent(this.contentEl);
    this.modalEl.addClass("gib-sync-status-modal");
    this.setTitle("Sync status");
    this.hero = this.contentEl.createDiv({ cls: "gib-sync-status-overview" });
    this.icon = this.hero.createSpan({ cls: "gib-sync-status-overview-icon" });
    this.icon.setAttr("aria-hidden", "true");
    const copy = this.hero.createDiv({ cls: "gib-sync-status-overview-copy" });
    this.overviewTitleEl = copy.createEl("strong");
    this.descriptionEl = copy.createDiv({ cls: "gib-sync-status-overview-description" });
    this.metaEl = copy.createEl("small", { cls: "gib-sync-status-overview-meta" });
    this.progress = this.contentEl.createDiv({ cls: "gib-sync-progress", attr: { role: "progressbar", "aria-label": "Sync progress", "aria-valuemin": "0", "aria-valuemax": "100" } });
    this.progressValue = this.progress.createDiv({ cls: "gib-sync-progress-value" });
    const actions = this.contentEl.createDiv({ cls: "gib-sync-status-overview-actions" });
    this.primary = actions.createEl("button", { cls: "mod-cta" });
    this.pause = actions.createEl("button");
    this.pause.onclick = () => void this.plugin.setPaused(!this.plugin.settings.paused);
    const details = actions.createEl("button", { text: "Settings" });
    details.onclick = () => this.openSettings();
    this.render();
    this.unsubscribe = this.plugin.subscribeStatus(() => this.render());
    if (this.plugin.settings.deviceToken) void this.plugin.refreshServerStatus();
  }
  openSettings() {
    var _a;
    this.close();
    const control = this.app.setting;
    (_a = control == null ? void 0 : control.open) == null ? void 0 : _a.call(control);
    window.setTimeout(() => {
      var _a2;
      return (_a2 = control == null ? void 0 : control.openTabById) == null ? void 0 : _a2.call(control, "gib-sync");
    }, 50);
  }
  runPrimary(action) {
    if (action === "setup") {
      this.close();
      new SetupModal(this.app, this.plugin).open();
      return;
    }
    if (action === "resolve") {
      new NativeSyncConflictModal(this.app, this.plugin).open();
      return;
    }
    if (action === "review") {
      this.close();
      this.plugin.openSafeguards();
      return;
    }
    if (action === "resume") {
      void this.plugin.setPaused(false);
      return;
    }
    if (action === "settings") {
      this.openSettings();
      return;
    }
    this.close();
    void this.plugin.runSync();
  }
  render() {
    const live = this.plugin.liveStatus, state = this.plugin.indicatorState();
    const model = buildQuickStatusModel({ state, live, configured: Boolean(this.plugin.settings.deviceToken), nativeSyncBlocked: this.plugin.isNativeSyncBlocking(), paused: this.plugin.settings.paused });
    this.hero.className = `gib-sync-status-overview is-${state.tone}`;
    if (this.icon.dataset.icon !== state.icon) {
      (0, import_obsidian3.setIcon)(this.icon, state.icon);
      this.icon.dataset.icon = state.icon;
    }
    this.overviewTitleEl.setText(state.label);
    this.descriptionEl.setText(model.description);
    this.metaEl.setText(model.meta);
    const percent = live.total ? Math.min(100, (live.current || 0) / live.total * 100) : 0;
    this.progress.hidden = state.key !== "syncing" || !live.total;
    this.progressValue.style.width = `${percent}%`;
    this.progress.setAttr("aria-valuenow", String(Math.round(percent)));
    this.primary.setText(model.primaryLabel);
    this.primary.disabled = model.primaryDisabled;
    this.primary.onclick = () => this.runPrimary(model.primaryAction);
    this.pause.hidden = !this.plugin.settings.deviceToken;
    this.pause.setText(this.plugin.settings.paused ? "Resume" : "Pause");
  }
  onClose() {
    var _a;
    (_a = this.unsubscribe) == null ? void 0 : _a.call(this);
    this.unsubscribe = null;
    this.contentEl.empty();
  }
};
var GibSyncSettingTab = class extends import_obsidian3.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
    __publicField(this, "unsubscribe", null);
    __publicField(this, "liveRoot", null);
    __publicField(this, "liveRenderTimer", null);
    __publicField(this, "liveFields", /* @__PURE__ */ new Map());
    __publicField(this, "liveValues", /* @__PURE__ */ new Map());
    __publicField(this, "consoleRows", /* @__PURE__ */ new Map());
    __publicField(this, "page", "status");
    __publicField(this, "pageEl");
  }
  display() {
    var _a;
    (_a = this.unsubscribe) == null ? void 0 : _a.call(this);
    this.unsubscribe = null;
    if (this.liveRenderTimer !== null) window.clearTimeout(this.liveRenderTimer);
    this.liveRenderTimer = null;
    this.liveRoot = null;
    this.liveFields.clear();
    this.liveValues.clear();
    this.consoleRows.clear();
    this.containerEl.empty();
    this.containerEl.addClass("gib-sync-settings");
    const header = this.containerEl.createDiv({ cls: "gib-sync-settings-header" });
    header.createEl("h2", { text: "Gib Sync" });
    header.createSpan({ text: "Vault sync with readable Seafile storage" });
    const tabs = [["status", "Connection", "activity"], ["content", "What syncs", "files"], ["sync", "Automation", "refresh-cw"], ["safety", "Devices & recovery", "shield-check"], ["console", "Diagnostics", "terminal"]];
    const tablist = this.containerEl.createDiv({ cls: "gib-sync-settings-tabs", attr: { role: "tablist", "aria-label": "Gib Sync settings" } });
    for (const [id, label, iconName] of tabs) {
      const button = tablist.createEl("button", { attr: { type: "button", role: "tab", "aria-selected": String(this.page === id) } });
      const icon = button.createSpan();
      (0, import_obsidian3.setIcon)(icon, iconName);
      button.createSpan({ text: label });
      button.toggleClass("is-active", this.page === id);
      button.addEventListener("click", () => {
        if (this.page === id) return;
        this.page = id;
        this.display();
      });
    }
    this.pageEl = this.containerEl.createDiv({ cls: "gib-sync-settings-page", attr: { role: "tabpanel" } });
    if (this.page === "sync") this.renderSyncPage();
    else if (this.page === "content") this.renderContentPage();
    else if (this.page === "safety") this.renderSafetyPage();
    else if (this.page === "console") this.renderConsolePage();
    else this.renderStatusPage();
    if (this.page === "status" || this.page === "console") this.unsubscribe = this.plugin.subscribeStatus(() => this.scheduleLiveRender());
  }
  renderStatusPage() {
    const configured = Boolean(this.plugin.settings.deviceToken);
    this.liveRoot = this.pageEl.createDiv({ cls: "gib-sync-status-panel" });
    this.renderLive();
    new import_obsidian3.Setting(this.pageEl).setName("Connection").setHeading();
    const actions = new import_obsidian3.Setting(this.pageEl).setName("Actions").setDesc(configured ? "Sync now, or refresh server-side counters and connection details." : "Connect manually with Seafile details, or enter a temporary quick code from an existing device.");
    actions.addButton((button) => button.setButtonText(configured ? "Sync now" : "Manual setup").setCta().onClick(() => configured ? void this.plugin.runSync() : new SetupModal(this.app, this.plugin).open()));
    if (configured) actions.addButton((button) => button.setButtonText("Refresh status").onClick(() => void this.plugin.refreshServerStatus()));
    if (configured) actions.addButton((button) => button.setButtonText(this.plugin.settings.paused ? "Resume" : "Pause").onClick(async () => {
      await this.plugin.setPaused(!this.plugin.settings.paused);
      button.setButtonText(this.plugin.settings.paused ? "Resume" : "Pause");
    }));
    if (!configured) actions.addButton((button) => button.setButtonText("Enter quick code").onClick(() => new QuickCodeEntryModal(this.app, this.plugin).open()));
    if (configured) new import_obsidian3.Setting(this.pageEl).setName("Add another device").setDesc("Show a five-digit code that changes every 60 seconds and works once.").addButton((button) => button.setButtonText("Show quick code").onClick(() => new QuickCodeDisplayModal(this.app, this.plugin).open())).addButton((button) => button.setButtonText("Change connection").onClick(() => new SetupModal(this.app, this.plugin).open()));
    if (configured) void this.plugin.refreshServerStatus();
  }
  renderSyncPage() {
    new import_obsidian3.Setting(this.pageEl).setName("Status indicators").setHeading();
    new import_obsidian3.Setting(this.pageEl).setName("Desktop status icon").setDesc("Show the current state as an icon in the desktop status bar.").addToggle((toggle) => toggle.setValue(this.plugin.settings.desktopStatusIcon).onChange(async (value) => {
      this.plugin.settings.desktopStatusIcon = value;
      await this.plugin.saveSettings();
      this.plugin.configureStatusSurfaces();
    }));
    new import_obsidian3.Setting(this.pageEl).setName("Desktop short state").setDesc("Show only the short state word, such as Synced, Syncing, Attention, Paused, or Error.").addToggle((toggle) => toggle.setValue(this.plugin.settings.desktopStatusText).onChange(async (value) => {
      this.plugin.settings.desktopStatusText = value;
      await this.plugin.saveSettings();
      this.plugin.configureStatusSurfaces();
    }));
    new import_obsidian3.Setting(this.pageEl).setName("Mobile right-sidebar indicator").setDesc("Place a tappable indicator in the bottom-right status area of the mobile right sidebar.").addToggle((toggle) => toggle.setValue(this.plugin.settings.mobileSidebarIndicator).onChange(async (value) => {
      this.plugin.settings.mobileSidebarIndicator = value;
      await this.plugin.saveSettings();
      this.plugin.configureStatusSurfaces();
    }));
    new import_obsidian3.Setting(this.pageEl).setName("Mobile top-navigation dot").setDesc("Place a compact status dot immediately left of the mobile view-mode control.").addToggle((toggle) => toggle.setValue(this.plugin.settings.mobileTopIndicator).onChange(async (value) => {
      this.plugin.settings.mobileTopIndicator = value;
      await this.plugin.saveSettings();
      this.plugin.configureStatusSurfaces();
    }));
    new import_obsidian3.Setting(this.pageEl).setName("Animate active synchronization").setDesc("Actual transfers use a loading ring. A verified checkmark changes hue subtly while checking, without changing size.").addToggle((toggle) => toggle.setValue(this.plugin.settings.animateStatusIndicator).onChange(async (value) => {
      this.plugin.settings.animateStatusIndicator = value;
      await this.plugin.saveSettings();
      this.plugin.configureStatusSurfaces();
    }));
    new import_obsidian3.Setting(this.pageEl).setName("Attention badge count").setDesc("Show the number of quarantined change batches that need review.").addToggle((toggle) => toggle.setValue(this.plugin.settings.showAttentionBadge).onChange(async (value) => {
      this.plugin.settings.showAttentionBadge = value;
      await this.plugin.saveSettings();
      this.plugin.configureStatusSurfaces();
    }));
    new import_obsidian3.Setting(this.pageEl).setName("Automation").setHeading();
    const nativeProtection = new import_obsidian3.Setting(this.pageEl).setName("Obsidian Sync protection").setDesc(this.plugin.isNativeSyncBlocking() ? "Obsidian Sync is enabled. Gib Sync is paused to prevent two sync engines from changing this vault." : "Gib Sync checks continuously and refuses to run while Obsidian Sync is enabled.");
    nativeProtection.addButton((button) => button.setButtonText("Open Core plugins").onClick(() => this.plugin.openCorePluginSettings())).addButton((button) => button.setButtonText("Check now").onClick(async () => {
      button.setDisabled(true);
      const blocked = await this.plugin.checkObsidianSyncProtection(true);
      button.setDisabled(false);
      new import_obsidian3.Notice(blocked ? "Obsidian Sync is still enabled." : "Protection check passed.");
      this.display();
    }));
    new import_obsidian3.Setting(this.pageEl).setName("Periodic sync").setDesc("Checks for remote changes on a timer.").addToggle((toggle) => toggle.setValue(this.plugin.settings.autoSync).onChange(async (value) => {
      this.plugin.settings.autoSync = value;
      await this.plugin.saveSettings();
      this.plugin.configureTimer();
    }));
    new import_obsidian3.Setting(this.pageEl).setName("Instant incoming sync").setDesc("The server notifies this device when another device changes the vault. The periodic interval remains a safety check.").addToggle((toggle) => toggle.setValue(this.plugin.settings.instantReceive).onChange(async (value) => {
      this.plugin.settings.instantReceive = value;
      await this.plugin.saveSettings();
      this.plugin.configureWatch();
    }));
    new import_obsidian3.Setting(this.pageEl).setName("Sync interval").setDesc("Seconds between periodic checks (minimum 15).").addText((text) => text.setValue(String(this.plugin.settings.syncIntervalSeconds)).onChange(async (value) => {
      const parsed = Number(value);
      if (Number.isFinite(parsed)) {
        this.plugin.settings.syncIntervalSeconds = Math.max(15, Math.round(parsed));
        await this.plugin.saveSettings();
        this.plugin.configureTimer();
      }
    }));
    new import_obsidian3.Setting(this.pageEl).setName("Sync when files change").setDesc("Detects editor changes plus created, saved, renamed, and deleted files. After editing stops, waits two seconds for Obsidian to save and then syncs. Excluded paths do not trigger it.").addToggle((toggle) => toggle.setValue(this.plugin.settings.syncOnFileChange).onChange(async (value) => {
      this.plugin.settings.syncOnFileChange = value;
      this.plugin.configureFileChangeSync();
      await this.plugin.saveSettings();
    }));
  }
  renderContentPage() {
    const configured = Boolean(this.plugin.settings.deviceToken);
    new import_obsidian3.Setting(this.pageEl).setName("Vault content").setHeading();
    new import_obsidian3.Setting(this.pageEl).setName("Sync bookmarks").setDesc("Synchronizes Obsidian bookmarks across devices. Enabled by default and independent of other Obsidian configuration files.").addToggle((toggle) => toggle.setValue(this.plugin.settings.syncBookmarks).onChange(async (value) => {
      if (!value && this.plugin.settings.syncBookmarks && !await this.confirmFilterChange(this.plugin.settings.exclusions, value, this.plugin.settings.syncObsidianConfig, this.plugin.settings.syncPlugins)) {
        toggle.setValue(true);
        return;
      }
      this.plugin.settings.syncBookmarks = value;
      this.plugin.requireFullScan();
      await this.plugin.saveSettings();
      if (configured) void this.plugin.runSync();
    }));
    new import_obsidian3.Setting(this.pageEl).setName("Sync Obsidian configuration").setDesc("Includes portable themes, snippets, hotkeys, and other .obsidian settings. JSON settings merge by key; overlapping values use the newer version without creating conflict files. Workspace state remains device-local.").addToggle((toggle) => toggle.setValue(this.plugin.settings.syncObsidianConfig).onChange(async (value) => {
      if (!value && this.plugin.settings.syncObsidianConfig && !await this.confirmFilterChange(this.plugin.settings.exclusions, this.plugin.settings.syncBookmarks, value, this.plugin.settings.syncPlugins)) {
        toggle.setValue(true);
        return;
      }
      this.plugin.settings.syncObsidianConfig = value;
      this.plugin.requireFullScan();
      await this.plugin.saveSettings();
      if (configured) void this.plugin.runSync();
    }));
    new import_obsidian3.Setting(this.pageEl).setName("Sync installed plugins").setDesc("Synchronizes each community plugin as one version-aware package, repairs incomplete enablement, and leaves generated caches, indexes, embeddings, logs, and temporary data on their device. First activation pulls the accepted plugin inventory and settings before this device may publish plugin changes. Plugin data.json may contain API keys visible in readable Seafile. Reload Obsidian after plugin updates.").addToggle((toggle) => toggle.setValue(this.plugin.settings.syncPlugins).onChange(async (value) => {
      if (!value && this.plugin.settings.syncPlugins && !await this.confirmFilterChange(this.plugin.settings.exclusions, this.plugin.settings.syncBookmarks, this.plugin.settings.syncObsidianConfig, value)) {
        toggle.setValue(true);
        return;
      }
      if (value && !this.plugin.settings.syncPlugins) this.plugin.settings.pluginSyncBootstrapPending = true;
      if (!value) this.plugin.settings.pluginSyncBootstrapPending = false;
      this.plugin.settings.syncPlugins = value;
      this.plugin.requireFullScan();
      await this.plugin.saveSettings();
      if (configured) void this.plugin.runSync();
    }));
    new import_obsidian3.Setting(this.pageEl).setName("Filters").setHeading();
    let proposedExclusions = this.plugin.settings.exclusions.join("\n");
    new import_obsidian3.Setting(this.pageEl).setName("Excluded path prefixes").setDesc("The device-local ignore list. Ignored remote files remain safe for other devices. Changes are previewed; use one prefix per line.").addTextArea((area) => area.setValue(proposedExclusions).onChange((value) => proposedExclusions = value)).addButton((button) => button.setButtonText("Preview and apply").onClick(async () => {
      const next = proposedExclusions.split("\n").map((line) => line.trim()).filter(Boolean);
      button.setDisabled(true);
      try {
        if (await this.confirmFilterChange(next, this.plugin.settings.syncBookmarks, this.plugin.settings.syncObsidianConfig, this.plugin.settings.syncPlugins)) {
          this.plugin.settings.exclusions = next;
          this.plugin.requireFullScan();
          await this.plugin.saveSettings();
          new import_obsidian3.Notice("Ignore list updated; ignored remote files remain safe for other devices");
          if (configured) void this.plugin.runSync();
        }
      } finally {
        button.setDisabled(false);
      }
    }));
    this.pageEl.createDiv({ cls: "gib-sync-settings-note", text: "Filters apply only to this device. Accepted remote files remain available to other connected devices." });
  }
  renderSafetyPage() {
    const configured = Boolean(this.plugin.settings.deviceToken);
    new import_obsidian3.Setting(this.pageEl).setName("Protection").setHeading();
    if (!configured) {
      this.pageEl.createDiv({ cls: "gib-sync-settings-note", text: "Connect this device before managing safeguards, devices, recovery, or version history." });
      return;
    }
    new import_obsidian3.Setting(this.pageEl).setName("Safety center").setDesc("Review held changes, tune mass-change protection, manage devices, or freeze all remote writes.").addButton((button) => button.setButtonText("Review held changes").onClick(() => this.plugin.openSafeguards())).addButton((button) => button.setButtonText("Safeguard settings").onClick(() => new SafeguardSettingsModal(this.app, this.plugin).open())).addButton((button) => button.setButtonText("Devices").onClick(() => new DeviceManagementModal(this.app, this.plugin).open()));
    new import_obsidian3.Setting(this.pageEl).setName("Remote write lock").setDesc("Freezes commits and external Seafile imports while downloads remain available.").addButton((button) => {
      var _a;
      return button.setButtonText(((_a = this.plugin.serverStatus) == null ? void 0 : _a.safeguards.writeLocked) ? "Resume writes" : "Freeze writes").onClick(async () => {
        button.setDisabled(true);
        try {
          const current = await this.plugin.api.safeguards();
          await this.plugin.api.setWriteLock(!current.writeLocked);
          await this.plugin.refreshServerStatus();
          this.display();
          new import_obsidian3.Notice(current.writeLocked ? "Remote writes resumed" : "Remote writes frozen");
        } catch (error) {
          new import_obsidian3.Notice(error instanceof Error ? error.message : String(error), 1e4);
          button.setDisabled(false);
        }
      });
    });
    if (this.plugin.settings.vaultIdentity && this.plugin.currentVaultIdentity() !== this.plugin.settings.vaultIdentity) new import_obsidian3.Setting(this.pageEl).setName("Vault location changed").setDesc("Sync is paused until you verify that this is the intended local vault.").addButton((button) => button.setWarning().setButtonText("Trust this vault location").onClick(async () => {
      if (!await confirmAction(this.app, "Trust vault location", "Trust this vault name and location for Gib Sync? Only continue if you intentionally moved or renamed the vault.", "Trust location", true)) return;
      await this.plugin.acceptCurrentVaultIdentity();
      this.display();
    }));
    new import_obsidian3.Setting(this.pageEl).setName("Recovery").setHeading();
    new import_obsidian3.Setting(this.pageEl).setName("Repair vault health").setDesc("Uses the accepted server snapshot as the safe checkpoint, dismisses stuck held proposals, rebuilds the readable Seafile vault, removes obsolete internal conflict artifacts, and then runs normal reconciliation. Version history is preserved.").addButton((button) => button.setWarning().setButtonText("Diagnose and repair").onClick(async () => {
      if (!await confirmAction(this.app, "Repair vault health", "Restore the currently accepted server snapshot as the readable Seafile checkpoint and dismiss pending quarantined proposals? Normal notes and version history are preserved. Use this when sync cannot escape a blocked or dirty state.", "Repair health", true)) return;
      button.setDisabled(true);
      try {
        await this.plugin.repairVaultHealth();
      } finally {
        button.setDisabled(false);
      }
    }));
    new import_obsidian3.Setting(this.pageEl).setName("Version history").setDesc("Browse accepted snapshots and restore a known version.").addButton((button) => button.setButtonText("Open history").onClick(() => new HistoryModal(this.app, this.plugin).open()));
    new import_obsidian3.Setting(this.pageEl).setName("Local recovery copies").setDesc("Sync preserves replaced or deleted originals in .gib-sync/local-recovery on this device. These are separate from server history and are never uploaded as notes.").addButton((button) => button.setButtonText("Browse copies").onClick(() => new LocalRecoveryModal(this.app, this.plugin).open()));
    new import_obsidian3.Setting(this.pageEl).setName("Conflicts & recovery inbox").setDesc("Compare preserved versions and make a reversible decision. Newer edits are never overwritten by undo.").addButton((button) => button.setButtonText("Review conflicts").onClick(() => new ConflictInboxModal(this.app, this.plugin).open()));
    new import_obsidian3.Setting(this.pageEl).setName("New device approvals").setDesc("Only this inviting device can approve its pending quick-code requests.").addButton((button) => button.setButtonText("Review requests").onClick(() => new DeviceRequestsModal(this.app, this.plugin).open()));
    void this.plugin.refreshServerStatus();
  }
  renderConsolePage() {
    new import_obsidian3.Setting(this.pageEl).setName("Mobile & device readiness").setDesc("Test native streaming, foreground/background behavior, and responsiveness without exporting note content or secrets.").addButton((button) => button.setButtonText("Open device test").onClick(() => new DeviceDiagnosticsModal(this.app, this.plugin).open()));
    const toolbar = this.pageEl.createDiv({ cls: "gib-sync-console-toolbar" });
    const detailed = toolbar.createEl("button", { text: "Copy detailed", attr: { type: "button", title: "Includes vault-relative file names, merge decisions, and errors; excludes credentials and server addresses" } });
    detailed.onclick = async () => {
      var _a;
      const storage = ((_a = this.plugin.serverStatus) == null ? void 0 : _a.storage) || this.plugin.settings.storage, copied = await copyText(JSON.stringify(detailedDiagnostics(this.plugin.liveStatus, this.plugin.serverStatus, { configured: Boolean(this.plugin.settings.deviceToken), storageConfigured: Boolean(storage) }), null, 2));
      new import_obsidian3.Notice(copied ? "Detailed Gib Sync log copied; review vault-relative file names before sharing" : "Clipboard access is unavailable on this device.", copied ? 6e3 : 8e3);
    };
    const safe = toolbar.createEl("button", { text: "Copy safe", attr: { type: "button", title: "Removes activity text and file names for public sharing" } });
    safe.onclick = async () => {
      var _a;
      const storage = ((_a = this.plugin.serverStatus) == null ? void 0 : _a.storage) || this.plugin.settings.storage, copied = await copyText(JSON.stringify(privacySafeDiagnostics(this.plugin.liveStatus, this.plugin.serverStatus, { configured: Boolean(this.plugin.settings.deviceToken), storageConfigured: Boolean(storage) }), null, 2));
      new import_obsidian3.Notice(copied ? "Privacy-safe Gib Sync log copied" : "Clipboard access is unavailable on this device.", copied ? 4e3 : 8e3);
    };
    const clear = toolbar.createEl("button", { text: "Clear", attr: { type: "button" } });
    clear.onclick = () => this.plugin.clearActivity();
    toolbar.createSpan({ text: "Live session activity" });
    this.liveRoot = this.pageEl.createDiv({ cls: "gib-sync-console", attr: { role: "log", "aria-live": "off", "aria-label": "Detailed sync activity" } });
    this.renderConsole();
  }
  hide() {
    var _a;
    (_a = this.unsubscribe) == null ? void 0 : _a.call(this);
    this.unsubscribe = null;
    if (this.liveRenderTimer !== null) window.clearTimeout(this.liveRenderTimer);
    this.liveRenderTimer = null;
  }
  included(path, exclusions, syncBookmarks, syncConfig, syncPlugins) {
    return shouldSyncChangedPath(path, { ...this.plugin.settings, exclusions, syncBookmarks, syncObsidianConfig: syncConfig, syncPlugins });
  }
  async confirmFilterChange(exclusions, syncBookmarks, syncConfig, syncPlugins) {
    if (!this.plugin.settings.deviceToken) return true;
    const head = (await this.plugin.api.state()).head;
    if (!head) return true;
    const affected = head.entries.filter((entry) => this.included(entry.path, this.plugin.settings.exclusions, this.plugin.settings.syncBookmarks, this.plugin.settings.syncObsidianConfig, this.plugin.settings.syncPlugins) && !this.included(entry.path, exclusions, syncBookmarks, syncConfig, syncPlugins));
    if (!affected.length) return true;
    const examples = affected.slice(0, 10).map((entry) => `- ${entry.path}`).join("\n");
    return confirmAction(this.app, "Apply sync filter", `This device will stop syncing ${affected.length} file${affected.length === 1 ? "" : "s"}:

${examples}${affected.length > 10 ? `
- \u2026and ${affected.length - 10} more` : ""}

Their accepted remote versions remain safe and available to other devices.`, "Apply filter");
  }
  scheduleLiveRender() {
    if (this.liveRenderTimer !== null) return;
    this.liveRenderTimer = window.setTimeout(() => {
      this.liveRenderTimer = null;
      if (this.page === "console") this.renderConsole();
      else if (this.page === "status") this.renderLive();
    }, 250);
  }
  renderLive() {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    if (!this.liveRoot) return;
    const root2 = this.liveRoot, live = this.plugin.liveStatus, server = this.plugin.serverStatus, state = this.plugin.indicatorState();
    if (!this.liveFields.size) {
      const header = root2.createDiv({ cls: "gib-sync-status-head" });
      header.createDiv({ cls: "gib-sync-status-dot" });
      const copy = header.createDiv();
      this.liveFields.set("header", header);
      this.liveFields.set("label", copy.createEl("strong"));
      this.liveFields.set("description", copy.createDiv({ cls: "gib-sync-muted" }));
      this.liveFields.set("freshness", header.createDiv({ cls: "gib-sync-status-freshness" }));
      const track2 = root2.createDiv({ cls: "gib-sync-progress", attr: { role: "progressbar", "aria-label": "Sync progress", "aria-valuemin": "0", "aria-valuemax": "100" } });
      this.liveFields.set("track", track2);
      this.liveFields.set("progress", track2.createDiv({ cls: "gib-sync-progress-value" }));
      const attention2 = root2.createDiv({ cls: "gib-sync-attention-card" });
      this.liveFields.set("attention", attention2);
      this.liveFields.set("attentionTitle", attention2.createEl("strong"));
      this.liveFields.set("attentionMessage", attention2.createEl("p"));
      this.liveFields.set("grid", root2.createDiv({ cls: "gib-sync-status-grid gib-sync-status-summary" }));
      this.liveFields.set("versions", root2.createDiv({ cls: "gib-sync-version-line gib-sync-muted" }));
      const details = root2.createEl("details", { cls: "gib-sync-status-details" });
      details.createEl("summary", { text: "Technical details" });
      this.liveFields.set("technical", details.createDiv({ cls: "gib-sync-status-grid" }));
    }
    this.liveFields.get("header").className = `gib-sync-status-head is-${state.tone}`;
    this.liveFields.get("label").setText(state.label);
    this.liveFields.get("description").setText(state.description);
    this.liveFields.get("freshness").setText(live.lastSuccessAt ? `Last verified ${when(live.lastSuccessAt)}` : "Not verified yet");
    const percent = live.total ? Math.min(100, (live.current || 0) / live.total * 100) : 0, track = this.liveFields.get("track");
    track.hidden = !live.running || !live.total;
    track.setAttr("aria-valuenow", String(Math.round(percent)));
    this.liveFields.get("progress").style.width = `${percent}%`;
    const issues = (_a = server == null ? void 0 : server.healthAlerts.filter((alert) => alert.level === "warning" || alert.level === "error")) != null ? _a : [], incompatible = this.plugin.compatibility && !this.plugin.compatibility.compatible, attention = this.liveFields.get("attention");
    attention.hidden = !incompatible && live.phase !== "error" && !issues.length;
    attention.className = `gib-sync-attention-card is-${live.phase === "error" || issues.some((issue) => issue.level === "error") ? "error" : "warning"}`;
    this.liveFields.get("attentionTitle").setText(incompatible ? "Update required" : live.phase === "error" ? "Sync needs help" : "Server needs attention");
    this.liveFields.get("attentionMessage").setText(incompatible ? (_b = this.plugin.compatibility.reason) != null ? _b : "A compatibility update is required" : live.phase === "error" ? live.lastError || live.message : (_d = (_c = issues[0]) == null ? void 0 : _c.message) != null ? _d : "");
    const item = (host, label, value, tone = "neutral", detail = "") => {
      let row = this.liveValues.get(label);
      if (!row) {
        row = host.createDiv();
        row.createEl("span", { text: label });
        row.createEl("strong");
        this.liveValues.set(label, row);
      }
      row.className = `is-${tone}`;
      row.querySelector("strong").textContent = value;
      row.setAttr("title", detail || value);
    };
    for (const fact of buildSyncFacts(live, server, this.plugin.settings.lastSnapshotId)) item(this.liveFields.get("grid"), fact.label, fact.value, fact.tone, fact.detail);
    const compatibility = (_e = server == null ? void 0 : server.compatibility) != null ? _e : this.plugin.compatibility;
    this.liveFields.get("versions").setText(`Plugin ${this.plugin.manifest.version} \xB7 Server ${(_f = compatibility == null ? void 0 : compatibility.serverVersion) != null ? _f : "checking\u2026"}`);
    const technical = this.liveFields.get("technical"), storage = (_g = server == null ? void 0 : server.storage) != null ? _g : this.plugin.settings.storage;
    item(technical, "Current operation", live.running ? live.message : "Idle");
    item(technical, "Last result", live.lastResult || "No completed sync yet");
    item(technical, "Next automatic check", when(live.nextSyncAt));
    item(technical, "Current error", live.phase === "error" ? live.lastError || live.message : "None", live.phase === "error" ? "error" : "neutral");
    item(technical, "Server pause", ((_h = server == null ? void 0 : server.containment) == null ? void 0 : _h.active) && !server.containment.thisVaultAllowed ? "This vault is safely paused" : "Off");
    item(technical, "Held changes", server ? String(server.safeguards.pendingQuarantines) : "Checking");
    item(technical, "Vault / device", this.plugin.settings.vaultName ? `${this.plugin.settings.vaultName} / ${this.plugin.settings.deviceName}` : "Not configured");
    item(technical, "Gib Sync server", this.plugin.settings.serverUrl || "Not connected");
    item(technical, "Folder topology", this.plugin.settings.lastFolderCleanupError || this.plugin.settings.retiredFolderNote || "No outstanding folder warnings");
    if (storage) {
      item(technical, "Seafile account", `${storage.username} @ ${storage.seafileUrl}`);
      item(technical, "Readable vault", `${storage.libraryName}:${storage.readablePath}`);
    }
    if (server) {
      item(technical, "Stored history", `${server.snapshotCount} snapshots \xB7 ${server.blobCount} blobs \xB7 ${bytes(server.blobBytes)}`);
      item(technical, "External edits", server.externalError || "Watching for Seafile edits");
      item(technical, "Client compatibility", server.compatibility ? `Minimum ${server.compatibility.minimumVersion} \xB7 recommended ${server.compatibility.recommendedVersion}` : "Not advertised");
      item(technical, "Server notices", server.healthAlerts.map((alert) => alert.message).join(" \xB7 ") || "None");
    }
  }
  renderConsole() {
    var _a, _b;
    if (!this.liveRoot) return;
    const root2 = this.liveRoot, nearBottom = root2.scrollHeight - root2.scrollTop - root2.clientHeight < 48, activities = this.plugin.liveStatus.activities.slice(-100), keys = /* @__PURE__ */ new Set();
    let index = 0;
    for (const entry of activities) {
      const key = `${entry.phase}\0${entry.message}`;
      keys.add(key);
      let row = this.consoleRows.get(key);
      if (!row) {
        row = root2.createDiv({ cls: "gib-sync-console-row" });
        row.createEl("time");
        row.createSpan({ cls: "gib-sync-console-phase" });
        row.createSpan({ cls: "gib-sync-console-message" });
        this.consoleRows.set(key, row);
      }
      row.setAttr("data-level", entry.level);
      row.querySelector("time").textContent = new Date(entry.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
      row.querySelector(".gib-sync-console-phase").textContent = entry.phase;
      row.querySelector(".gib-sync-console-message").textContent = `${entry.message}${((_a = entry.repeats) != null ? _a : 1) > 1 ? ` \xB7 repeated ${entry.repeats} times` : ""}`;
      if (root2.children[index] !== row) root2.insertBefore(row, (_b = root2.children[index]) != null ? _b : null);
      index++;
    }
    for (const [key, row] of this.consoleRows) if (!keys.has(key)) {
      row.remove();
      this.consoleRows.delete(key);
    }
    let empty = root2.querySelector(".gib-sync-console-empty");
    if (activities.length) empty == null ? void 0 : empty.remove();
    else if (!empty) empty = root2.createDiv({ cls: "gib-sync-console-empty", text: "No activity recorded in this session." });
    if (nearBottom) root2.scrollTop = root2.scrollHeight;
  }
};
async function claimQuickCodeSetup(plugin, server, value, deviceName) {
  await plugin.verifyServerBeforeSetup(server);
  const code = normalizeQuickCode(value);
  const response = await plugin.api.claimQuickCode(server, code, deviceName);
  if ("status" in response && response.status === "pending") {
    const approved = await new Promise((resolve, reject) => new DeviceApprovalWaitModal(plugin.app, plugin, server, response, (result) => result instanceof Error ? reject(result) : resolve(result)).open());
    return openPairingEnvelope(approved.envelope, response.ticket, approved.pairingId);
  }
  const legacy = response;
  return openPairingEnvelope(legacy.envelope, code, legacy.pairingId);
}

// src/main.ts
var GibSyncPlugin = class extends import_obsidian4.Plugin {
  constructor() {
    super(...arguments);
    __publicField(this, "settings", { ...DEFAULT_SETTINGS });
    __publicField(this, "api");
    __publicField(this, "engine");
    __publicField(this, "statusEl");
    __publicField(this, "timer", null);
    __publicField(this, "debounce", null);
    __publicField(this, "debounceKind", null);
    __publicField(this, "fileChangePending", false);
    __publicField(this, "lastRelevantVaultChangeAt", 0);
    __publicField(this, "lastVaultRenameAt", 0);
    __publicField(this, "watchGeneration", 0);
    __publicField(this, "syncTask", null);
    __publicField(this, "operationGeneration", 0);
    __publicField(this, "operationOwner", 0);
    __publicField(this, "stopped", false);
    __publicField(this, "vaultEventsReady", false);
    __publicField(this, "inventoryChecking", false);
    __publicField(this, "canonicalConfigEnabled", false);
    __publicField(this, "configAliases", []);
    __publicField(this, "declaredConfigScope", "");
    __publicField(this, "syncAdapter");
    __publicField(this, "packageRuntime", null);
    __publicField(this, "liveStatus", initialLiveStatus(false));
    __publicField(this, "serverStatus", null);
    __publicField(this, "statusListeners", /* @__PURE__ */ new Set());
    __publicField(this, "safeguardModalOpen", false);
    __publicField(this, "safetyHold", false);
    __publicField(this, "notificationGate", new NotificationGate());
    __publicField(this, "nativeSyncBlocked", false);
    __publicField(this, "nativeSyncNoticeShown", false);
    __publicField(this, "changedDuringReadFailures", /* @__PURE__ */ new Map());
    __publicField(this, "mobileSidebarEl", null);
    __publicField(this, "mobileTopEl", null);
    __publicField(this, "mobileLongPressCancel", null);
    __publicField(this, "mobileObserver", null);
    __publicField(this, "ribbonEl", null);
    __publicField(this, "indicatorRenderKeys", /* @__PURE__ */ new WeakMap());
    __publicField(this, "mobileMountScheduled", false);
    __publicField(this, "mobileLayoutReady", !import_obsidian4.Platform.isMobile);
    __publicField(this, "pathVersions", /* @__PURE__ */ new Map());
    __publicField(this, "pathRevision", 0);
    __publicField(this, "fullScanRevision", 0);
    __publicField(this, "syncApplicationRevisions", null);
    __publicField(this, "journalSaveTimer", null);
    __publicField(this, "expectedLocalMutations", /* @__PURE__ */ new Map());
    __publicField(this, "expectedVerificationQueue", /* @__PURE__ */ new Map());
    __publicField(this, "expectedVerificationTimer", null);
    __publicField(this, "expectedVerificationRunning", false);
    __publicField(this, "configWatcher", null);
    __publicField(this, "configWatchError", "");
    __publicField(this, "compatibility", null);
    __publicField(this, "compatibilityBlocked", false);
    __publicField(this, "persistSettings", createSerializedSettingsWriter(() => this.settings, (snapshot) => this.saveData(snapshot)));
  }
  async onload() {
    this.settings = await loadSettings(this);
    this.settings.configDir = (0, import_obsidian4.normalizePath)(this.app.vault.configDir);
    this.settings.fullScanRequired = true;
    for (const path of this.settings.pendingPaths) this.pathVersions.set(path, ++this.pathRevision);
    this.api = new GibSyncApi(() => this.settings, new SnapshotCache(this.app.vault.adapter));
    this.liveStatus = { ...initialLiveStatus(Boolean(this.settings.deviceToken)), lastSuccessAt: this.settings.lastSuccessAt, lastErrorAt: this.settings.lastErrorAt, lastError: this.settings.lastError, lastResult: this.settings.lastResult };
    this.statusEl = this.addStatusBarItem();
    this.syncAdapter = canonicalAdapter(this.app.vault.adapter, () => this.canonicalConfigEnabled ? this.settings.configDir : ".obsidian", () => this.configAliases);
    this.packageRuntime = new PluginRuntimeCoordinator(this.app, import_obsidian4.Plugin.prototype, () => this.app.plugins, this.app.vault.adapter, (id) => `${this.settings.configDir}/plugins/${id}`, import_obsidian4.Platform.isMobile, () => this.assertOperationCurrent(), cooperativeYield, (id, message, attention = true) => this.recordRuntimeOutcome(id, message, attention));
    this.engine = new SyncEngine(this.syncAdapter, this.api, () => this.settings, () => this.saveSettings(), (progress) => {
      var _a;
      if (this.stopped) return;
      if (progress.remoteChanged || ["applying", "uploading", "committing", "mirroring"].includes(progress.phase)) this.liveStatus.verified = false;
      this.report(progress.phase, progress.message, (_a = progress.level) != null ? _a : "info", progress.current, progress.total);
    }, void 0, (path, hash) => this.expectedLocalMutations.set(this.syncPath(path), hash), void 0, import_obsidian4.Platform.isMobile, (path) => !this.syncApplicationRevisions || this.syncApplicationRevisions.get(this.syncPath(path)) === this.pathVersions.get(this.syncPath(path)), () => this.canContinueOperation(), this.packageRuntime);
    const ribbon = this.addRibbonIcon("refresh-cw", "Gib Sync status", () => this.openStatusOverview());
    this.ribbonEl = ribbon;
    ribbon.oncontextmenu = (event) => {
      event.preventDefault();
      void this.runSync();
    };
    this.addCommand({ id: "sync-now", name: "Sync now", callback: () => void this.runSync() });
    this.addCommand({ id: "open-status", name: "Open sync status", callback: () => this.openStatusOverview() });
    this.addCommand({ id: "toggle-pause", name: "Pause or resume sync", checkCallback: (checking) => {
      if (!this.settings.deviceToken) return false;
      if (!checking) void this.setPaused(!this.settings.paused);
      return true;
    } });
    this.addCommand({ id: "desktop-setup", name: "Set up first device", callback: () => new SetupModal(this.app, this).open() });
    this.addCommand({ id: "show-quick-code", name: "Show temporary mobile setup code", checkCallback: (checking) => {
      if (!this.settings.deviceToken) return false;
      if (!checking) new QuickCodeDisplayModal(this.app, this).open();
      return true;
    } });
    this.addCommand({ id: "enter-quick-code", name: "Enter temporary setup code", callback: () => new QuickCodeEntryModal(this.app, this).open() });
    this.addCommand({ id: "open-history", name: "Open version history", checkCallback: (checking) => {
      if (!this.settings.deviceToken) return false;
      if (!checking) new HistoryModal(this.app, this).open();
      return true;
    } });
    this.addCommand({ id: "review-safeguards", name: "Review quarantined changes", checkCallback: (checking) => {
      if (!this.settings.deviceToken) return false;
      if (!checking) this.openSafeguards();
      return true;
    } });
    this.addCommand({ id: "repair-vault-health", name: "Repair vault health", checkCallback: (checking) => {
      if (!this.settings.deviceToken) return false;
      if (!checking) void this.repairVaultHealth();
      return true;
    } });
    this.addSettingTab(new GibSyncSettingTab(this.app, this));
    this.registerEvent(this.app.vault.on("create", (file) => {
      if (file instanceof import_obsidian4.TFolder) {
        const path = this.syncPath(file.path);
        if (!shouldSyncChangedPath(path, this.settings)) return;
        const expected = this.expectedLocalMutations.get(path);
        if (this.expectedLocalMutations.has(path)) {
          this.queueExpectedMutationVerification(path, expected != null ? expected : null);
          return;
        }
        this.journalIntent(this.vaultEventsReady ? "create" : "observe", path, "folder");
        this.settings.folderCreateTimes[path] = Date.now();
        this.requireFullScan();
      } else {
        this.recordFileCreation(file.path);
        this.scheduleFileChangeSync(file.path);
      }
    }));
    this.registerEvent(this.app.vault.on("modify", (file) => {
      if (!(file instanceof import_obsidian4.TFolder)) this.scheduleFileChangeSync(file.path);
    }));
    this.registerEvent(this.app.vault.on("delete", (file) => {
      this.journalIntent("delete", file.path, file instanceof import_obsidian4.TFolder ? "folder" : "file");
      if (file instanceof import_obsidian4.TFolder) {
        const path = this.syncPath(file.path);
        if (!shouldSyncChangedPath(path, this.settings)) return;
        const expected = this.expectedLocalMutations.get(path);
        if (this.expectedLocalMutations.has(path)) {
          this.queueExpectedMutationVerification(path, expected != null ? expected : null);
          return;
        }
        this.recordPathTime(path, true);
        this.requireFullScan();
      } else this.scheduleFileChangeSync(file.path);
    }));
    this.registerEvent(this.app.vault.on("rename", (file, oldPath) => {
      if (this.stopped || !shouldSyncChangedPath(oldPath, this.settings) && !shouldSyncChangedPath(file.path, this.settings)) return;
      this.journalIntent("move", file.path, file instanceof import_obsidian4.TFolder ? "folder" : "file", oldPath);
      this.lastVaultRenameAt = Date.now();
      this.recordRename(oldPath, file.path);
      if (file instanceof import_obsidian4.TFolder) {
        this.settings.folderCreateTimes[this.syncPath(file.path)] = Date.now();
        this.persistJournalSoon();
        this.recordPathTime(file.path, true);
        this.recordPathTime(oldPath, true);
        this.requireFullScan();
      } else this.scheduleFileChangeSync(file.path, oldPath);
    }));
    this.registerEvent(this.app.workspace.on("editor-change", (_editor, info) => {
      if (info.file) this.scheduleFileChangeSync(info.file.path);
    }));
    this.registerEvent(this.app.workspace.on("layout-change", () => this.scheduleMobileMount()));
    this.configWatcher = new ConfigWatcher(this.app.vault.adapter, () => this.settings, (paths, created) => {
      for (const path of created) this.recordFileCreation(path);
      this.scheduleFileChangeSync(...paths);
    });
    this.registerInterval(window.setInterval(() => void this.checkConfigChanges(), 5e3));
    this.registerInterval(window.setInterval(() => void this.checkInventory(), 2e3));
    void this.checkConfigChanges();
    this.registerDomEvent(document, "visibilitychange", () => {
      if (document.visibilityState !== "visible" || !this.settings.deviceToken) return;
      this.configureWatch();
      if (this.liveStatus.running) this.fileChangePending = true;
      else if (this.settings.autoSync || this.settings.instantReceive) this.queueSync(750, "App returned to foreground", "automatic");
    });
    this.configureStatusSurfaces();
    this.registerInterval(window.setInterval(() => void this.checkObsidianSyncProtection(), 5e3));
    this.registerInterval(window.setInterval(() => {
      if (this.settings.deviceToken && this.safetyHold) void this.refreshServerStatus();
    }, 3e4));
    void this.checkObsidianSyncProtection();
    if (this.settings.deviceToken) await this.checkCompatibility(false);
    this.configureTimer();
    this.configureWatch();
    this.app.workspace.onLayoutReady(() => {
      if (this.stopped) return;
      this.mobileLayoutReady = true;
      this.vaultEventsReady = true;
      this.configureStatusSurfaces();
      void this.checkObsidianSyncProtection();
      if (this.settings.deviceToken && this.settings.autoSync) this.scheduleSync(2500);
    });
  }
  onunload() {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    this.stopped = true;
    (_a = this.configWatcher) == null ? void 0 : _a.stop();
    this.cancelOperation();
    (_c = (_b = this.engine) == null ? void 0 : _b.stop) == null ? void 0 : _c.call(_b);
    (_d = this.packageRuntime) == null ? void 0 : _d.dispose();
    this.watchGeneration++;
    if (this.timer !== null) window.clearInterval(this.timer);
    if (this.debounce !== null) window.clearTimeout(this.debounce);
    if (this.journalSaveTimer !== null) window.clearTimeout(this.journalSaveTimer);
    if (this.expectedVerificationTimer !== null) window.clearTimeout(this.expectedVerificationTimer);
    this.expectedVerificationQueue.clear();
    if (this.settings.pendingPaths.length || Object.keys(this.settings.pendingPathTimes).length || this.settings.pendingApplyPaths.length || this.settings.fullScanRequired) void this.saveSettings();
    (_e = this.mobileLongPressCancel) == null ? void 0 : _e.call(this);
    this.mobileLongPressCancel = null;
    (_f = this.mobileObserver) == null ? void 0 : _f.disconnect();
    (_g = this.mobileSidebarEl) == null ? void 0 : _g.remove();
    (_h = this.mobileTopEl) == null ? void 0 : _h.remove();
    this.statusListeners.clear();
    this.removeStaleMobileSidebarIndicators();
  }
  async checkConfigChanges() {
    var _a;
    if (this.stopped || document.visibilityState === "hidden") return;
    try {
      await ((_a = this.configWatcher) == null ? void 0 : _a.poll());
      this.configWatchError = "";
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (message !== this.configWatchError) {
        this.configWatchError = message;
        this.liveStatus.activities.push({ at: (/* @__PURE__ */ new Date()).toISOString(), phase: "checking", level: "warning", message: `Configuration change tracking unavailable: ${message}; full reconciliation remains active.` });
        this.emitStatus();
      }
    }
  }
  async checkInventory() {
    if (this.stopped || !this.vaultEventsReady || this.inventoryChecking || this.liveStatus.running || this.syncTask || this.settings.paused || !this.settings.deviceToken || this.nativeSyncBlocked || this.compatibilityBlocked || this.safetyHold || document.visibilityState === "hidden") return;
    this.inventoryChecking = true;
    this.operationOwner = this.operationGeneration;
    try {
      const result = await this.engine.verifyInventory();
      if (this.stopped) return;
      if (result.changedPaths.length) result.changedPaths.forEach((path) => this.scheduleFileChangeSync(path));
      if (this.settings.fullScanRequired && !this.liveStatus.running) this.queueSync(750, "Folder inventory changed", "automatic");
      if (result.pending) {
        this.liveStatus.verified = false;
        this.report("checking", `Verifying saved inventory \xB7 ${result.pending} files remaining`, "info");
      } else if (!this.liveStatus.lastError && !Object.keys(this.settings.packageHolds).length && !this.settings.pendingPaths.length && !this.settings.fullScanRequired && !this.settings.pendingApplySnapshotId && !this.settings.retiredFolderCount && this.settings.lastSnapshotId) {
        this.liveStatus.verified = true;
        this.report("up-to-date", "Up to date \xB7 file contents verified", "success");
      }
    } catch (error) {
      if (!(error instanceof SyncCancelledError) && !this.stopped) {
        this.liveStatus.verified = false;
        this.report("checking", "Background verification will retry; local files are unchanged", "info");
      }
    } finally {
      this.inventoryChecking = false;
    }
  }
  syncPath(path) {
    return this.canonicalConfigEnabled ? canonicalConfigPath((0, import_obsidian4.normalizePath)(path), this.settings.configDir) : (0, import_obsidian4.normalizePath)(path);
  }
  journalIntent(kind, path, entity = "file", from) {
    const normalized = this.syncPath(path);
    if (this.stopped || this.expectedLocalMutations.has(normalized) || from && this.expectedLocalMutations.has(this.syncPath(from)) || !shouldSyncChangedPath(normalized, this.settings) && (!from || !shouldSyncChangedPath(from, this.settings))) return;
    void this.engine.recordIntent(kind, normalized, entity, from ? this.syncPath(from) : void 0).catch(() => {
      if (!this.stopped) {
        this.liveStatus.verified = false;
        this.report("checking", "Saving the change journal will retry before any files are published", "info");
      }
    });
  }
  async ensureConfigurationNamespace() {
    if (typeof this.api.supportsOperationsV2 !== "function" || !this.api.supportsOperationsV2()) return;
    const scope = JSON.stringify([this.settings.serverUrl, this.settings.vaultId, this.settings.deviceId, this.settings.configDir]);
    if (this.declaredConfigScope === scope) return;
    let declaration;
    try {
      declaration = await this.api.declareConfigRoot(this.settings.configDir);
    } catch (error) {
      if (error instanceof ApiError && error.status === 404) return;
      throw error;
    }
    this.assertOperationCurrent();
    this.configAliases = declaration.aliases;
    this.engine.setConfigAliases(declaration.aliases);
    this.canonicalConfigEnabled = true;
    const mapPath = (path) => {
      for (const alias of [...declaration.aliases].sort((a, b) => b.length - a.length)) if (path === alias || path.startsWith(`${alias}/`)) return `.obsidian${path.slice(alias.length)}`;
      return this.syncPath(path);
    }, mapRecord = (record, entry) => Object.fromEntries(Object.entries(record).map(([old, value]) => {
      const path = mapPath(old);
      return [path, entry ? entry(value, path, old) : value];
    }));
    for (const field of ["pendingPaths", "pendingApplyPaths"]) this.settings[field] = [...new Set(this.settings[field].map(mapPath))];
    for (const field of ["pendingPathTimes", "fileCreationTimes", "folderCreateTimes", "pendingApplyPriorHashes", "retiredPaths"]) this.settings[field] = mapRecord(this.settings[field]);
    this.settings.pendingMoves = this.settings.pendingMoves.map((move) => ({ ...move, from: mapPath(move.from), to: mapPath(move.to) }));
    this.settings.pendingApplyOperations = mapRecord(this.settings.pendingApplyOperations, (operation, path, old) => {
      var _a;
      return { ...operation, ...old !== path ? { namespacePath: (_a = operation.namespacePath) != null ? _a : old } : {} };
    });
    this.settings.pendingApplyPriorEntries = mapRecord(this.settings.pendingApplyPriorEntries, (entry, path) => ({ ...entry, path }));
    this.settings.localReconcileBases = mapRecord(this.settings.localReconcileBases, (entry, path) => entry ? { ...entry, path } : null);
    if (this.settings.pendingCommit) {
      this.settings.pendingCommit.priorHashes = mapRecord(this.settings.pendingCommit.priorHashes);
      if (this.settings.pendingCommit.priorEntries) this.settings.pendingCommit.priorEntries = mapRecord(this.settings.pendingCommit.priorEntries, (entry, path) => ({ ...entry, path }));
    }
    for (const [path, revision] of [...this.pathVersions]) {
      this.pathVersions.delete(path);
      this.pathVersions.set(mapPath(path), revision);
    }
    this.settings.fullScanRequired = true;
    await this.saveSettings();
    this.declaredConfigScope = scope;
  }
  canContinueOperation() {
    return !this.stopped && !this.settings.paused && !this.nativeSyncBlocked && !this.compatibilityBlocked && this.operationOwner === this.operationGeneration;
  }
  assertOperationCurrent() {
    if (!this.canContinueOperation()) throw new SyncCancelledError("Synchronization was safely stopped");
  }
  cancelOperation() {
    var _a, _b;
    this.operationGeneration++;
    (_b = (_a = this.engine) == null ? void 0 : _a.cancel) == null ? void 0 : _b.call(_a);
  }
  attentionCount() {
    var _a, _b;
    return (_b = (_a = this.serverStatus) == null ? void 0 : _a.safeguards.pendingQuarantines) != null ? _b : 0;
  }
  indicatorHealth() {
    var _a, _b, _c;
    const alerts = (_b = (_a = this.serverStatus) == null ? void 0 : _a.healthAlerts) != null ? _b : [], error = alerts.find((item) => item.level === "error"), warning = alerts.find((item) => item.level === "warning");
    return { errors: alerts.filter((item) => item.level === "error").length, warnings: alerts.filter((item) => item.level === "warning").length, description: (_c = error == null ? void 0 : error.message) != null ? _c : warning == null ? void 0 : warning.message };
  }
  indicatorState() {
    var _a, _b, _c, _d;
    this.liveStatus.pendingChanges = (/* @__PURE__ */ new Set([...this.settings.pendingPaths, ...this.settings.pendingApplyPaths, ...Object.keys(this.settings.pendingPathTimes)])).size;
    if (this.compatibilityBlocked) return { key: "blocked", label: "Update required", icon: "download", tone: "warning", animated: false, attentionCount: 0, description: (_b = (_a = this.compatibility) == null ? void 0 : _a.reason) != null ? _b : "This Gib Sync version is not compatible with the server" };
    if (((_d = (_c = this.serverStatus) == null ? void 0 : _c.containment) == null ? void 0 : _d.active) && !this.serverStatus.containment.thisVaultAllowed) return { key: "blocked", label: "Server paused", icon: "shield-alert", tone: "warning", animated: false, attentionCount: 0, description: "Emergency containment is protecting this vault; no files are being changed" };
    const health = this.indicatorHealth();
    if (this.settings.retiredFolderCount) {
      health.warnings++;
      health.description = this.settings.retiredFolderNote || `${this.settings.retiredFolderCount} local folder mismatch${this.settings.retiredFolderCount === 1 ? "" : "es"} remain`;
    }
    const packageHolds = Object.keys(this.settings.packageHolds);
    if (packageHolds.length) {
      health.warnings++;
      health.description = `${packageHolds.length} plugin package${packageHolds.length === 1 ? "" : "s"} need repair; other vault files can still sync. ${packageHolds.slice(0, 3).join(", ")}`;
    }
    return deriveIndicatorState(this.liveStatus, Boolean(this.settings.deviceToken), this.nativeSyncBlocked || this.settings.paused, this.attentionCount(), health);
  }
  isNativeSyncBlocking() {
    return this.nativeSyncBlocked;
  }
  appendIndicatorVisual(host, state = this.indicatorState(), dotOnly = false) {
    var _a;
    if (state.key === "syncing") {
      const ring = host.createSpan({ cls: `gib-sync-progress-ring${this.liveStatus.total ? " is-determinate" : this.settings.animateStatusIndicator ? " is-indeterminate" : ""}` });
      const percent = this.liveStatus.total ? Math.max(0, Math.min(100, ((_a = this.liveStatus.current) != null ? _a : 0) / this.liveStatus.total * 100)) : 25;
      ring.style.setProperty("--gib-sync-progress", `${percent}%`);
      ring.setAttr("aria-hidden", "true");
      return;
    }
    if (dotOnly) host.createSpan({ cls: "gib-sync-indicator-dot" });
    else {
      const icon = host.createSpan({ cls: "gib-sync-indicator-icon" });
      (0, import_obsidian4.setIcon)(icon, state.icon);
    }
  }
  renderIndicator(element, dotOnly = false) {
    var _a, _b;
    const state = this.indicatorState(), animate = this.settings.animateStatusIndicator && state.animated;
    const kind = element.dataset.gibSyncIndicatorKind;
    const placement = kind ? ` gib-sync-mobile-${kind}-indicator` : "";
    const nativeSidebar = kind === "sidebar";
    const nativeClasses = nativeSidebar ? ` clickable-icon workspace-drawer-header-icon mod-raised sync-status-icon${state.tone === "success" ? " mod-success" : state.tone === "active" ? " mod-working" : state.tone === "error" ? " mod-error" : ""}` : "";
    element.className = `gib-sync-indicator${placement}${nativeClasses} is-${state.tone} is-${state.key}${animate ? " is-animated" : ""}${dotOnly ? " is-dot-only" : ""}`;
    const visualKey = `${state.key}:${state.icon}:${dotOnly}:${animate}:${this.settings.showAttentionBadge ? state.attentionCount : 0}:${Boolean(this.liveStatus.total)}`;
    if (this.indicatorRenderKeys.get(element) !== visualKey) {
      element.empty();
      this.indicatorRenderKeys.set(element, visualKey);
      this.appendIndicatorVisual(element, state, dotOnly);
      if (!dotOnly && this.settings.showAttentionBadge && state.attentionCount > 0) element.createSpan({ cls: "gib-sync-indicator-badge", text: String(Math.min(99, state.attentionCount)) });
    }
    (_b = element.querySelector(".gib-sync-progress-ring")) == null ? void 0 : _b.style.setProperty("--gib-sync-progress", `${this.liveStatus.total ? Math.max(0, Math.min(100, ((_a = this.liveStatus.current) != null ? _a : 0) / this.liveStatus.total * 100)) : 25}%`);
    element.setAttr("aria-label", `${state.label}. ${state.description}`);
    element.setAttr("data-tooltip-position", "top");
  }
  updateStatusBar() {
    var _a, _b, _c, _d, _e;
    if (!this.statusEl) return;
    const state = this.indicatorState(), show = !import_obsidian4.Platform.isMobile && (this.settings.desktopStatusIcon || this.settings.desktopStatusText);
    this.statusEl.toggleClass("is-hidden", !show);
    this.statusEl.className = `status-bar-item gib-sync-desktop-status is-${state.tone} is-${state.key}${this.settings.animateStatusIndicator && state.animated ? " is-animated" : ""}${show ? "" : " is-hidden"}`;
    const visualKey = `${state.key}:${state.icon}:${this.settings.animateStatusIndicator}:${this.settings.desktopStatusIcon}:${this.settings.desktopStatusText}:${this.settings.showAttentionBadge ? state.attentionCount : 0}:${Boolean(this.liveStatus.total)}`;
    if (this.indicatorRenderKeys.get(this.statusEl) !== visualKey) {
      this.statusEl.empty();
      this.indicatorRenderKeys.set(this.statusEl, visualKey);
      if (this.settings.desktopStatusIcon) {
        this.appendIndicatorVisual(this.statusEl, state);
        if (this.settings.showAttentionBadge && state.attentionCount > 0) this.statusEl.createSpan({ cls: "gib-sync-indicator-badge", text: String(Math.min(99, state.attentionCount)) });
      }
      if (this.settings.desktopStatusText) this.statusEl.createSpan({ cls: "gib-sync-status-short-text" });
    }
    (_a = this.statusEl.querySelector(".gib-sync-status-short-text")) == null ? void 0 : _a.setText(state.label);
    (_c = this.statusEl.querySelector(".gib-sync-progress-ring")) == null ? void 0 : _c.style.setProperty("--gib-sync-progress", `${this.liveStatus.total ? Math.max(0, Math.min(100, ((_b = this.liveStatus.current) != null ? _b : 0) / this.liveStatus.total * 100)) : 25}%`);
    this.statusEl.setAttr("aria-label", `${state.label}. ${state.description}`);
    this.statusEl.setAttr("role", "button");
    this.statusEl.setAttr("tabindex", "0");
    this.statusEl.onkeydown = (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        this.openStatusOverview();
      }
    };
    if (this.ribbonEl) {
      this.ribbonEl.setAttr("aria-label", `${state.label}. ${state.description}. Open sync status`);
      this.ribbonEl.toggleClass("gib-sync-ribbon-fallback", import_obsidian4.Platform.isMobile);
      this.ribbonEl.setAttr("data-gib-sync-state", state.key);
      if (this.ribbonEl.dataset.gibSyncIcon !== state.icon) {
        (0, import_obsidian4.setIcon)(this.ribbonEl, state.icon);
        this.ribbonEl.dataset.gibSyncIcon = state.icon;
      }
    }
    this.statusEl.onclick = () => this.openStatusOverview();
    this.statusEl.oncontextmenu = (event) => {
      event.preventDefault();
      const menu = new import_obsidian4.Menu();
      menu.addItem((item) => item.setTitle("Sync now").setIcon("refresh-cw").onClick(() => void this.runSync()));
      menu.addItem((item) => item.setTitle(this.settings.paused ? "Resume" : "Pause").setIcon(this.settings.paused ? "play" : "pause").onClick(() => void this.setPaused(!this.settings.paused)));
      menu.addItem((item) => item.setTitle("Open status").setIcon("activity").onClick(() => this.openStatusOverview()));
      menu.showAtMouseEvent(event);
    };
    if ((_d = this.mobileSidebarEl) == null ? void 0 : _d.isConnected) this.renderIndicator(this.mobileSidebarEl);
    if ((_e = this.mobileTopEl) == null ? void 0 : _e.isConnected) this.renderIndicator(this.mobileTopEl, true);
    this.scheduleMobileMount();
  }
  openStatusOverview() {
    new StatusOverviewModal(this.app, this).open();
  }
  configureStatusSurfaces() {
    var _a, _b, _c;
    this.updateStatusBar();
    if (!import_obsidian4.Platform.isMobile) {
      (_a = this.mobileObserver) == null ? void 0 : _a.disconnect();
      this.mobileObserver = null;
      (_b = this.mobileSidebarEl) == null ? void 0 : _b.remove();
      (_c = this.mobileTopEl) == null ? void 0 : _c.remove();
      return;
    }
    if (!this.mobileLayoutReady) {
      this.removeStaleMobileSidebarIndicators();
      return;
    }
    const workspaceRoot = this.app.workspace.containerEl;
    if (!this.mobileObserver && workspaceRoot) {
      const layoutSelector = ".view-header, .view-actions, .view-action, .mobile-navbar-actions, .workspace-drawer, .workspace-leaf";
      this.mobileObserver = new MutationObserver((records2) => {
        if (records2.some((record) => Array.from(record.addedNodes).concat(Array.from(record.removedNodes)).some((node) => node instanceof HTMLElement && (node.matches(layoutSelector) || node.querySelector(layoutSelector))))) this.scheduleMobileMount();
      });
      this.mobileObserver.observe(workspaceRoot, { childList: true, subtree: true });
    }
    this.scheduleMobileMount();
  }
  mobileButton() {
    let element = this.mobileTopEl;
    if (!element) {
      element = document.createElement("button");
      element.type = "button";
      element.dataset.gibSyncIndicatorKind = "top";
      let timer = null, longPressed = false;
      const cancel = () => {
        if (timer !== null) window.clearTimeout(timer);
        timer = null;
      };
      this.mobileLongPressCancel = cancel;
      element.addEventListener("pointerdown", () => {
        cancel();
        if (this.stopped) return;
        longPressed = false;
        timer = window.setTimeout(() => {
          timer = null;
          if (this.stopped || !(element == null ? void 0 : element.isConnected)) return;
          longPressed = true;
          void this.runSync();
        }, 650);
      });
      element.addEventListener("pointerup", cancel);
      element.addEventListener("pointercancel", cancel);
      element.addEventListener("pointerleave", cancel);
      element.addEventListener("click", (event) => {
        if (longPressed) {
          event.preventDefault();
          longPressed = false;
          return;
        }
        this.openStatusOverview();
      });
      this.mobileTopEl = element;
    }
    this.renderIndicator(element, true);
    return element;
  }
  mountNativeMobileSidebarIndicator() {
    var _a, _b;
    if ((_a = this.mobileSidebarEl) == null ? void 0 : _a.isConnected) {
      this.removeStaleMobileSidebarIndicators(this.mobileSidebarEl);
      return this.mobileSidebarEl;
    }
    (_b = this.mobileSidebarEl) == null ? void 0 : _b.remove();
    this.mobileSidebarEl = null;
    this.removeStaleMobileSidebarIndicators();
    const rightSplit = this.app.workspace.rightSplit;
    if (!(rightSplit == null ? void 0 : rightSplit.addHeaderButton)) return null;
    let element;
    try {
      element = rightSplit.addHeaderButton("sync-small", () => this.openStatusOverview());
    } catch (e) {
      return null;
    }
    if (!(element == null ? void 0 : element.dataset)) return null;
    element.dataset.gibSyncIndicatorKind = "sidebar";
    element.addEventListener("contextmenu", (event) => {
      event.preventDefault();
      void this.runSync();
    });
    this.mobileSidebarEl = element;
    this.renderIndicator(element);
    this.removeStaleMobileSidebarIndicators(element);
    return element;
  }
  removeStaleMobileSidebarIndicators(keep) {
    document.querySelectorAll(".gib-sync-mobile-sidebar-indicator, [data-gib-sync-indicator-kind='sidebar']").forEach((element) => {
      if (element !== keep) element.remove();
    });
  }
  scheduleMobileMount() {
    if (this.stopped || !import_obsidian4.Platform.isMobile || !this.mobileLayoutReady || this.mobileMountScheduled) return;
    this.mobileMountScheduled = true;
    window.requestAnimationFrame(() => {
      this.mobileMountScheduled = false;
      if (!this.stopped) this.mountMobileIndicators();
    });
  }
  mountMobileIndicators() {
    var _a, _b, _c, _d, _e;
    if (!import_obsidian4.Platform.isMobile) return;
    if (this.settings.mobileSidebarIndicator) {
      this.mountNativeMobileSidebarIndicator();
    } else {
      (_a = this.mobileSidebarEl) == null ? void 0 : _a.remove();
      this.mobileSidebarEl = null;
      this.removeStaleMobileSidebarIndicators();
    }
    if (this.settings.mobileTopIndicator) {
      const element = (_b = this.mobileTopEl) != null ? _b : this.mobileButton();
      const actions = Array.from(document.querySelectorAll(".mobile-navbar-action, .view-action, .view-header-icon"));
      const mode = actions.find((item) => {
        var _a2, _b2;
        return /reading view|editing mode|live preview|source mode|view mode|preview/i.test(`${(_a2 = item.getAttribute("aria-label")) != null ? _a2 : ""} ${(_b2 = item.getAttribute("data-tooltip")) != null ? _b2 : ""}`);
      });
      const host = (_c = mode == null ? void 0 : mode.parentElement) != null ? _c : document.querySelector(".mobile-navbar-actions, .workspace-leaf.mod-active .view-actions, .view-header .view-actions");
      if (host && (element.parentElement !== host || mode && element.nextElementSibling !== mode)) host.insertBefore(element, mode != null ? mode : host.firstChild);
    } else {
      (_d = this.mobileLongPressCancel) == null ? void 0 : _d.call(this);
      (_e = this.mobileTopEl) == null ? void 0 : _e.remove();
    }
  }
  emitStatus() {
    if (this.stopped) return;
    this.updateStatusBar();
    for (const listener of this.statusListeners) listener();
  }
  subscribeStatus(listener) {
    this.statusListeners.add(listener);
    return () => this.statusListeners.delete(listener);
  }
  recordRuntimeOutcome(id, message, attention) {
    var _a;
    if (attention) {
      this.settings.packageHolds[id] = { ...this.settings.packageHolds[id], reason: message, at: Date.now() };
      this.liveStatus.verified = false;
      this.report("applying", message, "warning");
      return;
    }
    const now = (/* @__PURE__ */ new Date()).toISOString(), previous = this.liveStatus.activities.at(-1);
    if ((previous == null ? void 0 : previous.message) === message && previous.level === "info") {
      previous.at = now;
      previous.repeats = ((_a = previous.repeats) != null ? _a : 1) + 1;
    } else this.liveStatus.activities.push({ at: now, phase: this.liveStatus.phase, level: "info", message, repeats: 1 });
    if (this.liveStatus.activities.length > 100) this.liveStatus.activities.splice(0, this.liveStatus.activities.length - 100);
    this.emitStatus();
  }
  report(phase, message, level = "info", current, total) {
    var _a;
    this.liveStatus.phase = phase;
    this.liveStatus.message = message;
    this.liveStatus.current = current;
    this.liveStatus.total = total;
    const now = (/* @__PURE__ */ new Date()).toISOString(), previous = this.liveStatus.activities.at(-1);
    if (previous && previous.phase === phase && previous.message === message && current !== void 0) {
      Object.assign(previous, { at: now, level, current, total });
    } else {
      let repeated = -1;
      for (let index = this.liveStatus.activities.length - 1; index >= 0; index--) {
        const entry = this.liveStatus.activities[index];
        if (entry.phase === phase && entry.message === message && Date.now() - Date.parse(entry.at) < 10 * 6e4) {
          repeated = index;
          break;
        }
      }
      if (repeated >= 0) {
        const [entry] = this.liveStatus.activities.splice(repeated, 1);
        this.liveStatus.activities.push({ ...entry, at: now, level, current, total, repeats: ((_a = entry.repeats) != null ? _a : 1) + 1 });
      } else this.liveStatus.activities.push({ at: now, phase, level, message, current, total, repeats: 1 });
      if (this.liveStatus.activities.length > 100) this.liveStatus.activities.splice(0, this.liveStatus.activities.length - 100);
    }
    this.emitStatus();
  }
  notify(key, message, duration = 8e3, cooldownMs = 6e4) {
    const visible = this.notificationGate.next(key, message, cooldownMs);
    if (visible) new import_obsidian4.Notice(visible, duration);
  }
  clearActivity() {
    this.liveStatus.activities = [];
    this.emitStatus();
  }
  async refreshServerStatus() {
    var _a, _b, _c, _d, _e;
    if (this.stopped || !this.settings.deviceToken) return;
    const checkpoint = this.settings.lastSnapshotId;
    try {
      const wasHeld = this.safetyHold, wasContained = Boolean(((_b = (_a = this.serverStatus) == null ? void 0 : _a.containment) == null ? void 0 : _b.active) && !this.serverStatus.containment.thisVaultAllowed);
      const status = await this.api.status();
      if (this.stopped) return;
      this.serverStatus = status;
      if (this.serverStatus.compatibility) this.applyCompatibility(this.serverStatus.compatibility);
      this.settings.storage = this.serverStatus.storage;
      if (!this.liveStatus.running && checkpoint === this.settings.lastSnapshotId && ((_d = (_c = this.serverStatus.head) == null ? void 0 : _c.id) != null ? _d : null) !== checkpoint) this.liveStatus.verified = false;
      const contained = Boolean(((_e = this.serverStatus.containment) == null ? void 0 : _e.active) && !this.serverStatus.containment.thisVaultAllowed);
      if (contained) {
        this.safetyHold = true;
        this.report("blocked", "Server emergency pause is active; this vault is protected and no files are being changed", "warning");
      } else if (!this.serverStatus.safeguards.pendingQuarantines && !this.serverStatus.safeguards.writeLocked) this.safetyHold = false;
      await this.saveSettings();
      if (wasContained && !contained && !this.safetyHold) {
        this.report("idle", "Server emergency pause cleared; synchronization can resume", "success");
        this.configureTimer();
        this.configureWatch();
        this.queueSync(1e3, "Server pause cleared", "automatic");
      } else if (wasHeld && !this.safetyHold) this.scheduleNextSyncLabel();
      else this.emitStatus();
    } catch (error) {
      this.liveStatus.activities.push({ at: (/* @__PURE__ */ new Date()).toISOString(), phase: "checking", level: "warning", message: `Server status refresh unavailable: ${error instanceof Error ? error.message : String(error)}` });
      this.liveStatus.activities = this.liveStatus.activities.slice(-100);
      this.emitStatus();
    }
  }
  applyCompatibility(result) {
    result = enforceServerCompatibility(result);
    this.compatibility = result;
    const wasBlocked = this.compatibilityBlocked;
    this.compatibilityBlocked = !result.compatible;
    if (this.compatibilityBlocked) {
      this.cancelOperation();
      this.watchGeneration++;
      if (this.timer !== null) window.clearInterval(this.timer);
      this.timer = null;
      if (this.debounce !== null) window.clearTimeout(this.debounce);
      this.debounce = null;
      this.debounceKind = null;
      this.liveStatus.nextSyncAt = null;
      this.report("blocked", `${result.reason} Synchronization is disabled until compatibility is restored.`, "warning");
    } else if (wasBlocked) {
      this.report("idle", "Client update accepted; synchronization can resume", "success");
      this.configureTimer();
      this.configureWatch();
    }
    if (result.compatible && result.updateAvailable) this.notify("client-update", `Gib Sync ${result.recommendedVersion} is available through BRAT.`, 7e3, 6 * 60 * 60 * 1e3);
  }
  async checkCompatibility(showNotice = true, propagateErrors = false) {
    try {
      this.applyCompatibility(await this.api.compatibility());
      const result = this.compatibility;
      if (!result.compatible && showNotice) this.notify("compatibility", `${result.reason} Synchronization remains disabled.`, 12e3, 6e4);
      return result.compatible;
    } catch (error) {
      if (error instanceof ApiError && error.status === 404) {
        const result = unavailableServerCompatibility();
        this.applyCompatibility(result);
        if (showNotice) this.notify("compatibility", `${result.reason} Update the self-hosted server before syncing.`, 12e3, 6e4);
        return false;
      }
      if (propagateErrors) throw error;
      const message = error instanceof Error ? error.message : String(error);
      this.report(error instanceof ApiTransportError ? "offline" : "error", `Compatibility check failed: ${message}`, "warning");
      if (showNotice) this.notify("compatibility-check", `Gib Sync could not verify server compatibility: ${message}`, 8e3, 6e4);
      return false;
    }
  }
  async saveSettings() {
    await this.persistSettings();
  }
  currentVaultIdentity() {
    var _a, _b;
    const adapter = this.app.vault.adapter;
    return `${this.app.vault.getName()}|${(_b = (_a = adapter.getBasePath) == null ? void 0 : _a.call(adapter)) != null ? _b : "mobile-adapter"}`.replace(/\\/g, "/").toLowerCase();
  }
  async acceptCurrentVaultIdentity() {
    this.settings.vaultIdentity = this.currentVaultIdentity();
    await this.saveSettings();
    this.report("idle", "Current vault location trusted", "success");
  }
  openSafeguards() {
    if (this.safeguardModalOpen) return;
    this.safeguardModalOpen = true;
    new SafeguardReviewModal(this.app, this, () => {
      this.safeguardModalOpen = false;
    }).open();
  }
  async exclusiveOperation(operation) {
    if (this.syncTask || this.liveStatus.running) throw new SyncSafetyError("Let the current sync finish before starting recovery.");
    if (this.stopped || this.settings.paused) throw new SyncCancelledError("Resume this device before starting recovery.");
    this.operationOwner = this.operationGeneration;
    this.liveStatus.running = true;
    this.syncApplicationRevisions = new Map(this.pathVersions);
    const task = Promise.resolve().then(() => {
      this.assertOperationCurrent();
      return operation();
    }), reservation = task.then(() => true, () => false);
    this.syncTask = reservation;
    try {
      const result = await task;
      this.assertOperationCurrent();
      return result;
    } finally {
      if (this.syncTask === reservation) this.syncTask = null;
      this.liveStatus.running = false;
      this.syncApplicationRevisions = null;
      this.scheduleExpectedVerification();
      this.emitStatus();
    }
  }
  async rejectAndRestore(id) {
    return this.exclusiveOperation(async () => {
      await this.api.rejectQuarantine(id);
      this.assertOperationCurrent();
      const result = await this.engine.restoreAcceptedSnapshot();
      this.assertOperationCurrent();
      this.liveStatus.verified = false;
      this.report("complete", "Held changes rejected; accepted server version restored", "success");
      return result;
    });
  }
  listConflictInbox() {
    return this.engine.listConflictInbox();
  }
  previewConflict(id) {
    return this.engine.previewConflict(id);
  }
  listPackageRecoveryOriginals() {
    return this.engine.packageRecoveryOriginals();
  }
  resolveConflict(id, choice, combinedText) {
    return this.exclusiveOperation(async () => {
      await this.ensureConfigurationNamespace();
      await this.engine.resolveConflict(id, choice, combinedText);
      this.liveStatus.verified = false;
      this.report("complete", "Decision saved \xB7 both originals remain recoverable", "success");
    });
  }
  undoConflict(id) {
    return this.exclusiveOperation(async () => {
      await this.ensureConfigurationNamespace();
      await this.engine.undoConflict(id);
      this.liveStatus.verified = false;
      this.report("complete", "Decision undone \xB7 original versions restored", "success");
    });
  }
  restoreLocalRecovery(path) {
    return this.exclusiveOperation(async () => {
      await this.ensureConfigurationNamespace();
      await this.engine.restoreLocalRecovery(path);
      this.liveStatus.verified = false;
      this.report("complete", "Protected original restored \xB7 the current copy remains in recovery", "success");
    });
  }
  async repairVaultHealth() {
    try {
      const result = await this.exclusiveOperation(async () => {
        this.report("mirroring", "Repairing from the accepted server snapshot", "info");
        const result2 = await this.api.repairHealth();
        this.assertOperationCurrent();
        this.safetyHold = false;
        await this.refreshServerStatus();
        return result2;
      });
      this.report("complete", `Health repaired \xB7 ${result.restoredFiles} readable files verified \xB7 ${result.removedConflictCopies} redundant conflict copies cleaned \xB7 ${result.removedFiles} obsolete files removed \xB7 ${result.dismissedQuarantines} held changes dismissed`, "success");
      new import_obsidian4.Notice("Gib Sync repaired the accepted vault and readable recovery copy.", 6e3);
      return await this.runSync();
    } catch (error) {
      if (error instanceof SyncCancelledError) {
        if (this.settings.paused) this.report("blocked", "Synchronization paused");
        return false;
      }
      const message = error instanceof Error ? error.message : String(error);
      if (error instanceof SyncSafetyError) {
        this.notify("health-repair", message, 8e3, 6e4);
        return false;
      }
      this.report("error", `Health repair failed: ${message}`, "error");
      this.notify("health-repair", `Gib Sync health repair failed: ${message}`, 1e4, 6e4);
      return false;
    }
  }
  async acceptSetup(setup, deviceName, onboardingMode = "preserve-local") {
    assertSetupServerCompatible(setup);
    if (this.syncTask || this.liveStatus.running) throw new SyncSafetyError("Pause and let the current sync finish before changing this device\u2019s connection.");
    this.cancelOperation();
    this.operationOwner = this.operationGeneration;
    this.settings.onboardingMode = onboardingMode;
    Object.assign(this.settings, { serverUrl: setup.serverUrl, vaultId: setup.vaultId, vaultName: setup.vaultName, vaultKey: setup.vaultKey, deviceId: setup.deviceId, deviceToken: setup.deviceToken, deviceName, storage: setup.storage, lastSnapshotId: null, initialized: false, vaultIdentity: this.currentVaultIdentity(), pendingPaths: [], pendingPathTimes: {}, pendingApplyPaths: [], pendingApplySnapshotId: null, pendingApplyBaseSnapshotId: null, pendingApplyPriorHashes: {}, pendingCommit: null, pendingApplyPriorEntries: {}, pendingApplyOperations: {}, pendingMoves: [], fileCreationTimes: {}, observedFolderSnapshotId: null, localReconcileBases: {}, retiredPaths: {}, folderCreateTimes: {}, folderCleanupVersion: 5, lastFolderCleanupAt: 0, lastFolderCleanupError: "", retiredFolderCount: 0, retiredFolderNote: "", fullScanRequired: true, lastFullScanAt: null });
    this.pathVersions.clear();
    this.liveStatus = initialLiveStatus(true);
    this.report("idle", "Connected; ready for first sync", "success");
    await this.saveSettings();
    this.configureTimer();
    this.configureWatch();
    void this.refreshServerStatus();
  }
  async verifyServerBeforeSetup(server) {
    assertSetupServerCompatible(await this.api.serverInfo(server));
  }
  async claimQuickCode(server, value, deviceName, onboardingMode = "preserve-local") {
    await this.acceptSetup(await claimQuickCodeSetup(this, server, value, deviceName), deviceName, onboardingMode);
  }
  runtimeObsidianSyncState() {
    var _a, _b, _c, _d, _e;
    const manager = this.app.internalPlugins;
    if (!manager) return null;
    const enabled = (_a = manager.getEnabledPluginById) == null ? void 0 : _a.call(manager, "sync");
    if (enabled) return true;
    const entry = (_d = (_b = manager.getPluginById) == null ? void 0 : _b.call(manager, "sync")) != null ? _d : (_c = manager.plugins) == null ? void 0 : _c.sync;
    return entry ? Boolean((_e = entry.enabled) != null ? _e : entry.instance) : null;
  }
  async obsidianSyncEnabled() {
    const runtime = this.runtimeObsidianSyncState();
    if (runtime !== null) return runtime;
    try {
      const path = (0, import_obsidian4.normalizePath)(`${this.app.vault.configDir}/core-plugins.json`), adapter = this.app.vault.adapter;
      if (!await adapter.exists(path)) return false;
      const stored = JSON.parse(await adapter.read(path));
      if (Array.isArray(stored)) return stored.includes("sync");
      if (stored && typeof stored === "object") return Boolean(stored.sync);
    } catch (e) {
    }
    return false;
  }
  async checkObsidianSyncProtection(showDialog = false) {
    const enabled = await this.obsidianSyncEnabled();
    if (this.stopped) return enabled;
    if (enabled) {
      if (!this.nativeSyncBlocked) {
        this.nativeSyncBlocked = true;
        this.cancelOperation();
        this.watchGeneration++;
        if (this.timer !== null) window.clearInterval(this.timer);
        this.timer = null;
        if (this.debounce !== null) window.clearTimeout(this.debounce);
        this.debounce = null;
        this.debounceKind = null;
        this.report("blocked", "Obsidian Sync is enabled; Gib Sync is paused", "warning");
      } else this.emitStatus();
      if (!this.nativeSyncNoticeShown) {
        this.nativeSyncNoticeShown = true;
        new import_obsidian4.Notice("Gib Sync is paused until the Obsidian Sync core plugin is disabled.", 12e3);
      }
      if (showDialog) new NativeSyncConflictModal(this.app, this).open();
      return true;
    }
    if (this.nativeSyncBlocked) {
      this.nativeSyncBlocked = false;
      this.nativeSyncNoticeShown = false;
      this.report("idle", "Obsidian Sync disabled; Gib Sync resumed", "success");
      this.configureTimer();
      this.configureWatch();
      if (this.settings.deviceToken && !this.settings.paused) this.queueSync(750, "Safety check passed", "automatic");
    }
    return false;
  }
  openCorePluginSettings() {
    var _a;
    const setting = this.app.setting;
    (_a = setting == null ? void 0 : setting.open) == null ? void 0 : _a.call(setting);
    window.setTimeout(() => {
      var _a2;
      return (_a2 = setting == null ? void 0 : setting.openTabById) == null ? void 0 : _a2.call(setting, "core-plugins");
    }, 50);
  }
  async setPaused(paused) {
    this.settings.paused = paused;
    if (paused) this.cancelOperation();
    await this.saveSettings();
    if (paused) {
      this.watchGeneration++;
      if (this.timer !== null) window.clearInterval(this.timer);
      this.timer = null;
      if (this.debounce !== null) window.clearTimeout(this.debounce);
      this.debounce = null;
      this.debounceKind = null;
      this.report("blocked", "Synchronization paused", "warning");
    } else {
      this.report("idle", "Synchronization resumed", "success");
      this.configureTimer();
      this.configureWatch();
      if (this.settings.deviceToken && !await this.checkObsidianSyncProtection()) this.queueSync(500, "Manual resume", "automatic");
    }
  }
  runSync() {
    if (this.syncTask) return this.syncTask;
    this.syncTask = Promise.resolve().then(() => this.performSync()).finally(() => {
      this.syncTask = null;
    });
    return this.syncTask;
  }
  async performSync() {
    var _a, _b, _c;
    if (this.stopped) return false;
    if (!this.settings.deviceToken) {
      new SetupModal(this.app, this).open();
      return false;
    }
    if (this.settings.paused) {
      this.openStatusOverview();
      return false;
    }
    if (this.liveStatus.running) return false;
    this.operationOwner = this.operationGeneration;
    const settleWindow = Date.now() - this.lastVaultRenameAt < 3e4 ? 5e3 : 2e3, quietFor = Date.now() - this.lastRelevantVaultChangeAt;
    if (this.lastRelevantVaultChangeAt && quietFor < settleWindow) {
      this.queueSync(settleWindow + 250 - quietFor, "Waiting for file moves and automatic link updates to settle", "file-change");
      return false;
    }
    const identity = this.currentVaultIdentity();
    if (this.settings.initialized && this.settings.vaultIdentity && identity !== this.settings.vaultIdentity) {
      const message = "Vault-location protection paused sync because this device now points to a different vault path or name. Verify it in Gib Sync settings before trusting the new location.";
      this.report("error", message, "error");
      this.notify("vault-location", message, 1e4, 3e5);
      return false;
    }
    if (!this.settings.vaultIdentity) {
      this.settings.vaultIdentity = identity;
      await this.saveSettings();
    }
    if (this.debounce !== null) {
      window.clearTimeout(this.debounce);
      this.debounce = null;
      this.debounceKind = null;
    }
    this.liveStatus.running = true;
    this.liveStatus.startedAt = (/* @__PURE__ */ new Date()).toISOString();
    this.liveStatus.completedAt = null;
    this.liveStatus.nextSyncAt = null;
    this.report("checking", "Checking for changes");
    let changedDuringRead = null, genericFailure = false, runSucceeded = false, retryStarted = false;
    const startingVersions = new Map(this.pathVersions), startingPathTimes = { ...this.settings.pendingPathTimes }, startingFullScanRevision = this.fullScanRevision;
    try {
      const result = await recoverSync(async () => {
        if (!await this.checkCompatibility(false, true)) throw new SyncCancelledError("Update required");
        this.assertOperationCurrent();
        await this.ensureConfigurationNamespace();
        this.assertOperationCurrent();
        if (await this.checkObsidianSyncProtection(true)) throw new SyncCancelledError("Obsidian Sync is active");
        this.assertOperationCurrent();
        this.liveStatus.nextSyncAt = null;
        this.syncApplicationRevisions = new Map(this.pathVersions);
        const result2 = await this.engine.sync();
        this.assertOperationCurrent();
        if ((await this.api.headState()).headId !== result2.snapshotId) throw new ApiError("The server changed before final verification", 409, null);
        this.assertOperationCurrent();
        return result2;
      }, {
        shouldContinue: () => !this.stopped && !this.settings.paused && this.operationOwner === this.operationGeneration && (!retryStarted || !this.nativeSyncBlocked && !this.compatibilityBlocked && !this.safetyHold),
        onRetry: (error, attempt, delay) => {
          const message = error instanceof Error ? error.message : String(error);
          retryStarted = true;
          this.liveStatus.verified = false;
          this.liveStatus.nextSyncAt = new Date(Date.now() + delay).toISOString();
          this.report("retrying", `Connection or server interrupted sync; retrying automatically (${attempt}/3) in ${delay / 1e3}s. Details: ${message}`, "info");
        },
        wait: (delay) => new Promise((resolve) => window.setTimeout(resolve, delay))
      });
      const now = (/* @__PURE__ */ new Date()).toISOString();
      const summary = `${result.uploaded} encrypted uploads \xB7 ${result.mirrored} readable files written \xB7 ${result.downloaded} downloaded \xB7 ${result.deleted} deleted \xB7 ${result.prunedFolders} folders reconciled \xB7 ${result.pendingRetiredFolders} folder mismatches \xB7 ${result.resolved} system changes auto-resolved \xB7 ${result.conflicts} note conflicts`;
      for (const [path, version] of startingVersions) if (this.pathVersions.get(path) === version && (result.fullScan || result.processedPaths.includes(path) || !this.settings.pendingPaths.includes(path) && !this.settings.pendingPathTimes[path])) this.pathVersions.delete(path);
      for (const [path, time] of Object.entries(startingPathTimes)) if (this.settings.pendingPathTimes[path] === time && (result.fullScan || result.processedPaths.includes(path))) delete this.settings.pendingPathTimes[path];
      if (this.fullScanRevision !== startingFullScanRevision) this.settings.fullScanRequired = true;
      this.settings.pendingPaths = [...this.pathVersions.keys()].sort();
      this.liveStatus.running = false;
      this.liveStatus.completedAt = now;
      this.liveStatus.lastSuccessAt = now;
      this.liveStatus.lastResult = summary;
      this.liveStatus.lastError = "";
      this.liveStatus.verified = !result.pendingRetiredFolders && !((_a = result.pendingPackages) == null ? void 0 : _a.length) && !this.fileChangePending && !this.settings.pendingPaths.length && !this.settings.pendingApplyPaths.length && !this.settings.fullScanRequired && !this.engine.verificationPending;
      this.changedDuringReadFailures.clear();
      this.safetyHold = false;
      this.settings.lastSuccessAt = now;
      this.settings.lastResult = summary;
      this.settings.lastError = "";
      await this.saveSettings();
      this.assertOperationCurrent();
      const changed = Boolean(result.uploaded || result.mirrored || result.downloaded || result.deleted || result.prunedFolders), folderWarning = result.pendingRetiredFolders > 0, packageWarning = Boolean((_b = result.pendingPackages) == null ? void 0 : _b.length);
      this.report(folderWarning ? "blocked" : changed ? "complete" : "up-to-date", `${folderWarning ? "Files synchronized, but folder topology does not match" : packageWarning ? `Vault files synchronized \xB7 ${result.pendingPackages.length} plugin packages held for repair` : changed ? "Sync complete" : "Up to date"} \xB7 ${summary}`, result.conflicts || folderWarning || packageWarning ? "warning" : "success");
      if (!folderWarning) await this.api.markDeviceReady(result.snapshotId).catch(() => {
      });
      if (result.conflicts) this.notify("conflicts", `Gib Sync preserved ${result.conflicts} conflict${result.conflicts === 1 ? "" : "s"}.`, 8e3, 3e4);
      void this.refreshServerStatus();
      runSucceeded = true;
    } catch (error) {
      const now = (/* @__PURE__ */ new Date()).toISOString();
      this.liveStatus.running = false;
      this.liveStatus.completedAt = now;
      if (error instanceof SyncCancelledError) {
        if (this.stopped) return false;
        if (this.settings.paused) this.report("blocked", "Synchronization paused");
      } else if (error instanceof FileChangedDuringReadError) {
        changedDuringRead = error;
        const nowMs = Date.now(), previous = this.changedDuringReadFailures.get(error.path);
        const failure = previous ? { count: previous.count + 1, firstAt: previous.firstAt } : { count: 1, firstAt: nowMs };
        this.changedDuringReadFailures.set(error.path, failure);
        this.report("scheduled", `${error.path} changed during sync; quietly retrying the saved version`, "info");
        if (failure.count >= 3 && nowMs - failure.firstAt >= 12e4) this.notify(`changing-file:${error.path}`, `Gib Sync has been unable to read ${error.path} consistently for over two minutes. Close anything continuously rewriting it, then sync again.`, 8e3, 3e5);
      } else {
        genericFailure = true;
        console.error("Gib Sync could not finish", error);
        const message = error instanceof Error ? error.message : String(error);
        this.liveStatus.verified = false;
        this.liveStatus.lastErrorAt = now;
        this.liveStatus.lastError = message;
        this.settings.lastErrorAt = now;
        this.settings.lastError = message;
        await this.saveSettings();
        if (error instanceof ApiError && error.status === 423) {
          this.safetyHold = true;
          this.report("blocked", message, "warning");
          this.notify("safeguard", message, 1e4, 6e4);
          if ((_c = error.responseBody) == null ? void 0 : _c.quarantine) this.openSafeguards();
          void this.refreshServerStatus();
        } else if (error instanceof SyncSafetyError) {
          this.safetyHold = true;
          this.report("blocked", message, "warning");
          this.notify("safeguard", message, 1e4, 6e4);
        } else if (error instanceof ApiTransportError) {
          this.report("offline", "Could not reach the server after automatic retries. Your changes remain on this device.", "warning");
          this.notify("sync-error", "Gib Sync couldn\u2019t reach the server after retrying. Your changes are safe on this device.", 8e3, 6e4);
        } else {
          this.report("error", `Sync couldn\u2019t finish: ${message}`, "error");
          this.notify("sync-error", `Gib Sync couldn\u2019t finish: ${message}`, 8e3, 6e4);
        }
      }
    } finally {
      this.syncApplicationRevisions = null;
      this.scheduleExpectedVerification();
      if (this.stopped || this.settings.paused || this.safetyHold || this.compatibilityBlocked || this.nativeSyncBlocked) {
        this.liveStatus.nextSyncAt = null;
        this.emitStatus();
      } else if (changedDuringRead) {
        this.fileChangePending = false;
        this.queueSync(2e3, "File changed during sync; retrying");
      } else if (this.fileChangePending && this.settings.syncOnFileChange) {
        this.fileChangePending = false;
        this.queueSync(genericFailure ? 15e3 : 2e3, genericFailure ? "Files changed; retrying with error backoff" : "Files changed during sync");
      } else this.scheduleNextSyncLabel();
    }
    return runSucceeded;
  }
  scheduleSync(delay = 2e3) {
    if (!this.settings.autoSync || !this.settings.deviceToken) return;
    this.queueSync(delay, "Automatic sync", "automatic");
  }
  scheduleFileChangeSync(...paths) {
    if (this.stopped || !this.settings.deviceToken) return;
    const normalized = paths.map((path) => this.syncPath(path));
    const expected = normalized.filter((path) => this.expectedLocalMutations.has(path));
    if (expected.length) {
      for (const path of expected) this.queueExpectedMutationVerification(path, this.expectedLocalMutations.get(path));
      paths = normalized.filter((path) => !expected.includes(path));
    }
    const relevant = paths.map((path) => this.syncPath(path)).filter((path) => shouldSyncChangedPath(path, this.settings));
    if (!relevant.length) return;
    const changedAt = Date.now();
    for (const path of relevant) {
      this.journalIntent("modify", path);
      this.pathVersions.set(path, ++this.pathRevision);
      this.recordPathTime(path, false, changedAt);
    }
    this.settings.pendingPaths = [...this.pathVersions.keys()].sort();
    this.persistJournalSoon();
    this.lastRelevantVaultChangeAt = Date.now();
    if (!this.settings.syncOnFileChange) return;
    if (this.liveStatus.running) {
      this.fileChangePending = true;
      return;
    }
    const delay = Date.now() - this.lastVaultRenameAt < 3e4 ? 5e3 : 2e3;
    this.queueSync(delay, "Vault file changed", "file-change");
  }
  recordRename(from, to) {
    if (this.stopped) return;
    const source = this.syncPath(from), target = this.syncPath(to);
    if (!source || source === target || !shouldSyncChangedPath(source, this.settings) && !shouldSyncChangedPath(target, this.settings) || this.expectedLocalMutations.has(source) || this.expectedLocalMutations.has(target)) return;
    const moves = this.settings.pendingMoves, previous = moves.find((move) => move.to === source);
    if (previous) {
      previous.to = target;
      previous.at = Date.now();
    } else {
      const index = moves.findIndex((move) => move.from === source);
      if (index >= 0) moves.splice(index, 1);
      moves.push({ from: source, to: target, at: Date.now() });
    }
    this.persistJournalSoon();
  }
  recordFileCreation(path) {
    const normalized = this.syncPath(path);
    if (this.stopped || this.expectedLocalMutations.has(normalized) || !shouldSyncChangedPath(normalized, this.settings)) return;
    this.journalIntent(this.vaultEventsReady ? "create" : "observe", normalized);
    this.settings.fileCreationTimes[normalized] = Date.now();
    this.persistJournalSoon();
  }
  recordPathTime(path, folder = false, at = Date.now()) {
    var _a;
    let normalized = this.syncPath(path);
    if (!normalized) return;
    if (folder && !normalized.endsWith("/")) normalized += "/";
    this.settings.pendingPathTimes[normalized] = Math.max((_a = this.settings.pendingPathTimes[normalized]) != null ? _a : 0, at);
  }
  async verifyExpectedMutation(path, expectedHash) {
    var _a;
    if (this.stopped) return;
    try {
      const adapter = (_a = this.syncAdapter) != null ? _a : this.app.vault.adapter, stat = await adapter.stat(path);
      if (this.stopped) return;
      if (!stat && expectedHash === null) {
        if (this.expectedLocalMutations.get(path) === expectedHash) this.expectedLocalMutations.delete(path);
        return;
      }
      if ((stat == null ? void 0 : stat.type) === "folder" && expectedHash === "folder") {
        if (this.expectedLocalMutations.get(path) === expectedHash) this.expectedLocalMutations.delete(path);
        return;
      }
      if ((stat == null ? void 0 : stat.type) === "file" && expectedHash && await hashAdapterFile(adapter, path, () => {
        if (this.stopped) throw new SyncCancelledError("Plugin unloaded");
      }, cooperativeYield) === expectedHash) {
        if (this.expectedLocalMutations.get(path) === expectedHash) this.expectedLocalMutations.delete(path);
        return;
      }
    } catch (e) {
    }
    if (this.stopped) return;
    if (this.expectedLocalMutations.get(path) !== expectedHash) return;
    this.expectedLocalMutations.delete(path);
    this.scheduleFileChangeSync(path);
  }
  queueExpectedMutationVerification(path, expectedHash) {
    this.expectedVerificationQueue.set(path, expectedHash);
    this.scheduleExpectedVerification();
  }
  scheduleExpectedVerification() {
    if (this.stopped || this.liveStatus.running || this.expectedVerificationRunning || this.expectedVerificationTimer !== null || !this.expectedVerificationQueue.size) return;
    this.expectedVerificationTimer = window.setTimeout(() => {
      this.expectedVerificationTimer = null;
      void this.drainExpectedVerifications();
    }, 100);
  }
  async drainExpectedVerifications() {
    if (this.expectedVerificationRunning || this.liveStatus.running) return;
    this.expectedVerificationRunning = true;
    try {
      while (!this.stopped && this.expectedVerificationQueue.size && !this.liveStatus.running) {
        const next = this.expectedVerificationQueue.entries().next().value;
        if (!next) break;
        this.expectedVerificationQueue.delete(next[0]);
        await this.verifyExpectedMutation(next[0], next[1]);
        await new Promise((resolve) => window.setTimeout(resolve, 0));
      }
    } finally {
      this.expectedVerificationRunning = false;
      if (this.expectedVerificationQueue.size) this.scheduleExpectedVerification();
    }
  }
  requireFullScan() {
    if (this.stopped) return;
    this.fullScanRevision++;
    this.settings.fullScanRequired = true;
    this.persistJournalSoon();
    if (!this.settings.deviceToken || !this.settings.syncOnFileChange) return;
    this.lastRelevantVaultChangeAt = Date.now();
    if (this.liveStatus.running) {
      this.fileChangePending = true;
      return;
    }
    this.queueSync(5e3, "Folder structure changed; reconciling safely", "file-change");
  }
  persistJournalSoon() {
    if (this.stopped) return;
    if (this.journalSaveTimer !== null) window.clearTimeout(this.journalSaveTimer);
    this.journalSaveTimer = window.setTimeout(() => {
      this.journalSaveTimer = null;
      void this.saveSettings();
    }, 250);
  }
  configureFileChangeSync() {
    if (this.settings.syncOnFileChange || this.debounceKind !== "file-change" || this.debounce === null) return;
    window.clearTimeout(this.debounce);
    this.debounce = null;
    this.debounceKind = null;
    this.liveStatus.nextSyncAt = null;
    this.report("idle", "File-change sync disabled");
    this.scheduleNextSyncLabel();
  }
  queueSync(delay, reason, kind = "file-change") {
    if (this.stopped || this.nativeSyncBlocked || this.settings.paused || this.safetyHold || this.compatibilityBlocked) return;
    if (this.debounce !== null) window.clearTimeout(this.debounce);
    this.debounceKind = kind;
    this.liveStatus.nextSyncAt = new Date(Date.now() + delay).toISOString();
    this.report("scheduled", `${reason}; sync in ${Math.max(1, Math.round(delay / 1e3))}s`);
    this.debounce = window.setTimeout(() => {
      this.debounce = null;
      this.debounceKind = null;
      void this.runSync();
    }, delay);
  }
  scheduleNextSyncLabel() {
    if (!this.nativeSyncBlocked && !this.settings.paused && !this.safetyHold && !this.compatibilityBlocked && this.settings.autoSync && this.settings.deviceToken) {
      this.liveStatus.nextSyncAt = new Date(Date.now() + Math.max(15, this.settings.syncIntervalSeconds) * 1e3).toISOString();
      this.emitStatus();
    } else {
      this.liveStatus.nextSyncAt = null;
      this.emitStatus();
    }
  }
  configureTimer() {
    if (this.timer !== null) window.clearInterval(this.timer);
    this.timer = null;
    if (!this.stopped && !this.nativeSyncBlocked && !this.settings.paused && !this.compatibilityBlocked && this.settings.autoSync && this.settings.deviceToken) {
      this.timer = window.setInterval(() => {
        if (!this.safetyHold) void this.runSync();
      }, Math.max(15, this.settings.syncIntervalSeconds) * 1e3);
      this.scheduleNextSyncLabel();
    } else {
      this.liveStatus.nextSyncAt = null;
      this.emitStatus();
    }
  }
  configureWatch() {
    const generation = ++this.watchGeneration;
    if (!this.stopped && !this.nativeSyncBlocked && !this.settings.paused && !this.compatibilityBlocked && this.settings.instantReceive && this.settings.deviceToken) void this.watchLoop(generation);
  }
  async watchLoop(generation) {
    var _a;
    let failures = 0;
    while (generation === this.watchGeneration && this.settings.instantReceive && this.settings.deviceToken) {
      try {
        const result = await this.api.watch(this.settings.lastSnapshotId);
        if (generation !== this.watchGeneration) return;
        const reconnected = failures > 0;
        failures = 0;
        if (reconnected && !this.liveStatus.running && !this.safetyHold) this.queueSync(750, "Connection restored; verifying this device", "automatic");
        if (result.attention) {
          this.safetyHold = true;
          await this.refreshServerStatus();
          this.report("blocked", "Suspicious remote changes need review", "warning");
          this.notify("safeguard", "Gib Sync quarantined suspicious remote changes. Review them in settings.", 1e4, 6e4);
          this.openSafeguards();
        } else if (result.changed && result.headId !== this.settings.lastSnapshotId) {
          if (this.safetyHold) {
            await new Promise((resolve) => window.setTimeout(resolve, 5e3));
            continue;
          }
          this.liveStatus.verified = false;
          if (!this.syncTask) this.report("scheduled", "Remote change detected; syncing now", "info");
          const succeeded = await this.runSync();
          if (!succeeded) await new Promise((resolve) => window.setTimeout(resolve, 6e4));
        }
      } catch (error) {
        if (generation !== this.watchGeneration) return;
        if (error instanceof ApiError && error.status === 426) {
          await this.checkCompatibility();
          return;
        }
        if (error instanceof ApiError && error.status === 423 && ((_a = error.responseBody) == null ? void 0 : _a.containment)) {
          this.safetyHold = true;
          await this.refreshServerStatus();
          await new Promise((resolve) => window.setTimeout(resolve, 3e4));
          continue;
        }
        failures++;
        if (!this.syncTask && !this.safetyHold && !this.compatibilityBlocked) {
          this.liveStatus.verified = false;
          if (failures === 1) this.report("retrying", "Reconnecting to incoming updates; periodic checks remain active", "info");
          else if (failures === 4) this.report("offline", "Incoming updates are unavailable; periodic checks remain active", "warning");
        }
        await new Promise((resolve) => window.setTimeout(resolve, Math.min(1e4, 1e3 * 2 ** Math.min(failures - 1, 3))));
      }
    }
  }
};
